from fastapi import FastAPI, Depends, HTTPException, Query, Form, Request
from fastapi.responses import JSONResponse, HTMLResponse, RedirectResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from sqlalchemy import or_
from datetime import datetime
import json, uuid, time, os

from database import get_db, engine, Base
from models import (
    SVS, Ticket, User, ScoringRule, ScoringRuleSubItem, ScoringRubric,
    ScoringRequestLog, AuditLog, ApiLog,
)
import schemas

# ── FastAPI App ──────────────────────────────────────────────────────
app = FastAPI(
    title="HSBC Admin Portal",
    description="FastAPI backend for HSBC project scoring management",
    version="2.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Jinja2 templates
templates = Jinja2Templates(directory="templates")

# Jinja2 filter: parse JSON string
def from_json_filter(value):
    if value is None:
        return []
    if isinstance(value, str):
        try:
            return json.loads(value)
        except (json.JSONDecodeError, TypeError):
            return []
    return value

templates.env.filters['from_json'] = from_json_filter

# ── Helper: add audit log ────────────────────────────────────────────
def log_action(db: Session, action: str, object_type: str = None,
               object_id: str = None, details: str = None):
    log = AuditLog(
        timestamp=datetime.now().strftime('%Y-%m-%d %H:%M'),
        user_id='admin_001',
        action=action,
        object_type=object_type,
        object_id=object_id,
        details=details,
    )
    db.add(log)
    db.commit()


# ============================================================
# API: Dashboard Data
# ============================================================
@app.get("/api/dashboard", response_model=schemas.DashboardResponse)
def api_dashboard(db: Session = Depends(get_db)):
    total_svs = db.query(SVS).count()
    total_tickets = db.query(Ticket).count()
    high_priority = db.query(Ticket).filter_by(priority='HIGH').count()
    pending_tickets = db.query(Ticket).filter_by(status='PENDING').count()

    priority_dist = [
        {'name': 'High', 'value': db.query(Ticket).filter_by(priority='HIGH').count(), 'color': '#DA291C'},
        {'name': 'Medium', 'value': db.query(Ticket).filter_by(priority='MEDIUM').count(), 'color': '#F59E0B'},
        {'name': 'Low', 'value': db.query(Ticket).filter_by(priority='LOW').count(), 'color': '#3B82F6'},
    ]

    recent = db.query(Ticket).order_by(Ticket.id.desc()).limit(5).all()
    svs_all = db.query(SVS).all()

    bar_data = []
    for s in sorted(svs_all, key=lambda x: len(x.tickets), reverse=True)[:6]:
        bar_data.append({'name': s.name[:18] + ('...' if len(s.name) > 18 else ''), 'score': len(s.tickets)})

    return {
        'kpi': {
            'total_svs': total_svs,
            'total_tickets': total_tickets,
            'high': high_priority,
            'pending': pending_tickets,
        },
        'priority_dist': priority_dist,
        'recent_tickets': [t.to_dict() for t in recent],
        'svs_list': [s.to_dict() for s in svs_all],
        'bar_data': bar_data,
    }


# ============================================================
# API: SVS
# ============================================================
@app.get("/api/svs")
def api_svs_list(
    search: str = Query(default=""),
    priority: str = Query(default="All"),
    status: str = Query(default="All"),
    db: Session = Depends(get_db)
):
    query = db.query(SVS)
    if search:
        query = query.filter(or_(
            SVS.name.ilike(f'%{search}%'),
            SVS.svs_id.ilike(f'%{search}%')
        ))
    if priority != "All":
        query = query.filter_by(priority=priority.upper())
    if status != "All":
        query = query.filter_by(status=status.upper())
    items = query.all()
    return {"svs": [s.to_dict() for s in items]}


@app.post("/api/svs", response_model=schemas.SVSResponse)
def api_create_svs(payload: schemas.SVSCreate, db: Session = Depends(get_db)):
    svs_id = f'SVS-{datetime.now().strftime("%Y%m%d-%H%M%S")}'
    new = SVS(
        svs_id=svs_id,
        name=payload.name,
        description=payload.description,
        owner=payload.owner,
        priority=payload.priority.upper(),
        status=payload.status.upper(),
    )
    db.add(new)
    db.commit()
    db.refresh(new)
    log_action(db, 'SVS Created', 'svs', svs_id)
    return new


@app.delete("/api/svs/{svs_db_id}")
def api_delete_svs(svs_db_id: int, db: Session = Depends(get_db)):
    svs = db.query(SVS).get(svs_db_id)
    if not svs:
        raise HTTPException(status_code=404, detail="SVS not found")
    svs_id = svs.svs_id
    db.delete(svs)
    db.commit()
    log_action(db, 'SVS Deleted', 'svs', svs_id)
    return {"status": "deleted", "svs_id": svs_id}


# ============================================================
# API: Tickets
# ============================================================
@app.get("/api/tickets")
def api_tickets_list(
    search: str = Query(default=""),
    priority: str = Query(default="All"),
    status: str = Query(default="All"),
    svs: str = Query(default="All"),
    db: Session = Depends(get_db)
):
    query = db.query(Ticket)
    if search:
        query = query.filter(or_(
            Ticket.title.ilike(f'%{search}%'),
            Ticket.ticket_id.ilike(f'%{search}%')
        ))
    if priority != "All":
        query = query.filter_by(priority=priority.upper())
    if status != "All":
        query = query.filter_by(status=status.upper())
    if svs != "All":
        query = query.filter_by(svs_id=int(svs))
    items = query.all()
    return {"tickets": [t.to_dict() for t in items]}


@app.post("/api/tickets", response_model=schemas.TicketResponse)
def api_create_ticket(payload: schemas.TicketCreate, db: Session = Depends(get_db)):
    ticket_id = f'T-{datetime.now().strftime("%Y%m%d-%H%M%S")}'
    new = Ticket(
        ticket_id=ticket_id,
        title=payload.title,
        description=payload.description,
        svs_id=payload.svs_id,
        requested_by=payload.requested_by,
        department=payload.department,
        priority=payload.priority.upper(),
        status=payload.status.upper(),
    )
    db.add(new)
    db.commit()
    db.refresh(new)
    log_action(db, 'Ticket Created', 'ticket', ticket_id)
    return new


@app.delete("/api/tickets/{ticket_db_id}")
def api_delete_ticket(ticket_db_id: int, db: Session = Depends(get_db)):
    ticket = db.query(Ticket).get(ticket_db_id)
    if not ticket:
        raise HTTPException(status_code=404, detail="Ticket not found")
    tid = ticket.ticket_id
    db.delete(ticket)
    db.commit()
    log_action(db, 'Ticket Deleted', 'ticket', tid)
    return {"status": "deleted", "ticket_id": tid}


# ============================================================
# API: Scoring Rules
# ============================================================
@app.get("/api/scoring-rules")
def api_get_scoring_rules(db: Session = Depends(get_db)):
    rules = db.query(ScoringRule).all()
    return {"scoring_rules": [r.to_agent_payload() for r in rules]}


@app.put("/api/scoring-rules/{rule_id}")
def api_update_scoring_rule(rule_id: str, payload: dict, db: Session = Depends(get_db)):
    rule = db.query(ScoringRule).filter_by(rule_id=rule_id).first()
    if not rule:
        raise HTTPException(status_code=404, detail="Rule not found")

    if "title" in payload:
        rule.title = payload["title"]
    if "weight" in payload:
        rule.weight = payload["weight"]

    if "sub_items" in payload:
        # 1. Clear existing sub_items (cascade deletes rubric_rows automatically)
        for si in list(rule.sub_items):
            db.delete(si)
        db.flush()

        # 2. Recreate all sub_items with fresh rubric rows
        for idx, si_data in enumerate(payload["sub_items"]):
            new_si = ScoringRuleSubItem(
                rule_id=rule.id,
                name=si_data["name"],
                sub_weight=si_data.get("sub_weight", 50.0),
                criteria=si_data.get("criteria", ""),
                order=si_data.get("order", idx),
            )
            db.add(new_si)
            db.flush()
            for rubric in si_data.get("rubric_rows", []):
                db.add(ScoringRubric(
                    sub_item_id=new_si.id,
                    score_level=rubric["score_level"],
                    description=rubric["description"],
                ))

    db.commit()
    log_action(db, 'Scoring Rule Updated', 'scoring_rule', rule_id)
    return {"status": "updated", "rule_id": rule_id}


@app.post("/api/scoring-rules")
def api_create_scoring_rule(payload: schemas.ScoringRuleCreate, db: Session = Depends(get_db)):
    rule = ScoringRule(
        rule_id=payload.rule_id,
        title=payload.title,
        weight=payload.weight,
    )
    db.add(rule)
    db.commit()
    db.refresh(rule)
    for si_data in payload.sub_items:
        si = ScoringRuleSubItem(
            rule_id=rule.id,
            name=si_data.name,
            sub_weight=si_data.sub_weight,
            criteria=si_data.criteria,
        )
        db.add(si)
        db.commit()
        db.refresh(si)
        for rubric in si_data.rubric_rows:
            db.add(ScoringRubric(
                sub_item_id=si.id,
                score_level=rubric.score_level,
                description=rubric.description,
            ))
        db.commit()
    log_action(db, 'Scoring Rule Created', 'scoring_rule', payload.rule_id)
    return {"status": "created", "rule_id": payload.rule_id}


@app.delete("/api/scoring-rules/{rule_id}")
def api_delete_scoring_rule(rule_id: str, db: Session = Depends(get_db)):
    rule = db.query(ScoringRule).filter_by(rule_id=rule_id).first()
    if not rule:
        raise HTTPException(status_code=404, detail="Rule not found")
    db.delete(rule)
    db.commit()
    log_action(db, 'Scoring Rule Deleted', 'scoring_rule', rule_id)
    return {"status": "deleted", "rule_id": rule_id}


# ============================================================
# API: Score Ticket
# ============================================================
def build_agent_prompt(payload):
    """Build the system + user prompt for the Agent LLM API."""
    ticket = payload.get('ticket', {})
    rules = payload.get('scoring_rules', [])

    system_prompt = """You are an expert project scoring analyst at HSBC. Your job is to evaluate project tickets against predefined scoring rules and return a structured assessment.

SCORING RULES:
- Each category has a weight (0-100%).
- Each subcategory within a category has a sub-weight (0-100%).
- Each subcategory has a 1-5 rubric scale defining what each score means.
- You must evaluate every subcategory independently.

OUTPUT FORMAT (strict JSON):
{
  "total_score": <0-100>,
  "evidence": [
    {
      "subcategory": "<exact subcategory name>",
      "category": "<exact category name>",
      "score": <1-5>,
      "rubric_level": <1-5>,
      "rubric_description": "<description of the chosen rubric level>",
      "reasoning": "<why you chose this score, referencing ticket text>",
      "quoted_text": "<exact keyword or phrase from ticket description that supports this score>",
      "subcategory_weight": <number>,
      "category_weight": <number>
    }
  ]
}

SCORING METHODOLOGY:
1. Read the ticket description carefully.
2. For each subcategory, compare the ticket against the rubric levels 1-5.
3. Choose the rubric level that best matches the ticket.
4. Provide specific evidence: quote exact words/phrases from the ticket that justify the score.
5. If the ticket strongly matches a high-level rubric criterion, give a high score.
6. If the ticket lacks evidence for a criterion, give a low score.
7. Be objective and consistent. Do not inflate scores.

TOTAL SCORE CALCULATION:
total_score = sum over all evidence of (category_weight / 100 * subcategory_weight / 100 * score * 20)
This produces a score from 0 to 100.

IMPORTANT:
- Return ONLY valid JSON. No markdown, no explanation text outside JSON.
- Every subcategory must have an evidence entry.
- quoted_text must be an exact substring from the ticket description or title."""

    user_prompt = f"""TICKET TO EVALUATE:
Ticket ID: {ticket.get('ticket_id', 'N/A')}
Title: {ticket.get('title', 'N/A')}
Description: {ticket.get('description', 'No description provided')}
SVS: {ticket.get('svs', {}).get('name', 'N/A') if ticket.get('svs') else 'N/A'}
Priority: {ticket.get('priority', 'N/A')}

SCORING RULES:
"""
    for rule in rules:
        cat = rule['category']
        cat_w = rule['weight']
        user_prompt += f"\nCategory: {cat} (Weight: {cat_w}%)\n"
        for sub in rule.get('subcategories', []):
            sub_name = sub['name']
            sub_w = sub['sub_weight']
            rubric = sub.get('rubric', {})
            user_prompt += f"  Subcategory: {sub_name} (Sub Weight: {sub_w}%)\n"
            for level in [1, 2, 3, 4, 5]:
                desc = rubric.get(str(level), 'No description')
                label = {1: 'Minimal', 2: 'Low', 3: 'Medium', 4: 'High', 5: 'Exceptional'}.get(level, '')
                user_prompt += f"    Score {level} — {label}: {desc}\n"

    user_prompt += """
Please evaluate the ticket against every subcategory above and return ONLY the JSON response."""

    return {
        "model": "gpt-4o",
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        "temperature": 0.2,
        "max_tokens": 4000,
        "response_format": {"type": "json_object"}
    }


def validate_agent_response(result, scoring_rules):
    """Validate the LLM response with minimal checks."""
    if not isinstance(result, dict):
        return False, "Response is not a JSON object", None
    if 'total_score' not in result:
        return False, "Missing 'total_score' field", None

    total_score = result.get('total_score')
    if not isinstance(total_score, (int, float)):
        return False, f"'total_score' is not a number: {type(total_score)}", None
    if not (0 <= total_score <= 100):
        return False, f"'total_score' out of range: {total_score}", None

    if 'evidence' not in result:
        return False, "Missing 'evidence' field", None

    evidence = result.get('evidence')
    if not isinstance(evidence, list):
        return False, f"'evidence' is not an array: {type(evidence)}", None

    expected_subs_map = {}
    for rule in scoring_rules:
        cat_name = rule['category']
        cat_w = rule['weight']
        for sub in rule.get('subcategories', []):
            sub_name = sub['name']
            expected_subs_map[sub_name] = {
                'category': cat_name,
                'category_weight': cat_w,
                'sub_weight': sub['sub_weight'],
                'rubric': sub.get('rubric', {}),
            }

    seen_subs = set()
    for ev in evidence:
        if not isinstance(ev, dict):
            continue
        sub_name = ev.get('subcategory')
        if not sub_name or sub_name not in expected_subs_map:
            continue
        if sub_name in seen_subs:
            continue
        seen_subs.add(sub_name)

        score = ev.get('score')
        if not isinstance(score, (int, float)) or not (1 <= score <= 5):
            score = 3
            ev['score'] = score

        info = expected_subs_map[sub_name]
        ev.setdefault('category', info['category'])
        ev.setdefault('category_weight', info['category_weight'])
        ev.setdefault('subcategory_weight', info['sub_weight'])
        ev.setdefault('rubric_level', score)
        rubric = info['rubric']
        rubric_desc = rubric.get(str(score), rubric.get(str(int(score)), 'No rubric description'))
        ev.setdefault('rubric_description', rubric_desc)
        ev.setdefault('reasoning', 'No detailed reasoning provided.')
        ev.setdefault('quoted_text', 'N/A')

    for sub_name, info in expected_subs_map.items():
        if sub_name not in seen_subs:
            evidence.append({
                'subcategory': sub_name,
                'category': info['category'],
                'score': 0,
                'rubric_level': 0,
                'rubric_description': 'Not mentioned in ticket — default score 0',
                'reasoning': 'This subcategory was not explicitly addressed in the ticket description. Default score: 0/5.',
                'quoted_text': 'N/A',
                'subcategory_weight': info['sub_weight'],
                'category_weight': info['category_weight'],
            })

    calculated = 0.0
    for ev in evidence:
        cat_w = float(ev.get('category_weight', 0) or 0)
        sub_w = float(ev.get('subcategory_weight', 0) or 0)
        score = int(ev.get('score', 0) or 0)
        calculated += (cat_w / 100.0) * (sub_w / 100.0) * score * 20

    if abs(calculated - total_score) > 3.0:
        result['total_score'] = round(calculated, 2)

    return True, None, result


def _parse_api_response(response_json):
    """Extract content string from various LLM / API response formats."""
    if isinstance(response_json, dict):
        if 'choices' in response_json and response_json['choices']:
            choice = response_json['choices'][0]
            if isinstance(choice, dict):
                msg = choice.get('message', {})
                if isinstance(msg, dict) and 'content' in msg:
                    return msg['content']
        if 'total_score' in response_json or 'evidence' in response_json:
            return json.dumps(response_json)
        for key in ('data', 'result', 'body', 'response', 'output'):
            if key in response_json:
                val = response_json[key]
                if isinstance(val, str):
                    return val
                if isinstance(val, dict):
                    return json.dumps(val)
    return json.dumps(response_json) if isinstance(response_json, dict) else str(response_json)


def _simulate_llm_response(payload, inject_errors=False):
    """Simulate LLM response for development."""
    import random
    if inject_errors and random.random() < 0.1:
        bad = [
            'not json at all',
            '{"total_score": 999}',
            '{"evidence": []}',
            '{"total_score": 50, "evidence": [{"score": 10}]}',
        ]
        return random.choice(bad)

    scoring_rules = payload.get('scoring_rules', [])
    evidence = []
    total_weighted = 0.0
    desc = payload.get('ticket', {}).get('description', '')
    title = payload.get('ticket', {}).get('title', '')
    combined = (title + ' ' + desc).lower()

    keyword_map = {
        5: ['ai', 'ml', 'transform', 'strategic', 'platform', 'autonomous', 'breakthrough'],
        4: ['upgrade', 'enhancement', 'optimization', 'improvement', 'redesign', 'advanced'],
        3: ['integration', 'migration', 'development', 'implementation', 'modernization'],
        2: ['basic', 'maintenance', 'minor', 'setup', 'fix', 'patch', 'update'],
        1: ['bugfix', 'repair', 'trivial'],
    }

    for rule in scoring_rules:
        cat_name = rule['category']
        cat_weight = rule['weight']
        for sub in rule.get('subcategories', []):
            sub_name = sub['name']
            sub_weight = sub['sub_weight']
            rubric = sub.get('rubric', {})
            matched = []
            score = 3
            for level, kws in keyword_map.items():
                for kw in kws:
                    if kw in combined:
                        score = level
                        matched.append(kw)
                        break
                if score != 3:
                    break
            rubric_desc = rubric.get(str(score), 'No rubric description')
            quoted = f"Detected: {', '.join(matched)}" if matched else "No strong keywords found"
            evidence.append({
                'subcategory': sub_name,
                'category': cat_name,
                'score': score,
                'rubric_level': score,
                'rubric_description': rubric_desc,
                'reasoning': f"Score {score}/5 based on ticket analysis. {quoted}",
                'quoted_text': quoted,
                'subcategory_weight': sub_weight,
                'category_weight': cat_weight,
            })
            total_weighted += (cat_weight / 100.0) * (sub_weight / 100.0) * score * 20

    total_score = min(100, max(0, total_weighted))
    return json.dumps({
        'total_score': round(total_score, 2),
        'evidence': evidence,
        'reasoning_summary': f"Scored {len(evidence)} subcategories. Total: {total_score:.1f}/100.",
    })


def call_agent_api(payload):
    """Layer 1 — Call user's Agent API. Production: replace with real HTTP call."""
    # import requests
    # response = requests.post(...)
    # return _parse_api_response(response.json())
    return _simulate_llm_response(payload, inject_errors=True)


def call_llm_direct(payload):
    """Layer 2 — Degrade to direct LLM API."""
    # import requests
    # response = requests.post(...)
    # return _parse_api_response(response.json())
    return _simulate_llm_response(payload, inject_errors=False)


def call_scoring_agent(payload):
    """Two-layer scoring: Agent API (3 retries) → Direct LLM → raise error."""
    MAX_RETRIES = 3
    last_error = None

    for attempt in range(MAX_RETRIES):
        try:
            raw = call_agent_api(payload)
            result = json.loads(raw)
            is_valid, error_msg, result = validate_agent_response(result, payload.get('scoring_rules', []))
            if is_valid:
                if 'reasoning_summary' not in result:
                    total = result['total_score']
                    count = len(result['evidence'])
                    result['reasoning_summary'] = f"Scored {count} subcategories. Total: {total:.1f}/100."
                return result
            last_error = error_msg
        except json.JSONDecodeError as e:
            last_error = f"Invalid JSON: {str(e)}"
        except Exception as e:
            last_error = str(e)
            if attempt < MAX_RETRIES - 1:
                continue

    last_llm_error = None
    try:
        raw = call_llm_direct(payload)
        result = json.loads(raw)
        is_valid, error_msg, result = validate_agent_response(result, payload.get('scoring_rules', []))
        if is_valid:
            if 'reasoning_summary' not in result:
                total = result['total_score']
                count = len(result['evidence'])
                result['reasoning_summary'] = f"[Direct LLM] Scored {count} subcategories. Total: {total:.1f}/100."
            return result
        last_llm_error = error_msg
    except Exception as e:
        last_llm_error = str(e)

    raise RuntimeError(
        f"Scoring failed: Agent API exhausted after {MAX_RETRIES} retries, "
        f"and direct LLM API also failed ({last_llm_error or 'validation failed'}). "
        f"Please retry the request."
    )


@app.post("/api/score", response_model=schemas.ScoreResponse)
def api_score_ticket(payload: schemas.ScoreRequest, db: Session = Depends(get_db)):
    """Score a ticket. Can be called multiple times (preview mode)."""
    start_time = time.time()
    svs_id_str = payload.svs
    ticket_id_str = payload.ticket
    description = payload.description

    if not svs_id_str or not ticket_id_str:
        raise HTTPException(status_code=400, detail="Missing required fields: svs and ticket")

    svs = db.query(SVS).filter_by(svs_id=svs_id_str).first()
    if not svs:
        raise HTTPException(status_code=404, detail=f"SVS not found: {svs_id_str}")

    ticket = db.query(Ticket).filter_by(ticket_id=ticket_id_str).first()
    if not ticket:
        ticket = Ticket(
            ticket_id=ticket_id_str,
            title=ticket_id_str,
            description=description,
            svs_id=svs.id,
            requested_by='system',
            department='System',
            priority='MEDIUM',
            status='DRAFT',
        )
        db.add(ticket)
        db.commit()
        db.refresh(ticket)
        log_action(db, 'Ticket Auto-Created', 'ticket', ticket_id_str, f'SVS: {svs_id_str}')
    else:
        if ticket.description != description:
            ticket.description = description
            db.commit()

    if ticket.status == 'CONFIRMED':
        raise HTTPException(status_code=409, detail="Ticket already confirmed. Cannot re-score.")

    request_id = f"SCR-{uuid.uuid4().hex[:12].upper()}"
    scoring_log = ScoringRequestLog(
        request_id=request_id,
        ticket_id=ticket.id,
        status='processing',
    )
    db.add(scoring_log)
    db.commit()

    try:
        rules = db.query(ScoringRule).all()
        scoring_rules_payload = [r.to_agent_payload() for r in rules]
        ticket_payload = {
            'id': ticket.id,
            'ticket_id': ticket.ticket_id,
            'title': ticket.title,
            'description': ticket.description,
            'priority': ticket.priority,
            'status': ticket.status,
            'svs': svs.to_dict(),
        }
        agent_payload = {
            'ticket': ticket_payload,
            'scoring_rules': scoring_rules_payload,
        }
        scoring_log.request_payload = json.dumps(agent_payload, indent=2, default=str)
        db.commit()

        agent_result = call_scoring_agent(agent_payload)
        processing_time_ms = int((time.time() - start_time) * 1000)

        scoring_log.status = 'completed'
        scoring_log.response_payload = json.dumps(agent_result, indent=2, default=str)
        scoring_log.scores = json.dumps(agent_result['evidence'], indent=2, default=str)
        scoring_log.total_score = agent_result['total_score']
        scoring_log.processing_time_ms = processing_time_ms
        scoring_log.completed_at = datetime.utcnow()
        db.commit()

        log_action(db, 'Ticket Preview Scored', 'ticket', ticket.ticket_id,
                   f'Score: {agent_result["total_score"]} | Request: {request_id}')

        return {
            'request_id': request_id,
            'status': 'completed',
            'ticket': ticket_payload,
            'total_score': agent_result['total_score'],
            'evidence': agent_result['evidence'],
            'reasoning_summary': agent_result['reasoning_summary'],
            'processing_time_ms': processing_time_ms,
        }

    except Exception as e:
        processing_time_ms = int((time.time() - start_time) * 1000)
        scoring_log.status = 'failed'
        scoring_log.error_message = str(e)
        scoring_log.processing_time_ms = processing_time_ms
        scoring_log.completed_at = datetime.utcnow()
        db.commit()
        log_action(db, 'Ticket Scoring Failed', 'ticket', ticket.ticket_id,
                   f'Error: {str(e)} | Request: {request_id}')
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/confirm", response_model=schemas.ConfirmResponse)
def api_confirm_score(payload: schemas.ConfirmRequest, db: Session = Depends(get_db)):
    """Confirm the final score for a ticket."""
    svs_id_str = payload.svs
    ticket_id_str = payload.ticket

    if not svs_id_str or not ticket_id_str:
        raise HTTPException(status_code=400, detail="Missing required fields: svs and ticket")

    svs = db.query(SVS).filter_by(svs_id=svs_id_str).first()
    if not svs:
        raise HTTPException(status_code=404, detail=f"SVS not found: {svs_id_str}")

    ticket = db.query(Ticket).filter_by(ticket_id=ticket_id_str, svs_id=svs.id).first()
    if not ticket:
        raise HTTPException(status_code=404, detail=f"Ticket not found: {ticket_id_str}")

    if ticket.status == 'CONFIRMED':
        return {"status": "already_confirmed", "ticket": ticket.to_dict()}

    old_status = ticket.status
    ticket.status = 'CONFIRMED'
    db.commit()
    log_action(db, 'Ticket Confirmed', 'ticket', ticket.ticket_id,
               f'Status changed from {old_status} to CONFIRMED')
    return {"status": "confirmed", "ticket": ticket.to_dict()}


@app.get("/api/score/{request_id}")
def api_get_score_result(request_id: str, db: Session = Depends(get_db)):
    """Get scoring result by request ID."""
    log = db.query(ScoringRequestLog).filter_by(request_id=request_id).first()
    if not log:
        raise HTTPException(status_code=404, detail="Request not found")
    return {
        'request_id': log.request_id,
        'status': log.status,
        'ticket_id': log.ticket_id,
        'total_score': float(log.total_score) if log.total_score else None,
        'evidence': json.loads(log.scores) if log.scores else None,
        'processing_time_ms': log.processing_time_ms,
        'error_message': log.error_message,
        'created_at': log.created_at.isoformat() if log.created_at else None,
        'completed_at': log.completed_at.isoformat() if log.completed_at else None,
    }


# ============================================================
# API: Users
# ============================================================
@app.get("/api/users")
def api_users_list(db: Session = Depends(get_db)):
    users = db.query(User).all()
    return {"users": [u.to_dict() for u in users]}


@app.post("/api/users", response_model=schemas.UserResponse)
def api_create_user(payload: schemas.UserCreate, db: Session = Depends(get_db)):
    # Check duplicate staff_id
    existing = db.query(User).filter_by(staff_id=payload.staff_id).first()
    if existing:
        raise HTTPException(status_code=409, detail=f"Staff ID '{payload.staff_id}' already exists")
    user = User(
        staff_id=payload.staff_id,
        username=payload.username,
        department=payload.department,
        role=payload.role,
        status=payload.status,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    log_action(db, 'User Created', 'user', str(user.id), f"Staff ID: {payload.staff_id}, Name: {payload.username}")
    return user


@app.put("/api/users/{user_id}")
def api_update_user(user_id: int, payload: dict, db: Session = Depends(get_db)):
    user = db.query(User).get(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    if "role" in payload:
        user.role = payload["role"]
    if "status" in payload:
        user.status = payload["status"]
    db.commit()
    log_action(db, 'User Updated', 'user', str(user_id))
    return {"status": "updated", "user_id": user_id}


@app.delete("/api/users/{user_id}")
def api_delete_user(user_id: int, db: Session = Depends(get_db)):
    user = db.query(User).get(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    db.delete(user)
    db.commit()
    log_action(db, 'User Deleted', 'user', str(user_id))
    return {"status": "deleted", "user_id": user_id}


# ============================================================
# API: Audit Logs
# ============================================================
@app.get("/api/audit-logs")
def api_audit_logs(
    search: str = Query(default=""),
    db: Session = Depends(get_db)
):
    query = db.query(AuditLog)
    if search:
        query = query.filter(or_(
            AuditLog.user_id.ilike(f'%{search}%'),
            AuditLog.action.ilike(f'%{search}%')
        ))
    logs = query.order_by(AuditLog.id.desc()).limit(50).all()
    return {"logs": [l.to_dict() for l in logs]}


# ============================================================
# API: Scoring Logs
# ============================================================
@app.get("/api/scoring-logs")
def api_scoring_logs(db: Session = Depends(get_db)):
    logs = db.query(ScoringRequestLog).order_by(ScoringRequestLog.id.desc()).all()
    result = []
    for log in logs:
        ticket = db.query(Ticket).get(log.ticket_id)
        evidence = []
        if log.scores:
            try:
                evidence = json.loads(log.scores)
            except (json.JSONDecodeError, TypeError):
                evidence = []
        result.append({
            "id": log.id,
            "request_id": log.request_id,
            "ticket_id": log.ticket_id,
            "ticket": ticket.to_dict() if ticket else None,
            "total_score": float(log.total_score) if log.total_score else None,
            "status": log.status,
            "processing_time_ms": log.processing_time_ms,
            "scores": evidence,
            "error_message": log.error_message,
            "created_at": log.created_at.isoformat() if log.created_at else None,
            "completed_at": log.completed_at.isoformat() if log.completed_at else None,
        })
    return {"logs": result}


# ============================================================
# API: API Logs (seed data for now)
# ============================================================
@app.get("/api/api-logs")
def api_api_logs(db: Session = Depends(get_db)):
    logs = db.query(ApiLog).order_by(ApiLog.id.desc()).limit(50).all()
    return {"logs": [l.to_dict() for l in logs]}


# ============================================================
# Page Routes (TemplateResponse — data fetched by frontend JS)
# ============================================================
@app.get("/", response_class=HTMLResponse)
def page_dashboard(request: Request):
    return templates.TemplateResponse("dashboard.html", {"request": request, "active_page": "dashboard"})


@app.get("/svs", response_class=HTMLResponse)
def page_svs(request: Request):
    return templates.TemplateResponse("svs.html", {"request": request, "active_page": "svs"})


@app.get("/tickets", response_class=HTMLResponse)
def page_tickets(request: Request):
    return templates.TemplateResponse("tickets.html", {"request": request, "active_page": "tickets"})


@app.get("/scoring-rules", response_class=HTMLResponse)
def page_scoring_rules(request: Request):
    return templates.TemplateResponse("scoring_rules.html", {"request": request, "active_page": "scoring_rules"})


@app.get("/users", response_class=HTMLResponse)
def page_users(request: Request):
    return templates.TemplateResponse("users.html", {"request": request, "active_page": "users"})


@app.get("/audit-logs", response_class=HTMLResponse)
def page_audit_logs(request: Request):
    return templates.TemplateResponse("audit_logs.html", {"request": request, "active_page": "audit_logs"})


@app.get("/scoring-logs", response_class=HTMLResponse)
def page_scoring_logs(request: Request):
    return templates.TemplateResponse("scoring_logs.html", {"request": request, "active_page": "scoring_logs"})


@app.get("/api-logs", response_class=HTMLResponse)
def page_api_logs(request: Request):
    return templates.TemplateResponse("api_logs.html", {"request": request, "active_page": "api_logs"})


# ============================================================
# System Routes
# ============================================================
@app.get("/init-db")
def init_database():
    Base.metadata.create_all(bind=engine)
    return {"status": "ok", "message": "Database initialized"}


@app.get("/seed")
def seed_data(db: Session = Depends(get_db)):
    """Seed demo data into the database."""
    # Seed SVS
    if db.query(SVS).count() == 0:
        svs_data = [
            ('SVS-001', 'Cross-Border Payments', 'Digital transformation of cross-border payment infrastructure', 'Alice Chen', 'HIGH', 'ACTIVE'),
            ('SVS-002', 'AI Fraud Detection', 'Machine learning platform for real-time fraud detection', 'Bob Wang', 'HIGH', 'ACTIVE'),
            ('SVS-003', 'Mobile Banking Upgrade', 'Next-generation mobile banking app with biometric auth', 'Carol Li', 'MEDIUM', 'ACTIVE'),
            ('SVS-004', 'Data Lake Modernization', 'Cloud-native data lake for unified analytics', 'David Zhang', 'MEDIUM', 'ACTIVE'),
            ('SVS-005', 'Regulatory Reporting', 'Automated regulatory reporting platform', 'Eva Liu', 'LOW', 'ACTIVE'),
        ]
        for sid, name, desc, owner, priority, status in svs_data:
            db.add(SVS(svs_id=sid, name=name, description=desc, owner=owner, priority=priority, status=status))
        db.commit()

    # Seed Tickets
    if db.query(Ticket).count() == 0:
        svs_all = db.query(SVS).all()
        ticket_data = [
            ('T-2024-001', 'Implement real-time SWIFT gpi integration for cross-border payments', svs_all[0].id, 'Alice Chen', 'Payments', 'HIGH', 'PENDING'),
            ('T-2024-002', 'Deploy transformer-based anomaly detection model for fraud scoring', svs_all[1].id, 'Bob Wang', 'Risk', 'HIGH', 'DRAFT'),
            ('T-2024-003', 'Add face recognition + liveness detection to mobile login flow', svs_all[2].id, 'Carol Li', 'Digital', 'MEDIUM', 'PENDING'),
            ('T-2024-004', 'Migrate legacy Hadoop cluster to GCP BigQuery and Cloud Storage', svs_all[3].id, 'David Zhang', 'Data', 'MEDIUM', 'DRAFT'),
            ('T-2024-005', 'Build MAS TRM reporting automation pipeline', svs_all[4].id, 'Eva Liu', 'Compliance', 'LOW', 'PENDING'),
        ]
        for tid, title, svs_id, req_by, dept, priority, status in ticket_data:
            db.add(Ticket(ticket_id=tid, title=title, description=title, svs_id=svs_id,
                          requested_by=req_by, department=dept, priority=priority, status=status))
        db.commit()

    # Seed Users
    if db.query(User).count() == 0:
        user_data = [
            ('admin001', 'Alice Chen', 'Alice Chen', 'Digital Transformation', 'Admin', 'Active'),
            ('admin002', 'Bob Wang', 'Bob Wang', 'Risk Management', 'Manager', 'Active'),
            ('usr003', 'Carol Li', 'Carol Li', 'Digital Banking', 'Submitter', 'Active'),
            ('usr004', 'David Zhang', 'David Zhang', 'Data Engineering', 'Submitter', 'Active'),
            ('usr005', 'Eva Liu', 'Eva Liu', 'Compliance', 'Submitter', 'Inactive'),
        ]
        for sid, uname, display, dept, role, status in user_data:
            db.add(User(staff_id=sid, username=uname, department=dept, role=role, status=status))
        db.commit()

    # Seed Scoring Rules
    if db.query(ScoringRule).count() == 0:
        rules_data = [
            ('SR-01', 'Strategic Alignment', 20.00),
            ('SR-02', 'Technical Complexity', 15.00),
            ('SR-03', 'Business Value', 25.00),
            ('SR-04', 'Risk Assessment', 20.00),
            ('SR-05', 'Resource Requirements', 20.00),
        ]
        for rid, title, weight in rules_data:
            db.add(ScoringRule(rule_id=rid, title=title, weight=weight))
        db.commit()

        # Seed sub-items and rubrics
        rule_map = {r.rule_id: r for r in db.query(ScoringRule).all()}
        sub_items_data = [
            ('SR-01', 'Strategic Fit', 50.0, [
                (1, 'No alignment with strategic objectives'),
                (2, 'Weak alignment, requires significant justification'),
                (3, 'Moderate alignment with some strategic goals'),
                (4, 'Strong alignment with key strategic objectives'),
                (5, 'Directly drives core strategic priorities'),
            ]),
            ('SR-01', 'Executive Sponsorship', 50.0, [
                (1, 'No executive sponsorship identified'),
                (2, 'Limited sponsorship from mid-level management'),
                (3, 'Department head sponsorship'),
                (4, 'VP-level executive sponsorship'),
                (5, 'C-suite executive sponsorship and commitment'),
            ]),
            ('SR-02', 'Technology Innovation', 40.0, [
                (1, 'Uses legacy or outdated technology'),
                (2, 'Minor technology refresh'),
                (3, 'Moderate technology upgrade'),
                (4, 'Significant technology advancement'),
                (5, 'Breakthrough or transformative technology'),
            ]),
            ('SR-02', 'Integration Complexity', 60.0, [
                (1, 'Standalone system, no integration needed'),
                (2, 'Simple integration with 1-2 systems'),
                (3, 'Moderate integration with 3-5 systems'),
                (4, 'Complex integration with 6-10 systems'),
                (5, 'Highly complex integration with 10+ systems'),
            ]),
            ('SR-03', 'Revenue Impact', 50.0, [
                (1, 'No direct revenue impact'),
                (2, 'Minor revenue impact (< $100K annually)'),
                (3, 'Moderate revenue impact ($100K - $500K annually)'),
                (4, 'Significant revenue impact ($500K - $2M annually)'),
                (5, 'Major revenue impact (>$2M annually)'),
            ]),
            ('SR-03', 'Cost Savings', 50.0, [
                (1, 'No cost savings identified'),
                (2, 'Minor cost savings (< $50K annually)'),
                (3, 'Moderate cost savings ($50K - $200K annually)'),
                (4, 'Significant cost savings ($200K - $1M annually)'),
                (5, 'Major cost savings (>$1M annually)'),
            ]),
            ('SR-04', 'Regulatory Risk', 50.0, [
                (1, 'No regulatory implications'),
                (2, 'Minor regulatory considerations'),
                (3, 'Moderate regulatory requirements'),
                (4, 'Significant regulatory compliance needed'),
                (5, 'Critical regulatory requirement with high penalties'),
            ]),
            ('SR-04', 'Operational Risk', 50.0, [
                (1, 'Minimal operational risk'),
                (2, 'Low operational risk with mitigation plans'),
                (3, 'Moderate operational risk'),
                (4, 'High operational risk requiring extensive controls'),
                (5, 'Critical operational risk with potential business disruption'),
            ]),
            ('SR-05', 'Team Size', 40.0, [
                (1, 'Small team (1-3 FTE)'),
                (2, 'Medium team (4-7 FTE)'),
                (3, 'Large team (8-15 FTE)'),
                (4, 'Very large team (16-25 FTE)'),
                (5, 'Enterprise team (>25 FTE)'),
            ]),
            ('SR-05', 'Budget Requirements', 60.0, [
                (1, 'Low budget (< $100K)'),
                (2, 'Medium budget ($100K - $500K)'),
                (3, 'High budget ($500K - $2M)'),
                (4, 'Very high budget ($2M - $5M)'),
                (5, 'Enterprise budget (>$5M)'),
            ]),
        ]

        for rule_id, sub_name, sub_weight, rubrics in sub_items_data:
            rule = rule_map[rule_id]
            si = ScoringRuleSubItem(
                rule_id=rule.id,
                name=sub_name,
                sub_weight=sub_weight,
            )
            db.add(si)
            db.commit()
            db.refresh(si)
            for level, desc in rubrics:
                db.add(ScoringRubric(sub_item_id=si.id, score_level=level, description=desc))
            db.commit()

    # Seed Audit Logs
    if db.query(AuditLog).count() == 0:
        audit_data = [
            ('2024-01-15 09:23', 'admin_001', 'Ticket Created', 'ticket', 'T-2024-001', 'Created via API'),
            ('2024-01-15 10:45', 'admin_001', 'Ticket Confirmed', 'ticket', 'T-2024-001', 'Score: 85.5'),
            ('2024-01-16 14:30', 'admin_002', 'SVS Updated', 'svs', 'SVS-001', 'Priority changed to HIGH'),
            ('2024-01-17 11:15', 'admin_001', 'User Created', 'user', 'U-005', 'New submitter: Eva Liu'),
            ('2024-01-18 16:20', 'admin_002', 'Scoring Rule Modified', 'scoring_rule', 'SR-03', 'Weight adjusted to 25%'),
        ]
        for ts, uid, action, obj_type, obj_id, details in audit_data:
            db.add(AuditLog(timestamp=ts, user_id=uid, action=action,
                            object_type=obj_type, object_id=obj_id, details=details))
        db.commit()

    # Seed API Logs
    if db.query(ApiLog).count() == 0:
        api_data = [
            ('2024-01-15 09:20:30', 'Alice Chen', 'Cross-Border Payments', 'GET /api/score', '85.5', '200'),
            ('2024-01-15 10:42:15', 'Bob Wang', 'AI Fraud Detection', 'POST /api/confirm', '92.0', '200'),
            ('2024-01-16 08:15:00', 'Carol Li', 'Mobile Banking', 'GET /api/score', '78.0', '200'),
            ('2024-01-16 14:25:30', 'David Zhang', 'Data Lake', 'GET /api/score', '65.5', '200'),
            ('2024-01-17 11:10:45', 'Eva Liu', 'Regulatory Reporting', 'GET /api/score', '72.0', '200'),
            ('2024-01-17 15:30:20', 'Alice Chen', 'Cross-Border Payments', 'POST /api/confirm', '85.5', '200'),
            ('2024-01-18 09:00:00', 'Bob Wang', 'AI Fraud Detection', 'GET /api/score', '88.5', '200'),
            ('2024-01-18 16:15:10', 'David Zhang', 'Data Lake', 'POST /api/confirm', '65.5', '200'),
        ]
        for ts, user, project, action, score, status in api_data:
            db.add(ApiLog(timestamp=ts, user=user, project=project, action=action,
                          score=score, status=status))
        db.commit()

    return {"status": "ok", "message": "Database seeded"}
