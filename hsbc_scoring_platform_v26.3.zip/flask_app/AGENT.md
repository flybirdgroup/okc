# HSBC Project Scoring — Agent Reference

## Architecture

Two-service Python FastAPI system. Zero JavaScript — pure server-side rendering.

```
                  HTTP (no key)           HTTP + API Key
Browser ──────► Biz Frontend :5001 ──────────► Admin :5000 ─────► SQLite
                (Jinja2 templates)           (API + Dashboard)     (single .db)
```

| Service | Port | Role |
|---------|------|------|
| **Admin** | 5000 | Scoring engine, management dashboard, API, SQLite database |
| **Biz Frontend** | 5001 | Project submission page, AI Review, score display |

---

## File Index

### Admin Backend

| File | Lines | Purpose |
|------|-------|---------|
| `main.py` | ~1000 | Admin: API endpoints, dashboard routes, scoring engine with 3-layer fallback |
| `models.py` | 256 | 8 SQLAlchemy tables |
| `database.py` | 32 | SQLAlchemy engine + session factory |
| `schemas.py` | ~200 | Pydantic request/response models |

### Admin Frontend (Dashboard)

| Template | Purpose |
|----------|---------|
| `templates/base.html` | Base layout with navigation sidebar |
| `templates/dashboard.html` | KPI cards + bar chart + donut chart + recent tables |
| `templates/scoring_rules.html` | Scoring rules config: matrix table + 5 category cards |
| `templates/tickets.html` | Ticket list with filters, search, status badges |
| `templates/users.html` | User management table |
| `templates/svs.html` | SVS (Strategic Value Stream) list |
| `templates/scoring_logs.html` | Scoring request logs (paginated) |
| `templates/api_logs.html` | API call logs |
| `templates/audit_logs.html` | Audit trail table |

### Business Frontend

| File | Lines | Purpose |
|------|-------|---------|
| `biz_app.py` | ~200 | Biz logic: `/review`, `/apply`, `/score`, `/confirm`, AI Review engine, Admin API proxy |
| `templates/biz_scoring.html` | ~250 | Main scoring page: left form panel + right score panel |

### Config

| File | Purpose |
|------|---------|
| `.env` | Environment variables (SECRET_KEY, DATABASE_URL, API_KEY, ADMIN_API_URL, SHOW_SCORE) |
| `start.sh` | Start Admin: `uvicorn main:app --host 0.0.0.0 --port 5000` |
| `start_biz.sh` | Start Biz Frontend: `uvicorn biz_app:app --host 0.0.0.0 --port 5001` |
| `requirements.txt` | Python dependencies |

---

## Data Model

```
svs (Strategic Value Streams)
 └── tickets
      └── scoring_request_logs

scoring_rules (5 categories)
 └── scoring_rule_sub_items (10 sub-items)
      └── scoring_rubrics (score 1-5 descriptions)

users, audit_logs, api_logs (independent)
```

**Scoring Rules:**
- 5 Categories × 2 Subcategories = 10 dimensions
- Weights: Strategic Alignment 20%, Technical Complexity 15%, Business Value 25%, Risk Assessment 15%, Resource Requirements 25%
- Multiplier formula: `(Category% × Subcategory%) / 500`

---

## Admin API (:5000)

### Public API (requires X-API-Key header)
| Method | Path | Purpose |
|--------|------|---------|
| POST | `/api/score` | Score project (3-layer fallback: Agent→LLM→Zero) |
| POST | `/api/confirm` | Lock score to ticket, mark CONFIRMED |
| GET | `/api/score/{request_id}` | Query score result |

### Internal Management (no API Key)
| Method | Path | Purpose |
|--------|------|---------|
| GET | `/api/dashboard` | Dashboard KPI data |
| CRUD | `/api/svs` | SVS management |
| CRUD | `/api/tickets` | Ticket management |
| CRUD | `/api/scoring-rules` | Scoring rules CRUD |
| CRUD | `/api/users` | User management |
| GET | `/api/scoring-logs` | Scoring logs (paginated) |
| GET | `/api/audit-logs` | Audit trail |

---

## Business Frontend API (:5001)

| Method | Path | Purpose |
|--------|------|---------|
| GET | `/` | Render main page (form + score panel) |
| POST | `/review` | AI Review: analyze 10 dimensions against description |
| POST | `/apply` | Add one dimension's example to description |
| POST | `/apply-all` | Add all missing dimensions' examples |
| POST | `/score` | Proxy to Admin `/api/score` |
| POST | `/confirm` | Proxy to Admin `/api/confirm`, clear session |
| POST | `/reset` | Clear all session data |
| GET | `/health` | Health check |

---

## AI Review Integration

### Current (Development)
`ai_review()` in `biz_app.py` — keyword matching against 10 DIMS entries.

### Production
Use `ai_review_llm()` (already written, commented out in `biz_app.py`):

```python
# In biz_app.py do_review():
# Replace:
s['review'] = ai_review(description)
# With:
s['review'] = await ai_review_llm(description)
```

Prerequisites:
```bash
pip install openai
export OPENAI_API_KEY="sk-..."
```

The prompt template and JSON output schema are fully defined in `ai_review_llm()`. Returns `[(dim_id, status, dim_info), ...]` where status is `ok`/`weak`/`missing`. Swap OpenAI client with Azure OpenAI, Claude, or any provider.

---

## Score Display Config

| `SHOW_SCORE` env var | Right Panel Shows |
|----------------------|------------------|
| `false` (default) | Band only with icons: 🏆 HIGH / 📊 MODERATE / 🔧 LOW |
| `true` | Raw number: 82.5/100 + 10-item evidence breakdown |

| Band | Range | Icon | Color |
|------|-------|------|-------|
| HIGH | 80-100 | 🏆 | Green |
| MEDIUM | 60-80 | 📊 | Orange |
| LOW | 0-60 | 🔧 | Red |

---

## Common Bugs & Patterns

| Trap | Wrong | Correct |
|------|-------|---------|
| Falsy 0.0 | `if self.score:` | `if self.score is not None:` |
| Session > 4KB | Store list of full dicts | Store compact `id:status` dict |
| Jinja2 dict access | `obj.key` | `obj['key']` |
| Multi-line f-string | `f"...\n..."` | Split into separate `+` statements |
| Confirm query | `status == 'completed'` | `status.in_(['completed', 'fallback'])` |
| Template `disabled` | Use `style="opacity:0.5"` | Use `disabled` attribute directly |

---

## Files to Edit by Task

| Task | File(s) |
|------|---------|
| Change AI Review logic / connect LLM | `biz_app.py` |
| Change business UI layout/colors | `templates/biz_scoring.html` |
| Change scoring engine / fallback | `main.py` |
| Add DB table/column | `models.py` |
| Change admin dashboard | `templates/dashboard.html` |
| Change scoring rules display | `templates/scoring_rules.html` |
| Change ticket management | `templates/tickets.html` + `main.py` |
| Add new API endpoint | `main.py` (Admin) or `biz_app.py` (Biz) |
