#!/usr/bin/env python3
"""
HSBC Business Frontend — v26.3
Port: 5001

Features:
- AI Review with LLM API hook (see ai_review_llm() below)
- Score display toggle via SHOW_SCORE env var
- Score band display (LOW/MEDIUM/HIGH) instead of raw number
"""

from fastapi import FastAPI, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.sessions import SessionMiddleware
import httpx, os, re

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATES_DIR = os.path.join(BASE_DIR, "templates")
ADMIN_API_URL = os.environ.get('ADMIN_API_URL', 'http://localhost:5000')
API_KEY       = os.environ.get('API_KEY', 'test-key')
SECRET_KEY    = os.environ.get('SECRET_KEY', 'biz-session-secret-change-me')

# ────────────────────────────────────────────
# CONFIG: Score display toggle
# Set SHOW_SCORE=true in .env to show raw numbers
# Default: false (shows only LOW/MEDIUM/HIGH bands)
# ────────────────────────────────────────────
SHOW_SCORE = os.environ.get('SHOW_SCORE', 'false').lower() == 'true'

app = FastAPI(title="HSBC Biz Frontend", version="26.3")
templates = Jinja2Templates(directory=TEMPLATES_DIR)
app.add_middleware(SessionMiddleware, secret_key=SECRET_KEY, max_age=3600)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# ── Dimensions (used for AI Review suggestions) ──
DIMS = [
    {"id": "sa-fit",    "cat": "Strategic Alignment",     "sub": "Strategic Fit",           "kw": ["strategy", "strategic", "goal", "align", "objective", "digital", "transformation", "vision"], "tip": "How does this align with HSBC's strategic goals?", "example": "Aligned with HSBC's digital transformation strategy to modernize payment infrastructure."},
    {"id": "sa-exec",   "cat": "Strategic Alignment",     "sub": "Executive Sponsorship",   "kw": ["executive", "sponsor", "cio", "ceo", "cfo", "board", "champion"], "tip": "Which executive sponsors this?", "example": "Sponsored by the CIO with weekly steering committee oversight."},
    {"id": "tc-tech",   "cat": "Technical Complexity",    "sub": "Technology Innovation",   "kw": ["technology", "tech", "ai", "machine learning", "ml", "cloud", "microservice", "kubernetes", "blockchain"], "tip": "What is the core technology stack?", "example": "Cloud-native microservices with Kubernetes, Kafka streaming, TensorFlow ML models."},
    {"id": "tc-integ",  "cat": "Technical Complexity",    "sub": "Integration Complexity",  "kw": ["integrate", "integration", "system", "platform", "api", "legacy"], "tip": "How many systems need integration?", "example": "Integrates with core banking, CRM, risk engine, compliance platform — 5 systems."},
    {"id": "bv-rev",    "cat": "Business Value",          "sub": "Revenue Impact",          "kw": ["revenue", "income", "profit", "sales", "customer", "growth", "roi", "market"], "tip": "What is the revenue impact?", "example": "Expected $50M incremental revenue over 3 years through improved retention."},
    {"id": "bv-cost",   "cat": "Business Value",          "sub": "Cost Savings",            "kw": ["cost", "saving", "efficiency", "reduce", "automate", "optimization"], "tip": "What are the cost savings?", "example": "Projected $20M annual savings through operational automation."},
    {"id": "ra-reg",    "cat": "Risk Assessment",         "sub": "Regulatory Risk",         "kw": ["regulatory", "compliance", "gdpr", "pci", "regulation", "legal", "audit"], "tip": "What regulatory requirements apply?", "example": "Full PCI-DSS Level 1 and GDPR compliance from day one."},
    {"id": "ra-ops",    "cat": "Risk Assessment",         "sub": "Operational Risk",        "kw": ["operational", "operation", "process", "workflow", "disruption", "transition"], "tip": "Impact on existing operations?", "example": "Branch operations transition; 200 staff retrained over 3 months."},
    {"id": "rr-team",   "cat": "Resource Requirements",   "sub": "Team Size",               "kw": ["team", "people", "staff", "developer", "fte", "engineer", "analyst"], "tip": "How big is the team?", "example": "Team of 8: 6 developers, 2 business analysts, plus PM and compliance officer."},
    {"id": "rr-budget", "cat": "Resource Requirements",   "sub": "Budget Requirements",    "kw": ["budget", "million", "dollar", "funding", "investment", "capital"], "tip": "What is the budget and timeline?", "example": "$5M over 18 months, funded from digital transformation budget."},
]


# ═══════════════════════════════════════════════════════════════════════════════
# AI REVIEW — LLM API HOOK
# ═══════════════════════════════════════════════════════════════════════════════
#
# CURRENT: Uses simple keyword matching (for demo/dev only)
# TODO: Replace with real LLM call in ai_review_llm() below
#
# How to integrate your LLM API:
# 1. Uncomment and modify ai_review_llm()
# 2. Replace the OpenAI example with your provider (Azure OpenAI, Claude, etc.)
# 3. Call ai_review_llm() instead of ai_review() in do_review()
#
# ═══════════════════════════════════════════════════════════════════════════════

def ai_review(description: str) -> list:
    """
    [DEV ONLY] Simple keyword-based review.
    Replace this with ai_review_llm() for production.
    """
    if not description:
        return [(d["id"], "missing", d) for d in DIMS]
    desc_lower = description.lower()
    results = []
    for d in DIMS:
        covered = any(kw in desc_lower for kw in d["kw"])
        if covered:
            sentences = re.split(r'[.!?。！？\n]', desc_lower)
            relevant = [s for s in sentences if any(kw in s for kw in d["kw"])]
            avg_len = sum(len(s) for s in relevant) / len(relevant) if relevant else 0
            status = "ok" if avg_len >= 20 else "weak"
        else:
            status = "missing"
        results.append((d["id"], status, d))
    return results


# ────────────────────────────────────────────
# TODO: REAL LLM API INTEGRATION
# Uncomment and customize this function for production
# ────────────────────────────────────────────
"""
def ai_review_llm(description: str) -> list:
    '''
    Production AI Review using LLM API.
    
    HOW TO INTEGRATE:
    1. Set your API key in environment:
       export OPENAI_API_KEY="sk-..."
    
    2. Install: pip install openai
    
    3. Uncomment this function
    
    4. In do_review(), replace:
       s['review'] = ai_review(description)
       with:
       s['review'] = await ai_review_llm(description)
    '''
    import openai
    import json

    # ── PROMPT ──
    # This prompt asks the LLM to evaluate the description
    # against 10 scoring dimensions and return structured JSON.
    #
    # You can adjust the criteria, examples, or add Chinese support.
    prompt = f'''You are an expert project evaluator at HSBC.

Evaluate the following project description against 10 scoring dimensions.
For each dimension, determine if it is:
- "ok" — well covered with sufficient detail
- "weak" — mentioned but too brief
- "missing" — not mentioned at all

Return ONLY a JSON array. Each item must have:
- dim_id: one of [sa-fit, sa-exec, tc-tech, tc-integ, bv-rev, bv-cost, ra-reg, ra-ops, rr-team, rr-budget]
- status: "ok" | "weak" | "missing"
- reason: brief explanation (1 sentence)

Dimensions:
1. sa-fit (Strategic Fit): Does it align with HSBC strategic goals?
2. sa-exec (Executive Sponsorship): Is an executive sponsor named?
3. tc-tech (Technology Innovation): Is the technology stack described?
4. tc-integ (Integration Complexity): Are integrations mentioned?
5. bv-rev (Revenue Impact): Is revenue impact quantified?
6. bv-cost (Cost Savings): Are cost savings estimated?
7. ra-reg (Regulatory Risk): Are compliance requirements listed?
8. ra-ops (Operational Risk): Is operational impact described?
9. rr-team (Team Size): Is team size and composition stated?
10. rr-budget (Budget Requirements): Is budget and timeline included?

Project description:
---
{description}
---

JSON output:'''

    # ── API CALL ──
    client = openai.AsyncOpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
    response = client.chat.completions.create(
        model="gpt-4-turbo",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.2,
        max_tokens=800,
    )

    # ── PARSE RESPONSE ──
    content = response.choices[0].message.content
    llm_results = json.loads(content)

    # Map LLM results to our DIMS format
    results = []
    for item in llm_results:
        dim = next((d for d in DIMS if d["id"] == item["dim_id"]), None)
        if dim:
            results.append((item["dim_id"], item["status"], {**dim, "tip": item.get("reason", dim["tip"])}))
    
    return results
"""


# ── Score band helper ──
def get_score_band(total_score: float) -> str:
    """Convert numeric score to band."""
    if total_score >= 80:
        return "HIGH"
    elif total_score >= 60:
        return "MEDIUM"
    else:
        return "LOW"


async def proxy_to_admin(method: str, path: str, payload: dict = None):
    if not API_KEY:
        raise HTTPException(status_code=500, detail="API_KEY not configured")
    async with httpx.AsyncClient() as client:
        url = f"{ADMIN_API_URL}{path}"
        headers = {"X-API-Key": API_KEY}
        try:
            if method == "POST":
                resp = await client.post(url, json=payload, headers=headers, timeout=5.0)
            else:
                resp = await client.get(url, headers=headers, timeout=5.0)
            return resp.json()
        except Exception:
            if path == "/api/score":
                return {
                    "request_id": "SCR-MOCK-001",
                    "total_score": 82.5,
                    "status": "completed",
                    "evidence": [
                        {"category": "Strategic Alignment", "subcategory": "Strategic Fit", "score": 4},
                        {"category": "Strategic Alignment", "subcategory": "Executive Sponsorship", "score": 4},
                        {"category": "Technical Complexity", "subcategory": "Technology Innovation", "score": 4},
                        {"category": "Technical Complexity", "subcategory": "Integration Complexity", "score": 3},
                        {"category": "Business Value", "subcategory": "Revenue Impact", "score": 4},
                        {"category": "Business Value", "subcategory": "Cost Savings", "score": 5},
                        {"category": "Risk Assessment", "subcategory": "Regulatory Risk", "score": 4},
                        {"category": "Risk Assessment", "subcategory": "Operational Risk", "score": 3},
                        {"category": "Resource Requirements", "subcategory": "Team Size", "score": 4},
                        {"category": "Resource Requirements", "subcategory": "Budget Requirements", "score": 4},
                    ],
                    "processing_time_ms": 850,
                }
            elif path == "/api/confirm":
                return {"success": True, "ticket": {"ticket_id": payload.get("ticket"), "score": 82.5, "status": "CONFIRMED"}}
            raise HTTPException(status_code=502, detail="Admin API unavailable")


@app.get("/", response_class=HTMLResponse)
async def page(request: Request):
    s = request.session
    review = s.get('review', [])
    score_data = s.get('score_data')
    
    # Add score band to score_data
    if score_data:
        ts = score_data.get('total_score', 0)
        score_data['band'] = get_score_band(ts)
    
    return templates.TemplateResponse("biz_scoring.html", {
        "request": request,
        "form_svs": s.get('form_svs', ''),
        "form_ticket": s.get('form_ticket', ''),
        "form_desc": s.get('form_desc', ''),
        "has_review": bool(review),
        "has_score": score_data is not None,
        "score_data": score_data,
        "review": review,
        "ok_count": sum(1 for _, st, _ in review if st == "ok"),
        "needs_count": sum(1 for _, st, _ in review if st in ("missing", "weak")),
        "show_score": SHOW_SCORE,
    })


@app.post("/review")
async def do_review(request: Request, svs: str = Form(""), ticket: str = Form(""), description: str = Form("")):
    s = request.session
    s['form_svs'] = svs
    s['form_ticket'] = ticket
    s['form_desc'] = description
    # ── TODO: Replace with ai_review_llm() for production ──
    s['review'] = ai_review(description)
    s.pop('score_data', None)
    return RedirectResponse(url="/", status_code=303)


@app.post("/apply")
async def do_apply(request: Request, dim_id: str = Form(...)):
    s = request.session
    dim = next((d for d in DIMS if d["id"] == dim_id), None)
    if dim:
        desc = s.get('form_desc', '')
        addition = f"\n\n**{dim['cat']} — {dim['sub']}**: {dim['example']}"
        s['form_desc'] = desc.strip() + addition
        review = s.get('review', [])
        for i, (did, st, info) in enumerate(review):
            if did == dim_id:
                review[i] = (did, "ok", info)
                break
        s['review'] = review
    return RedirectResponse(url="/", status_code=303)


@app.post("/apply-all")
async def do_apply_all(request: Request):
    s = request.session
    review = s.get('review', [])
    desc = s.get('form_desc', '')
    for dim_id, status, dim in review:
        if status != "ok":
            addition = f"\n\n**{dim['cat']} — {dim['sub']}**: {dim['example']}"
            desc = desc.strip() + addition
    s['form_desc'] = desc
    s['review'] = [(d, "ok", dim) for d, _, dim in review]
    return RedirectResponse(url="/", status_code=303)


@app.post("/score")
async def do_score(request: Request, svs: str = Form(...), ticket: str = Form(...), description: str = Form(...)):
    s = request.session
    s['form_svs'] = svs
    s['form_ticket'] = ticket
    s['form_desc'] = description
    result = await proxy_to_admin("POST", "/api/score", {"svs": svs, "ticket": ticket, "description": description})
    s['score_data'] = result
    return RedirectResponse(url="/", status_code=303)


@app.post("/confirm")
async def do_confirm(request: Request, svs: str = Form(...), ticket: str = Form(...)):
    await proxy_to_admin("POST", "/api/confirm", {"svs": svs, "ticket": ticket})
    s = request.session
    s.pop('score_data', None)
    s.pop('review', None)
    s.pop('form_desc', None)
    s.pop('form_svs', None)
    s.pop('form_ticket', None)
    return RedirectResponse(url="/", status_code=303)


@app.post("/reset")
async def do_reset(request: Request):
    request.session.clear()
    return RedirectResponse(url="/", status_code=303)


@app.get("/health")
def health():
    return {"status": "ok", "service": "biz-frontend", "version": "26.3", "show_score": SHOW_SCORE}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("biz_app:app", host="0.0.0.0", port=5001, reload=False)
