# HSBC Project Scoring Platform

> Version: 26.3
> Stack: Python + FastAPI + Jinja2 + SQLite
> Architecture: Admin (:5000) + Business Frontend (:5001)

---

## Quick Start

```bash
pip install -r requirements.txt
cd flask_app

# Terminal 1: Admin backend
cat > .env << 'EOF'
DATABASE_URL=sqlite:///hsbc_admin.db
SECRET_KEY=change-me
API_KEY=your-api-key
FLASK_ENV=development
EOF
bash start.sh        # Runs on :5000

# Terminal 2: Business frontend
cat > .env << 'EOF'
SECRET_KEY=biz-change-me
API_KEY=your-api-key
ADMIN_API_URL=http://localhost:5000
SHOW_SCORE=false     # Set true to show raw numbers
EOF
bash start_biz.sh    # Runs on :5001
```

---

## Architecture

```
Browser -----> Biz Frontend (:5001) -----> Admin (:5000) -----> SQLite
               (Jinja2 SSR)               (API + Dashboard)      (single .db)
```

| Service | Port | Role |
|---------|------|------|
| Admin | 5000 | Scoring engine, REST API, management dashboard, database |
| Business Frontend | 5001 | Project submission, AI Review, score display |

**Key principles:**
- Pure server-side rendering (zero JavaScript in browser)
- Session-based state management (signed cookies)
- API Key never exposed to browser (proxied through Biz Frontend)

---

## Business Frontend Flow

```
Empty Form --> AI Review --> Apply Suggestions --> AI Analyze --> Score --> Confirm
```

| Step | Action | Result |
|------|--------|--------|
| 1 | Fill in SVS + Ticket + Description | Form ready |
| 2 | Click "AI Review Description" | 10-dimension analysis, suggestions displayed |
| 3 | Click "+ Add" per item or "Apply All" | Description auto-enhanced with examples |
| 4 | Click "AI Analyze Project" | Score returned from Admin API |
| 5 | Click "Confirm & Submit" | Score locked to ticket, Admin logs updated |

---

## Score Display

Controlled by `SHOW_SCORE` environment variable:

| `SHOW_SCORE` | Right Panel Shows |
|-------------|------------------|
| `false` (default) | Band only: 🏆 HIGH / 📊 MODERATE / 🔧 LOW |
| `true` | Raw number: 82.5/100 + 10-item evidence breakdown |

**Score bands:**
| Band | Range | Icon | Color | Feedback |
|------|-------|------|-------|----------|
| HIGH | 80-100 | 🏆 | Green | Strong across most dimensions |
| MEDIUM | 60-80 | 📊 | Orange | Good coverage with room to improve |
| LOW | 0-60 | 🔧 | Red | Needs more detail |

---

## AI Review Integration

### Development (Current)
Keyword-based matching in `biz_app.py::ai_review()`.

### Production
Replace with real LLM by using `ai_review_llm()` in `biz_app.py`:

```python
# 1. Set API key
export OPENAI_API_KEY="sk-..."

# 2. Install
pip install openai

# 3. In do_review(), replace:
s['review'] = ai_review(description)
# With:
s['review'] = await ai_review_llm(description)
```

A complete prompt template and JSON output format are already defined in `ai_review_llm()`. You can swap the OpenAI client with Azure OpenAI, Claude, or any other LLM provider.

---

## API Endpoints

### Admin (:5000)

**Public API (requires X-API-Key header):**
| Method | Path | Purpose |
|--------|------|---------|
| POST | `/api/score` | Score a project (3-layer fallback) |
| POST | `/api/confirm` | Lock score to ticket |
| GET | `/api/score/{request_id}` | Query score result |

**Internal Management:**
| Method | Path | Purpose |
|--------|------|---------|
| GET | `/api/dashboard` | Dashboard KPI data |
| CRUD | `/api/svs` | SVS management |
| CRUD | `/api/tickets` | Ticket management |
| CRUD | `/api/scoring-rules` | Scoring rules CRUD |
| CRUD | `/api/users` | User management |
| GET | `/api/scoring-logs` | Scoring request logs (paginated) |
| GET | `/api/audit-logs` | Audit trail |

**Scoring Fallback (3 layers):**
```
Layer 1: Agent API (3 retries)     --> status="completed" if success
Layer 2: Direct LLM (1 call)       --> status="completed" if success
Layer 3: Zero-score fallback       --> status="fallback", score=0
```

### Business Frontend (:5001)
| Method | Path | Purpose |
|--------|------|---------|
| GET | `/` | Main scoring page |
| POST | `/review` | AI Review analysis |
| POST | `/apply` | Apply single suggestion to description |
| POST | `/apply-all` | Apply all missing suggestions |
| POST | `/score` | Score project via Admin API |
| POST | `/confirm` | Confirm and lock score |
| POST | `/reset` | Clear form and session |
| GET | `/health` | Health check |

---

## File Structure

```
flask_app/
├── main.py              # Admin backend (:5000) - API, dashboard, scoring engine
├── biz_app.py           # Business frontend (:5001) - AI Review, score display
├── models.py            # SQLAlchemy models (8 tables)
├── database.py          # Database connection and session
├── schemas.py           # Pydantic request/response schemas
├── templates/
│   ├── base.html            # Admin base layout
│   ├── dashboard.html       # Admin dashboard with charts
│   ├── scoring_rules.html   # Scoring rules configuration
│   ├── tickets.html         # Ticket management
│   ├── users.html           # User management
│   ├── svs.html             # SVS management
│   ├── scoring_logs.html    # Scoring request logs
│   ├── api_logs.html        # API call logs
│   ├── audit_logs.html      # Audit trail
│   └── biz_scoring.html     # Business frontend scoring page
├── .env                 # Environment variables
├── start.sh             # Start Admin service
├── start_biz.sh         # Start Business Frontend service
├── requirements.txt     # Python dependencies
├── README.md            # This file
└── AGENT.md             # Quick reference for AI agents
```

---

## Key Design Decisions

1. **Pure server-side rendering** — Zero JavaScript in the browser; all state managed server-side via session cookies
2. **Dual-service architecture** — Admin (:5000) for internal use, Biz Frontend (:5001) for public access
3. **API Key hidden** — Browser never sees the Admin API Key; Biz Frontend proxies all requests
4. **Score bands by default** — Raw numeric scores hidden unless `SHOW_SCORE=true` is set
5. **Pluggable AI Review** — LLM integration ready with keyword fallback for development

---

## Known Bug Patterns

| Pattern | Wrong | Correct |
|---------|-------|---------|
| Falsy 0.0 | `if self.score:` | `if self.score is not None:` |
| Session overflow | Store full dict objects | Store compact `id:status` dicts |
| Jinja2 dict access | `obj.key` | `obj['key']` |
| Multi-line f-string | `f"...\n..."` | Split into separate statements |
| Confirm query | `status == 'completed'` | `status.in_(['completed', 'fallback'])` |
