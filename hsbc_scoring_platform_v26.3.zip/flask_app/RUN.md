# How to Run

## 1. Install Dependencies

```bash
pip install -r requirements.txt
```

Required: Python 3.9+

## 2. Configure Environment

```bash
cp .env.example .env
# Edit .env with your keys
```

## 3. Start Both Services

### Terminal 1 — Admin Backend (:5000)

```bash
cd flask_app
bash start.sh
```

Admin runs on http://localhost:5000

### Terminal 2 — Business Frontend (:5001)

```bash
cd flask_app
bash start_biz.sh
```

Business Frontend runs on http://localhost:5001

## 4. Open in Browser

| URL | What you see |
|-----|-------------|
| http://localhost:5001 | Project scoring page (fill form, AI Review, Score, Confirm) |
| http://localhost:5000 | Admin dashboard (tickets, scoring rules, logs) |

## 5. First Time — Initialize Database

Admin auto-creates the SQLite database on first run. Scoring rules are seeded automatically.

## Quick Test

1. Open http://localhost:5001
2. Fill SVS: `SVS-001`, Ticket: `TICKET-001`
3. Write a short description: "We want AI fraud detection"
4. Click "AI Review Description" — see suggestions
5. Click "Apply All" — description gets enhanced
6. Click "AI Analyze Project" — score appears on right
7. Click "Confirm & Submit" — score locked

## Production Notes

- **Admin** should bind to internal IP only (`--host 127.0.0.1`)
- **Biz Frontend** can bind to public IP (`--host 0.0.0.0`)
- Use Nginx reverse proxy in production
- Replace mock scoring in `main.py` with real LLM API calls
- Replace keyword AI Review in `biz_app.py` with `ai_review_llm()`
- Set `SHOW_SCORE=false` to hide raw numbers from users
