import { useState } from 'react';
import { Search, ChevronDown, Filter } from 'lucide-react';
import { auditLogsData } from '@/data/mockData';

export default function AuditLogs() {
  const [searchQuery, setSearchQuery] = useState('');
  const [actionType, setActionType] = useState('');
  const [timeRange, setTimeRange] = useState('');

  const filteredLogs = auditLogsData.filter((log) => {
    const matchesSearch =
      searchQuery === '' ||
      log.userId.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesAction =
      actionType === '' || actionType === 'All' || log.action.includes(actionType);
    return matchesSearch && matchesAction;
  });

  return (
    <div className="p-8 max-w-[1400px]">
      {/* Page Title */}
      <div className="mb-6">
        <h1 className="text-[32px] font-bold text-[var(--hsbc-text-primary)] tracking-tight">
          Admin Backend: Audit Logs
        </h1>
      </div>

      {/* Filters Bar */}
      <div className="hsbc-card p-4 mb-5">
        <div className="flex items-center gap-4 flex-wrap">
          {/* Search */}
          <div className="relative flex-1 max-w-xs">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--hsbc-text-subtle)]" />
            <input
              type="text"
              placeholder="Search by User..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="hsbc-input w-full pl-10"
            />
          </div>

          {/* Action Type */}
          <div className="relative">
            <select
              value={actionType}
              onChange={(e) => setActionType(e.target.value)}
              className="hsbc-select pr-10 appearance-none min-w-[160px]"
            >
              <option value="">Select Action Type</option>
              <option value="All">All Actions</option>
              <option value="Project">Project Actions</option>
              <option value="Score">Score Actions</option>
              <option value="Rule">Rule Actions</option>
              <option value="User">User Actions</option>
            </select>
            <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--hsbc-text-muted)] pointer-events-none" />
          </div>

          {/* Time Range */}
          <div className="relative">
            <select
              value={timeRange}
              onChange={(e) => setTimeRange(e.target.value)}
              className="hsbc-select pr-10 appearance-none min-w-[140px]"
            >
              <option value="">Time Range</option>
              <option value="today">Today</option>
              <option value="week">This Week</option>
              <option value="month">This Month</option>
              <option value="quarter">This Quarter</option>
            </select>
            <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--hsbc-text-muted)] pointer-events-none" />
          </div>

          <button className="hsbc-btn-primary px-5 py-2.5 flex items-center gap-2 text-sm">
            <Filter className="w-4 h-4" />
            Apply Filters
          </button>
        </div>
      </div>

      {/* Logs Table */}
      <div className="hsbc-card">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-[var(--hsbc-bg-main)]">
                <th className="hsbc-table-header">TIMESTAMP</th>
                <th className="hsbc-table-header">USER ID</th>
                <th className="hsbc-table-header">ACTION</th>
                <th className="hsbc-table-header">OBJECT</th>
              </tr>
            </thead>
            <tbody>
              {filteredLogs.map((log, index) => (
                <tr
                  key={index}
                  className="hover:bg-[var(--hsbc-bg-main)] transition-colors"
                >
                  <td className="hsbc-table-cell text-[var(--hsbc-text-muted)]">
                    {log.timestamp}
                  </td>
                  <td className="hsbc-table-cell font-medium text-[var(--hsbc-text-primary)]">
                    {log.userId}
                  </td>
                  <td className="hsbc-table-cell">
                    <span className="text-sm text-[var(--hsbc-text-secondary)]">
                      {log.action}
                    </span>
                  </td>
                  <td className="hsbc-table-cell text-[var(--hsbc-blue)] font-medium">
                    {log.object}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
