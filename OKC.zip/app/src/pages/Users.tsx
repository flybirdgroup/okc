import { useState } from 'react';
import { Plus, Pencil, UserX, UserCheck } from 'lucide-react';
import { usersData } from '@/data/mockData';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

export default function Users() {
  const [users, setUsers] = useState(usersData);
  const [showAddDialog, setShowAddDialog] = useState(false);

  const toggleStatus = (userId: number) => {
    setUsers((prev) =>
      prev.map((u) =>
        u.id === userId
          ? { ...u, status: u.status === 'Active' ? 'Inactive' : 'Active' }
          : u
      )
    );
  };

  return (
    <div className="p-8 max-w-[1400px]">
      {/* Page Title & Add Button */}
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-[32px] font-bold text-[var(--hsbc-text-primary)] tracking-tight">
          Admin Backend: Users
        </h1>
        <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
          <DialogTrigger asChild>
            <button className="hsbc-btn-primary px-5 py-2.5 flex items-center gap-2 text-sm">
              <Plus className="w-4 h-4" />
              Add User
            </button>
          </DialogTrigger>
          <DialogContent className="bg-[var(--hsbc-bg-card)] border-[var(--hsbc-border)]">
            <DialogHeader>
              <DialogTitle className="text-[var(--hsbc-text-primary)] text-xl">
                Add New User
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <div>
                <label className="block text-sm font-medium text-[var(--hsbc-text-secondary)] mb-1.5">
                  Username
                </label>
                <input type="text" className="hsbc-input w-full" placeholder="Enter username" />
              </div>
              <div>
                <label className="block text-sm font-medium text-[var(--hsbc-text-secondary)] mb-1.5">
                  Department
                </label>
                <input type="text" className="hsbc-input w-full" placeholder="Enter department" />
              </div>
              <div>
                <label className="block text-sm font-medium text-[var(--hsbc-text-secondary)] mb-1.5">
                  Role
                </label>
                <select className="hsbc-select w-full">
                  <option>Admin</option>
                  <option>Reviewer</option>
                  <option>Submitter</option>
                </select>
              </div>
              <button
                onClick={() => setShowAddDialog(false)}
                className="hsbc-btn-primary w-full py-2.5 mt-2"
              >
                Add User
              </button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Users Table */}
      <div className="hsbc-card">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-[var(--hsbc-bg-main)]">
                <th className="hsbc-table-header">USERNAME</th>
                <th className="hsbc-table-header">DEPARTMENT</th>
                <th className="hsbc-table-header">ROLE</th>
                <th className="hsbc-table-header">STATUS</th>
                <th className="hsbc-table-header">ACTIONS</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr
                  key={user.id}
                  className="hover:bg-[var(--hsbc-bg-main)] transition-colors"
                >
                  <td className="hsbc-table-cell font-medium text-[var(--hsbc-text-primary)]">
                    {user.username}
                  </td>
                  <td className="hsbc-table-cell">{user.department}</td>
                  <td className="hsbc-table-cell">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-md text-xs font-medium bg-[var(--hsbc-blue-light)] text-[var(--hsbc-blue)]">
                      {user.role}
                    </span>
                  </td>
                  <td className="hsbc-table-cell">
                    <span
                      className={`hsbc-status-badge ${
                        user.status === 'Active'
                          ? 'hsbc-status-active'
                          : 'hsbc-status-inactive'
                      }`}
                    >
                      {user.status}
                    </span>
                  </td>
                  <td className="hsbc-table-cell">
                    <div className="flex items-center gap-2">
                      <button className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[var(--hsbc-blue)] hover:bg-[var(--hsbc-blue-light)] rounded-md transition-colors">
                        <Pencil className="w-3 h-3" />
                        Edit
                      </button>
                      <button
                        onClick={() => toggleStatus(user.id)}
                        className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                          user.status === 'Active'
                            ? 'text-[#DC2626] hover:bg-red-50'
                            : 'text-[#16A34A] hover:bg-green-50'
                        }`}
                      >
                        {user.status === 'Active' ? (
                          <>
                            <UserX className="w-3 h-3" />
                            Deactivate
                          </>
                        ) : (
                          <>
                            <UserCheck className="w-3 h-3" />
                            Reactivate
                          </>
                        )}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
