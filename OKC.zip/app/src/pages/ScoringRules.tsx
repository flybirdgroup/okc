import { useState } from 'react';
import { ClipboardList, ChevronDown, ChevronUp, Pencil, Save } from 'lucide-react';
import { scoringRules } from '@/data/mockData';

export default function ScoringRules() {
  const [expandedRule, setExpandedRule] = useState<string | null>('01');
  const [editingRule, setEditingRule] = useState<string | null>(null);

  const toggleExpand = (id: string) => {
    setExpandedRule(expandedRule === id ? null : id);
  };

  return (
    <div className="p-8 max-w-[1400px]">
      {/* Page Title */}
      <div className="mb-8">
        <h1 className="text-[32px] font-bold text-[var(--hsbc-text-primary)] tracking-tight">
          Scoring Rules Configuration
        </h1>
      </div>

      {/* Rules List */}
      <div className="space-y-4">
        {scoringRules.map((rule) => (
          <div key={rule.id} className="hsbc-card overflow-hidden">
            {/* Rule Header */}
            <div
              className="flex items-center justify-between px-6 py-4 cursor-pointer hover:bg-[var(--hsbc-bg-main)]/50 transition-colors"
              onClick={() => toggleExpand(rule.id)}
            >
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-lg bg-[var(--hsbc-red-light)] flex items-center justify-center">
                  <ClipboardList className="w-5 h-5 text-[var(--hsbc-red)]" strokeWidth={1.8} />
                </div>
                <div>
                  <h3 className="text-[16px] font-bold text-[var(--hsbc-text-primary)]">
                    {rule.id}. {rule.title}
                  </h3>
                  <p className="text-sm text-[var(--hsbc-red)] font-semibold mt-0.5">
                    Weight: {rule.weight}%
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setEditingRule(editingRule === rule.id ? null : rule.id);
                  }}
                  className="flex items-center gap-2 px-4 py-2 text-sm font-semibold text-[var(--hsbc-blue)] hover:bg-[var(--hsbc-blue-light)] rounded-lg transition-colors"
                >
                  <Pencil className="w-3.5 h-3.5" />
                  Edit Rule
                </button>
                {expandedRule === rule.id ? (
                  <ChevronUp className="w-5 h-5 text-[var(--hsbc-text-muted)]" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-[var(--hsbc-text-muted)]" />
                )}
              </div>
            </div>

            {/* Expanded Content */}
            {expandedRule === rule.id && (
              <div className="px-6 pb-5 border-t border-[var(--hsbc-border)]">
                <div className="pt-4 space-y-4">
                  {rule.subItems.map((item, index) => (
                    <div
                      key={index}
                      className="bg-[var(--hsbc-bg-main)] rounded-lg p-4"
                    >
                      <h4 className="text-sm font-semibold text-[var(--hsbc-text-primary)] mb-1">
                        Sub-item: {item.name}
                      </h4>
                      <p className="text-sm text-[var(--hsbc-text-muted)]">
                        Criteria: {item.criteria}
                      </p>
                    </div>
                  ))}
                </div>
                {editingRule === rule.id && (
                  <div className="mt-4 flex justify-end">
                    <button
                      onClick={() => setEditingRule(null)}
                      className="hsbc-btn-primary px-6 py-2.5 flex items-center gap-2"
                    >
                      <Save className="w-4 h-4" />
                      Save Changes
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
