import { useState } from 'react';
import {
  FolderOpen,
  AlertTriangle,
  Clock,
  MoreHorizontal,
  BarChart3,
  PieChart,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart as RePieChart,
  Pie,
  Cell,
} from 'recharts';
import {
  kpiData,
  priorityDistribution,
  projectMonitoring,
} from '@/data/mockData';

const kpiCards = [
  {
    title: 'Total Active Projects',
    value: kpiData.totalActiveProjects,
    icon: FolderOpen,
    color: '#DA291C',
    bgIcon: '#FEE2E2',
  },
  {
    title: 'High Priority Items',
    value: kpiData.highPriorityItems,
    icon: AlertTriangle,
    color: '#F59E0B',
    bgIcon: '#FEF3C7',
  },
  {
    title: 'Pending Review',
    value: kpiData.pendingReview,
    icon: Clock,
    color: '#3B82F6',
    bgIcon: '#EFF6FF',
  },
];

const barData = projectMonitoring.map((p) => ({
  name: p.name.split(' ').slice(0, 2).join(' '),
  score: p.score,
}));

const COLORS = ['#DA291C', '#F59E0B', '#3B82F6'];

export default function Dashboard() {
  const [hoveredRow, setHoveredRow] = useState<number | null>(null);

  return (
    <div className="p-8 max-w-[1400px]">
      {/* Page Title */}
      <div className="mb-8">
        <h1 className="text-[32px] font-bold text-[var(--hsbc-text-primary)] tracking-tight">
          Admin Backend Management Interface
        </h1>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-3 gap-5 mb-6">
        {kpiCards.map((card, index) => {
          const Icon = card.icon;
          return (
            <div
              key={index}
              className="hsbc-card p-5 flex items-center gap-4"
            >
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                style={{ backgroundColor: card.bgIcon }}
              >
                <Icon className="w-6 h-6" style={{ color: card.color }} strokeWidth={1.8} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-[var(--hsbc-text-muted)] mb-0.5">{card.title}</p>
                <p
                  className="text-[36px] font-bold leading-none"
                  style={{ color: card.color }}
                >
                  {card.value}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-2 gap-5 mb-6">
        {/* Active Project Monitoring */}
        <div className="hsbc-card p-5">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-6 h-6 rounded-md bg-[var(--hsbc-red-light)] flex items-center justify-center">
              <BarChart3 className="w-3.5 h-3.5 text-[var(--hsbc-red)]" strokeWidth={2} />
            </div>
            <h2 className="text-[16px] font-bold text-[var(--hsbc-text-primary)]">
              Active Project Monitoring
            </h2>
          </div>
          <div className="h-[220px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={barData} barSize={32}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--hsbc-border)" vertical={false} />
                <XAxis
                  dataKey="name"
                  tick={{ fontSize: 11, fill: 'var(--hsbc-text-muted)' }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fontSize: 11, fill: 'var(--hsbc-text-muted)' }}
                  axisLine={false}
                  tickLine={false}
                  domain={[60, 100]}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'var(--hsbc-bg-card)',
                    border: '1px solid var(--hsbc-border)',
                    borderRadius: '8px',
                    fontSize: '12px',
                    color: 'var(--hsbc-text-primary)',
                  }}
                />
                <Bar dataKey="score" fill="#DA291C" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Priority Distribution */}
        <div className="hsbc-card p-5">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-6 h-6 rounded-md bg-[var(--hsbc-blue-light)] flex items-center justify-center">
              <PieChart className="w-3.5 h-3.5 text-[var(--hsbc-blue)]" strokeWidth={2} />
            </div>
            <h2 className="text-[16px] font-bold text-[var(--hsbc-text-primary)]">
              Priority Distribution
            </h2>
          </div>
          <div className="flex items-center">
            <div className="w-1/2 h-[200px]">
              <ResponsiveContainer width="100%" height="100%">
                <RePieChart>
                  <Pie
                    data={priorityDistribution}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {priorityDistribution.map((_entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'var(--hsbc-bg-card)',
                      border: '1px solid var(--hsbc-border)',
                      borderRadius: '8px',
                      fontSize: '12px',
                    }}
                  />
                </RePieChart>
              </ResponsiveContainer>
            </div>
            <div className="w-1/2 space-y-3">
              {priorityDistribution.map((item, index) => (
                <div key={index} className="flex items-center gap-3">
                  <div
                    className="w-3 h-3 rounded-sm"
                    style={{ backgroundColor: item.color }}
                  />
                  <span className="text-sm text-[var(--hsbc-text-secondary)] flex-1">
                    {item.name}
                  </span>
                  <span className="text-sm font-semibold text-[var(--hsbc-text-primary)]">
                    {item.value}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Projects Table */}
      <div className="hsbc-card">
        <div className="flex items-center justify-between px-5 py-4 border-b border-[var(--hsbc-border)]">
          <h2 className="text-[16px] font-bold text-[var(--hsbc-text-primary)]">
            Projects
          </h2>
          <button className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors">
            <MoreHorizontal className="w-4 h-4 text-[var(--hsbc-text-muted)]" />
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-[var(--hsbc-bg-main)]">
                <th className="hsbc-table-header">Project Name</th>
                <th className="hsbc-table-header">Owner</th>
                <th className="hsbc-table-header">Score</th>
                <th className="hsbc-table-header">Priority</th>
                <th className="hsbc-table-header">Status</th>
              </tr>
            </thead>
            <tbody>
              {projectMonitoring.map((project, index) => (
                <tr
                  key={index}
                  className={`transition-colors ${
                    hoveredRow === index ? 'bg-[var(--hsbc-bg-main)]' : ''
                  }`}
                  onMouseEnter={() => setHoveredRow(index)}
                  onMouseLeave={() => setHoveredRow(null)}
                >
                  <td className="hsbc-table-cell font-medium text-[var(--hsbc-text-primary)]">
                    {project.name}
                  </td>
                  <td className="hsbc-table-cell">
                    {['SVS Team', 'Global Markets', 'IT Ops'][index] || 'N/A'}
                  </td>
                  <td className="hsbc-table-cell font-semibold">{project.score}</td>
                  <td className="hsbc-table-cell">
                    <span
                      className={`hsbc-status-badge ${
                        project.priority === 'High'
                          ? 'hsbc-priority-high'
                          : project.priority === 'Medium'
                          ? 'hsbc-priority-medium'
                          : 'hsbc-priority-low'
                      }`}
                    >
                      {project.priority}
                    </span>
                  </td>
                  <td className="hsbc-table-cell">
                    <span
                      className={`hsbc-status-badge ${
                        project.status === 'Approved'
                          ? 'hsbc-status-approved'
                          : project.status === 'Pending'
                          ? 'hsbc-status-pending'
                          : 'hsbc-status-in-review'
                      }`}
                    >
                      {project.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
