import { useState } from 'react';
import { Search, ChevronDown } from 'lucide-react';
import { projectsData } from '@/data/mockData';

export default function Projects() {
  const [searchQuery, setSearchQuery] = useState('');
  const [priorityFilter, setPriorityFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');

  const filteredProjects = projectsData.filter((project) => {
    const matchesSearch =
      searchQuery === '' ||
      project.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesPriority =
      priorityFilter === 'All' || project.priority === priorityFilter.toUpperCase();
    const matchesStatus =
      statusFilter === 'All' ||
      project.status.toLowerCase().includes(statusFilter.toLowerCase());
    return matchesSearch && matchesPriority && matchesStatus;
  });

  return (
    <div className="p-8 max-w-[1400px]">
      {/* Page Title */}
      <div className="mb-6">
        <h1 className="text-[32px] font-bold text-[var(--hsbc-text-primary)] tracking-tight">
          Admin Backend: Projects
        </h1>
      </div>

      {/* Filters Bar */}
      <div className="hsbc-card p-4 mb-5 flex items-center gap-4">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--hsbc-text-subtle)]" />
          <input
            type="text"
            placeholder="Search by Project Name or ID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="hsbc-input w-full pl-10"
          />
        </div>

        {/* Priority Filter */}
        <div className="relative">
          <select
            value={priorityFilter}
            onChange={(e) => setPriorityFilter(e.target.value)}
            className="hsbc-select pr-10 appearance-none"
          >
            <option value="All">Priority: All</option>
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
          </select>
          <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--hsbc-text-muted)] pointer-events-none" />
        </div>

        {/* Status Filter */}
        <div className="relative">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="hsbc-select pr-10 appearance-none"
          >
            <option value="All">Status: All</option>
            <option value="Approved">Approved</option>
            <option value="Pending">Pending</option>
            <option value="In Review">In Review</option>
            <option value="Draft">Draft</option>
          </select>
          <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--hsbc-text-muted)] pointer-events-none" />
        </div>
      </div>

      {/* Projects Table */}
      <div className="hsbc-card">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-[var(--hsbc-bg-main)]">
                <th className="hsbc-table-header">PROJECT NAME</th>
                <th className="hsbc-table-header">REQUESTED BY</th>
                <th className="hsbc-table-header">SCORE</th>
                <th className="hsbc-table-header">PRIORITY</th>
                <th className="hsbc-table-header">STATUS</th>
                <th className="hsbc-table-header">ACTIONS</th>
              </tr>
            </thead>
            <tbody>
              {filteredProjects.map((project, _index) => (
                <tr
                  key={project.id}
                  className="hover:bg-[var(--hsbc-bg-main)] transition-colors"
                >
                  <td className="hsbc-table-cell font-medium text-[var(--hsbc-text-primary)]">
                    {project.name}
                  </td>
                  <td className="hsbc-table-cell">{project.requestedBy}</td>
                  <td className="hsbc-table-cell font-semibold">{project.score}</td>
                  <td className="hsbc-table-cell">
                    <span
                      className={`hsbc-status-badge ${
                        project.priority === 'HIGH'
                          ? 'hsbc-priority-high'
                          : project.priority === 'MEDIUM'
                          ? 'hsbc-priority-medium'
                          : 'hsbc-priority-low'
                      }`}
                    >
                      {project.priority}
                    </span>
                  </td>
                  <td className="hsbc-table-cell">
                    <span
                      className={`hsbc-status-badge ${
                        project.status === 'APPROVED'
                          ? 'hsbc-status-approved'
                          : project.status === 'PENDING'
                          ? 'hsbc-status-pending'
                          : project.status === 'IN REVIEW'
                          ? 'hsbc-status-in-review'
                          : 'hsbc-status-draft'
                      }`}
                    >
                      {project.status}
                    </span>
                  </td>
                  <td className="hsbc-table-cell">
                    <button className="text-[var(--hsbc-blue)] hover:text-[var(--hsbc-red)] text-sm font-medium transition-colors">
                      {project.action}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
