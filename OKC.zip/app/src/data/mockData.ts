// Dashboard KPI Data
export const kpiData = {
  totalActiveProjects: 128,
  highPriorityItems: 24,
  pendingReview: 15,
};

// Priority Distribution Data
export const priorityDistribution = [
  { name: 'High', value: 24, color: '#DA291C' },
  { name: 'Medium', value: 65, color: '#F59E0B' },
  { name: 'Low', value: 39, color: '#3B82F6' },
];

// Active Project Monitoring Data
export const projectMonitoring = [
  { name: 'Cross-Border Data', score: 84.1, priority: 'High', status: 'Approved' },
  { name: 'Trade Finance Hub', score: 76.5, priority: 'Medium', status: 'Pending' },
  { name: 'CRM Migration V2', score: 91.2, priority: 'Low', status: 'Closed' },
  { name: 'Retail Risk V2', score: 89.4, priority: 'High', status: 'In Review' },
  { name: 'Wealth Management', score: 95.0, priority: 'Medium', status: 'Approved' },
];

// Projects Data
export const projectsData = [
  {
    id: 'P-2024-001',
    name: '2024 Core Banking Upg.',
    requestedBy: 'Alex Morgan (IT Dept)',
    score: 92.5,
    priority: 'HIGH',
    status: 'APPROVED',
    action: 'View Details',
  },
  {
    id: 'P-2024-002',
    name: 'Mobile App Redesign',
    requestedBy: 'Sara Lee (Digital)',
    score: 85.0,
    priority: 'MEDIUM',
    status: 'PENDING',
    action: 'Download Report',
  },
  {
    id: 'P-2024-003',
    name: 'Cloud Migration Phase 2',
    requestedBy: 'David Kim (Cloud Ops)',
    score: 98.0,
    priority: 'HIGH',
    status: 'IN REVIEW',
    action: 'View Details',
  },
  {
    id: 'P-2024-004',
    name: 'CRM System Upgrade',
    requestedBy: 'Lisa Wong (Sales)',
    score: 76.5,
    priority: 'LOW',
    status: 'DRAFT',
    action: 'Edit Project',
  },
  {
    id: 'P-2024-005',
    name: 'Retail Risk V2',
    requestedBy: 'John Smith (Risk)',
    score: 89.4,
    priority: 'HIGH',
    status: 'APPROVED',
    action: 'View Details',
  },
  {
    id: 'P-2024-006',
    name: 'Wealth Management',
    requestedBy: 'Emma Liu (Wealth)',
    score: 95.0,
    priority: 'MEDIUM',
    status: 'PENDING',
    action: 'Download Report',
  },
  {
    id: 'P-2024-007',
    name: 'Trade Finance Hub',
    requestedBy: 'Michael Chen (Trade)',
    score: 76.5,
    priority: 'MEDIUM',
    status: 'IN REVIEW',
    action: 'View Details',
  },
  {
    id: 'P-2024-008',
    name: 'Cross-Border Data',
    requestedBy: 'SVS Team',
    score: 84.1,
    priority: 'HIGH',
    status: 'APPROVED',
    action: 'View Details',
  },
];

// Scoring Rules Data
export const scoringRules = [
  {
    id: '01',
    title: 'Strategic Alignment',
    weight: 35,
    subItems: [
      {
        name: 'Market Growth Potential',
        criteria: 'High (4-5 pts), Medium (2-3 pts), Low (0-1 pt)',
      },
      {
        name: 'Brand Synergy',
        criteria: 'Strong alignment (4-5 pts), Partial (2-3 pts), None (0-1 pt)',
      },
    ],
  },
  {
    id: '02',
    title: 'Financial Viability',
    weight: 30,
    subItems: [
      {
        name: 'ROI Projection',
        criteria: '>20% (5 pts), 10-20% (3 pts), <10% (1 pt)',
      },
      {
        name: 'Cost Efficiency',
        criteria: 'Optimized (5 pts), Moderate (3 pts), Over-budget (1 pt)',
      },
    ],
  },
  {
    id: '03',
    title: 'Risk Assessment',
    weight: 20,
    subItems: [
      {
        name: 'Implementation Risk',
        criteria: 'Low (4-5 pts), Medium (2-3 pts), High (0-1 pt)',
      },
      {
        name: 'Regulatory Compliance',
        criteria: 'Full (5 pts), Partial (3 pts), Non-compliant (1 pt)',
      },
    ],
  },
  {
    id: '04',
    title: 'Operational Impact',
    weight: 15,
    subItems: [
      {
        name: 'Process Efficiency',
        criteria: 'Major (4-5 pts), Moderate (2-3 pts), Minimal (0-1 pt)',
      },
      {
        name: 'Resource Availability',
        criteria: 'Optimal (5 pts), Adequate (3 pts), Limited (1 pt)',
      },
    ],
  },
];

// Users Data
export const usersData = [
  {
    id: 1,
    username: 'Alex Morgan',
    department: 'Retail Banking',
    role: 'Admin',
    status: 'Active',
  },
  {
    id: 2,
    username: 'Sam Lee',
    department: 'Risk Management',
    role: 'Reviewer',
    status: 'Active',
  },
  {
    id: 3,
    username: 'Priya Patel',
    department: 'Compliance',
    role: 'Submitter',
    status: 'Inactive',
  },
  {
    id: 4,
    username: 'David Kim',
    department: 'Cloud Ops',
    role: 'Admin',
    status: 'Active',
  },
  {
    id: 5,
    username: 'Lisa Wong',
    department: 'Sales',
    role: 'Submitter',
    status: 'Active',
  },
  {
    id: 6,
    username: 'John Smith',
    department: 'Risk',
    role: 'Reviewer',
    status: 'Active',
  },
  {
    id: 7,
    username: 'Emma Liu',
    department: 'Wealth',
    role: 'Submitter',
    status: 'Inactive',
  },
  {
    id: 8,
    username: 'Michael Chen',
    department: 'Trade',
    role: 'Reviewer',
    status: 'Active',
  },
];

// Audit Logs Data
export const auditLogsData = [
  {
    timestamp: '2024-03-15 14:22',
    userId: 'admin_001',
    action: 'Project Submitted',
    object: 'P-2024-9102',
  },
  {
    timestamp: '2024-03-15 14:15',
    userId: 'analyst_05',
    action: 'Score Calculated',
    object: 'Rule-Set: V2.1',
  },
  {
    timestamp: '2024-03-15 13:40',
    userId: 'admin_001',
    action: 'Rule Updated',
    object: 'Rule-982-Config',
  },
  {
    timestamp: '2024-03-15 10:10',
    userId: 'admin_002',
    action: 'User Added',
    object: 'new-user: temp_99',
  },
  {
    timestamp: '2024-04-18 10:15',
    userId: 'jason_smith',
    action: 'Analysis Submitted',
    object: 'Cross-Border Data',
  },
  {
    timestamp: '2024-04-18 09:45',
    userId: 'admin_001',
    action: 'Project Approved',
    object: 'P-2024-9101',
  },
  {
    timestamp: '2024-04-18 09:30',
    userId: 'analyst_03',
    action: 'Score Recalculated',
    object: 'Rule-Set: V2.2',
  },
  {
    timestamp: '2024-04-17 16:20',
    userId: 'admin_002',
    action: 'User Deactivated',
    object: 'user: temp_99',
  },
  {
    timestamp: '2024-04-17 14:00',
    userId: 'sara_lee',
    action: 'Project Updated',
    object: 'P-2024-9100',
  },
  {
    timestamp: '2024-04-17 11:30',
    userId: 'admin_001',
    action: 'Rule Created',
    object: 'Rule-983-Config',
  },
];

// API & Analysis Logs Data
export const apiLogsData = [
  {
    timestamp: '14:32:11 20/10',
    user: 'john.s@hsbc',
    project: 'Retail Risk V2',
    action: 'Analysis Req',
    score: '89.4',
    status: 'Success',
  },
  {
    timestamp: '13:15:02 20/10',
    user: 'emma.l@hsbc',
    project: 'Wealth Mgmt',
    action: 'Data Sync',
    score: '-',
    status: 'Pending',
  },
  {
    timestamp: '10:05:47 20/10',
    user: 'mike.t@hsbc',
    project: 'Retail Risk V2',
    action: 'Analysis Req',
    score: '-',
    status: 'Failed',
  },
  {
    timestamp: '09:22:19 20/10',
    user: 'lisa.k@hsbc',
    project: 'Trade Finance',
    action: 'Health Check',
    score: '99.0',
    status: 'Success',
  },
  {
    timestamp: '08:45:33 20/10',
    user: 'alex.m@hsbc',
    project: 'Core Banking',
    action: 'Analysis Req',
    score: '92.5',
    status: 'Success',
  },
  {
    timestamp: '08:12:05 20/10',
    user: 'sara.l@hsbc',
    project: 'Mobile App',
    action: 'Data Sync',
    score: '-',
    status: 'Pending',
  },
  {
    timestamp: '07:58:41 20/10',
    user: 'david.k@hsbc',
    project: 'Cloud Migration',
    action: 'Analysis Req',
    score: '98.0',
    status: 'Success',
  },
  {
    timestamp: '07:30:15 20/10',
    user: 'priya.p@hsbc',
    project: 'Compliance Check',
    action: 'Health Check',
    score: '87.2',
    status: 'Success',
  },
];
