import { Routes, Route } from 'react-router-dom';
import Sidebar from '@/components/layout/Sidebar';
import Dashboard from '@/pages/Dashboard';
import Projects from '@/pages/Projects';
import ScoringRules from '@/pages/ScoringRules';
import Users from '@/pages/Users';
import AuditLogs from '@/pages/AuditLogs';
import ApiLogs from '@/pages/ApiLogs';

function App() {
  return (
    <div className="flex min-h-screen bg-[var(--hsbc-bg-main)]">
      <Sidebar />
      <main className="flex-1 ml-[260px]">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/projects" element={<Projects />} />
          <Route path="/scoring-rules" element={<ScoringRules />} />
          <Route path="/users" element={<Users />} />
          <Route path="/audit-logs" element={<AuditLogs />} />
          <Route path="/api-logs" element={<ApiLogs />} />
        </Routes>
      </main>
    </div>
  );
}

export default App;
