import React, { createContext, useContext, useReducer, useCallback } from "react";

// ──── Data Types ─────────────────────────────────────────────────────
export interface Project {
  id: string;
  name: string;
  requestedBy: string;
  score: number;
  priority: "HIGH" | "MEDIUM" | "LOW";
  status: "APPROVED" | "PENDING" | "IN_REVIEW" | "DRAFT";
  action: string;
}

export interface User {
  id: number;
  username: string;
  department: string;
  role: "Admin" | "Reviewer" | "Submitter";
  status: "Active" | "Inactive";
}

export interface ScoringRule {
  id: string;
  title: string;
  weight: number;
  subItems: { name: string; criteria: string }[];
}

export interface AuditLog {
  id: number;
  timestamp: string;
  userId: string;
  action: string;
  object: string;
}

export interface ApiLog {
  id: number;
  timestamp: string;
  user: string;
  project: string;
  action: string;
  score: string | null;
  status: "Success" | "Pending" | "Failed";
}

// ──── Initial Data ───────────────────────────────────────────────────
const initialProjects: Project[] = [
  { id: "P-2024-001", name: "2024 Core Banking Upg.", requestedBy: "Alex Morgan (IT Dept)", score: 92.5, priority: "HIGH", status: "APPROVED", action: "View Details" },
  { id: "P-2024-002", name: "Mobile App Redesign", requestedBy: "Sara Lee (Digital)", score: 85.0, priority: "MEDIUM", status: "PENDING", action: "Download Report" },
  { id: "P-2024-003", name: "Cloud Migration Phase 2", requestedBy: "David Kim (Cloud Ops)", score: 98.0, priority: "HIGH", status: "IN_REVIEW", action: "View Details" },
  { id: "P-2024-004", name: "CRM System Upgrade", requestedBy: "Lisa Wong (Sales)", score: 76.5, priority: "LOW", status: "DRAFT", action: "Edit Project" },
  { id: "P-2024-005", name: "Retail Risk V2", requestedBy: "John Smith (Risk)", score: 89.4, priority: "HIGH", status: "APPROVED", action: "View Details" },
  { id: "P-2024-006", name: "Wealth Management", requestedBy: "Emma Liu (Wealth)", score: 95.0, priority: "MEDIUM", status: "PENDING", action: "Download Report" },
  { id: "P-2024-007", name: "Trade Finance Hub", requestedBy: "Michael Chen (Trade)", score: 76.5, priority: "MEDIUM", status: "IN_REVIEW", action: "View Details" },
  { id: "P-2024-008", name: "Cross-Border Data", requestedBy: "SVS Team", score: 84.1, priority: "HIGH", status: "APPROVED", action: "View Details" },
];

const initialUsers: User[] = [
  { id: 1, username: "Alex Morgan", department: "Retail Banking", role: "Admin", status: "Active" },
  { id: 2, username: "Sam Lee", department: "Risk Management", role: "Reviewer", status: "Active" },
  { id: 3, username: "Priya Patel", department: "Compliance", role: "Submitter", status: "Inactive" },
  { id: 4, username: "David Kim", department: "Cloud Ops", role: "Admin", status: "Active" },
  { id: 5, username: "Lisa Wong", department: "Sales", role: "Submitter", status: "Active" },
  { id: 6, username: "John Smith", department: "Risk", role: "Reviewer", status: "Active" },
  { id: 7, username: "Emma Liu", department: "Wealth", role: "Submitter", status: "Inactive" },
  { id: 8, username: "Michael Chen", department: "Trade", role: "Reviewer", status: "Active" },
];

const initialScoringRules: ScoringRule[] = [
  {
    id: "01", title: "Strategic Alignment", weight: 35,
    subItems: [
      { name: "Market Growth Potential", criteria: "High (4-5 pts), Medium (2-3 pts), Low (0-1 pt)" },
      { name: "Brand Synergy", criteria: "Strong alignment (4-5 pts), Partial (2-3 pts), None (0-1 pt)" },
    ],
  },
  {
    id: "02", title: "Financial Viability", weight: 30,
    subItems: [
      { name: "ROI Projection", criteria: ">20% (5 pts), 10-20% (3 pts), <10% (1 pt)" },
      { name: "Cost Efficiency", criteria: "Optimized (5 pts), Moderate (3 pts), Over-budget (1 pt)" },
    ],
  },
  {
    id: "03", title: "Risk Assessment", weight: 20,
    subItems: [
      { name: "Implementation Risk", criteria: "Low (4-5 pts), Medium (2-3 pts), High (0-1 pt)" },
      { name: "Regulatory Compliance", criteria: "Full (5 pts), Partial (3 pts), Non-compliant (1 pt)" },
    ],
  },
  {
    id: "04", title: "Operational Impact", weight: 15,
    subItems: [
      { name: "Process Efficiency", criteria: "Major (4-5 pts), Moderate (2-3 pts), Minimal (0-1 pt)" },
      { name: "Resource Availability", criteria: "Optimal (5 pts), Adequate (3 pts), Limited (1 pt)" },
    ],
  },
];

let auditIdCounter = 11;
const initialAuditLogs: AuditLog[] = [
  { id: 1, timestamp: "2024-03-15 14:22", userId: "admin_001", action: "Project Submitted", object: "P-2024-9102" },
  { id: 2, timestamp: "2024-03-15 14:15", userId: "analyst_05", action: "Score Calculated", object: "Rule-Set: V2.1" },
  { id: 3, timestamp: "2024-03-15 13:40", userId: "admin_001", action: "Rule Updated", object: "Rule-982-Config" },
  { id: 4, timestamp: "2024-03-15 10:10", userId: "admin_002", action: "User Added", object: "new-user: temp_99" },
  { id: 5, timestamp: "2024-04-18 10:15", userId: "jason_smith", action: "Analysis Submitted", object: "Cross-Border Data" },
  { id: 6, timestamp: "2024-04-18 09:45", userId: "admin_001", action: "Project Approved", object: "P-2024-9101" },
  { id: 7, timestamp: "2024-04-18 09:30", userId: "analyst_03", action: "Score Recalculated", object: "Rule-Set: V2.2" },
  { id: 8, timestamp: "2024-04-17 16:20", userId: "admin_002", action: "User Deactivated", object: "user: temp_99" },
  { id: 9, timestamp: "2024-04-17 14:00", userId: "sara_lee", action: "Project Updated", object: "P-2024-9100" },
  { id: 10, timestamp: "2024-04-17 11:30", userId: "admin_001", action: "Rule Created", object: "Rule-983-Config" },
];

const initialApiLogs: ApiLog[] = [
  { id: 1, timestamp: "14:32:11 20/10", user: "john.s@hsbc", project: "Retail Risk V2", action: "Analysis Req", score: "89.4", status: "Success" },
  { id: 2, timestamp: "13:15:02 20/10", user: "emma.l@hsbc", project: "Wealth Mgmt", action: "Data Sync", score: null, status: "Pending" },
  { id: 3, timestamp: "10:05:47 20/10", user: "mike.t@hsbc", project: "Retail Risk V2", action: "Analysis Req", score: null, status: "Failed" },
  { id: 4, timestamp: "09:22:19 20/10", user: "lisa.k@hsbc", project: "Trade Finance", action: "Health Check", score: "99.0", status: "Success" },
  { id: 5, timestamp: "08:45:33 20/10", user: "alex.m@hsbc", project: "Core Banking", action: "Analysis Req", score: "92.5", status: "Success" },
  { id: 6, timestamp: "08:12:05 20/10", user: "sara.l@hsbc", project: "Mobile App", action: "Data Sync", score: null, status: "Pending" },
  { id: 7, timestamp: "07:58:41 20/10", user: "david.k@hsbc", project: "Cloud Migration", action: "Analysis Req", score: "98.0", status: "Success" },
  { id: 8, timestamp: "07:30:15 20/10", user: "priya.p@hsbc", project: "Compliance Check", action: "Health Check", score: "87.2", status: "Success" },
];

// ──── State ──────────────────────────────────────────────────────────
interface AppState {
  projects: Project[];
  users: User[];
  scoringRules: ScoringRule[];
  auditLogs: AuditLog[];
  apiLogs: ApiLog[];
}

const initialState: AppState = {
  projects: initialProjects,
  users: initialUsers,
  scoringRules: initialScoringRules,
  auditLogs: initialAuditLogs,
  apiLogs: initialApiLogs,
};

// ──── Actions ────────────────────────────────────────────────────────
type Action =
  | { type: "ADD_PROJECT"; payload: Project }
  | { type: "UPDATE_PROJECT"; payload: { id: string; data: Partial<Project> } }
  | { type: "DELETE_PROJECT"; payload: string }
  | { type: "ADD_USER"; payload: User }
  | { type: "UPDATE_USER"; payload: { id: number; data: Partial<User> } }
  | { type: "DELETE_USER"; payload: number }
  | { type: "TOGGLE_USER_STATUS"; payload: number }
  | { type: "ADD_AUDIT_LOG"; payload: Omit<AuditLog, "id"> }
  | { type: "ADD_API_LOG"; payload: Omit<ApiLog, "id"> }
  | { type: "UPDATE_SCORING_RULE"; payload: { id: string; data: Partial<ScoringRule> } };

function appReducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case "ADD_PROJECT": {
      const newProject = action.payload;
      const newAudit: AuditLog = {
        id: auditIdCounter++,
        timestamp: new Date().toISOString().slice(0, 16).replace("T", " "),
        userId: "admin_001",
        action: "Project Created",
        object: newProject.id,
      };
      return {
        ...state,
        projects: [...state.projects, newProject],
        auditLogs: [newAudit, ...state.auditLogs],
      };
    }
    case "UPDATE_PROJECT": {
      const { id, data } = action.payload;
      const newAudit: AuditLog = {
        id: auditIdCounter++,
        timestamp: new Date().toISOString().slice(0, 16).replace("T", " "),
        userId: "admin_001",
        action: "Project Updated",
        object: id,
      };
      return {
        ...state,
        projects: state.projects.map((p) => (p.id === id ? { ...p, ...data } : p)),
        auditLogs: [newAudit, ...state.auditLogs],
      };
    }
    case "DELETE_PROJECT": {
      const newAudit: AuditLog = {
        id: auditIdCounter++,
        timestamp: new Date().toISOString().slice(0, 16).replace("T", " "),
        userId: "admin_001",
        action: "Project Deleted",
        object: action.payload,
      };
      return {
        ...state,
        projects: state.projects.filter((p) => p.id !== action.payload),
        auditLogs: [newAudit, ...state.auditLogs],
      };
    }
    case "ADD_USER": {
      const newUser = action.payload;
      const newAudit: AuditLog = {
        id: auditIdCounter++,
        timestamp: new Date().toISOString().slice(0, 16).replace("T", " "),
        userId: "admin_001",
        action: "User Added",
        object: `new-user: ${newUser.username}`,
      };
      return {
        ...state,
        users: [...state.users, newUser],
        auditLogs: [newAudit, ...state.auditLogs],
      };
    }
    case "UPDATE_USER": {
      const { id, data } = action.payload;
      return {
        ...state,
        users: state.users.map((u) => (u.id === id ? { ...u, ...data } : u)),
      };
    }
    case "DELETE_USER": {
      const user = state.users.find((u) => u.id === action.payload);
      const newAudit: AuditLog = {
        id: auditIdCounter++,
        timestamp: new Date().toISOString().slice(0, 16).replace("T", " "),
        userId: "admin_001",
        action: "User Deleted",
        object: user ? user.username : String(action.payload),
      };
      return {
        ...state,
        users: state.users.filter((u) => u.id !== action.payload),
        auditLogs: [newAudit, ...state.auditLogs],
      };
    }
    case "TOGGLE_USER_STATUS": {
      const user = state.users.find((u) => u.id === action.payload);
      if (!user) return state;
      const newStatus = user.status === "Active" ? "Inactive" : "Active";
      const newAudit: AuditLog = {
        id: auditIdCounter++,
        timestamp: new Date().toISOString().slice(0, 16).replace("T", " "),
        userId: "admin_001",
        action: newStatus === "Active" ? "User Reactivated" : "User Deactivated",
        object: user.username,
      };
      return {
        ...state,
        users: state.users.map((u) =>
          u.id === action.payload ? { ...u, status: newStatus } : u
        ),
        auditLogs: [newAudit, ...state.auditLogs],
      };
    }
    case "ADD_AUDIT_LOG": {
      const newLog = { ...action.payload, id: auditIdCounter++ };
      return { ...state, auditLogs: [newLog, ...state.auditLogs] };
    }
    case "ADD_API_LOG": {
      const newLog = { ...action.payload, id: state.apiLogs.length + 1 };
      return { ...state, apiLogs: [newLog, ...state.apiLogs] };
    }
    case "UPDATE_SCORING_RULE": {
      const { id, data } = action.payload;
      const newAudit: AuditLog = {
        id: auditIdCounter++,
        timestamp: new Date().toISOString().slice(0, 16).replace("T", " "),
        userId: "admin_001",
        action: "Rule Updated",
        object: `Rule-${id}`,
      };
      return {
        ...state,
        scoringRules: state.scoringRules.map((r) => (r.id === id ? { ...r, ...data } : r)),
        auditLogs: [newAudit, ...state.auditLogs],
      };
    }
    default:
      return state;
  }
}

// ──── Context ────────────────────────────────────────────────────────
interface AppContextValue {
  state: AppState;
  dispatch: React.Dispatch<Action>;
  // Computed
  totalActiveProjects: number;
  highPriorityItems: number;
  pendingReview: number;
  priorityDistribution: { name: string; value: number; color: string }[];
}

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, initialState);

  // Computed values that flow across pages
  const totalActiveProjects = state.projects.length;
  const highPriorityItems = state.projects.filter((p) => p.priority === "HIGH").length;
  const pendingReview = state.projects.filter((p) => p.status === "PENDING").length;
  const priorityDistribution = [
    { name: "High", value: highPriorityItems, color: "#DA291C" },
    { name: "Medium", value: state.projects.filter((p) => p.priority === "MEDIUM").length, color: "#F59E0B" },
    { name: "Low", value: state.projects.filter((p) => p.priority === "LOW").length, color: "#3B82F6" },
  ];

  return (
    <AppContext.Provider
      value={{ state, dispatch, totalActiveProjects, highPriorityItems, pendingReview, priorityDistribution }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}

// ──── Convenience Hooks ──────────────────────────────────────────────
export function useProjects() {
  const { state, dispatch } = useApp();

  const addProject = useCallback(
    (project: Omit<Project, "id">) => {
      const id = `P-${Date.now()}`;
      dispatch({ type: "ADD_PROJECT", payload: { ...project, id } as Project });
    },
    [dispatch]
  );

  const updateProject = useCallback(
    (id: string, data: Partial<Project>) => {
      dispatch({ type: "UPDATE_PROJECT", payload: { id, data } });
    },
    [dispatch]
  );

  const deleteProject = useCallback(
    (id: string) => {
      dispatch({ type: "DELETE_PROJECT", payload: id });
    },
    [dispatch]
  );

  return { projects: state.projects, addProject, updateProject, deleteProject };
}

export function useUsers() {
  const { state, dispatch } = useApp();

  const addUser = useCallback(
    (user: Omit<User, "id">) => {
      const id = Math.max(0, ...state.users.map((u) => u.id)) + 1;
      dispatch({ type: "ADD_USER", payload: { ...user, id } as User });
    },
    [dispatch, state.users]
  );

  const updateUser = useCallback(
    (id: number, data: Partial<User>) => {
      dispatch({ type: "UPDATE_USER", payload: { id, data } });
    },
    [dispatch]
  );

  const toggleStatus = useCallback(
    (id: number) => {
      dispatch({ type: "TOGGLE_USER_STATUS", payload: id });
    },
    [dispatch]
  );

  const deleteUser = useCallback(
    (id: number) => {
      dispatch({ type: "DELETE_USER", payload: id });
    },
    [dispatch]
  );

  return { users: state.users, addUser, updateUser, toggleStatus, deleteUser };
}

export function useScoringRules() {
  const { state, dispatch } = useApp();

  const updateRule = useCallback(
    (id: string, data: Partial<ScoringRule>) => {
      dispatch({ type: "UPDATE_SCORING_RULE", payload: { id, data } });
    },
    [dispatch]
  );

  return { rules: state.scoringRules, updateRule };
}

export function useAuditLogs() {
  const { state } = useApp();
  return { logs: state.auditLogs };
}

export function useApiLogs() {
  const { state } = useApp();
  return { logs: state.apiLogs };
}
