import { useLocation, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  FolderOpen,
  ClipboardList,
  Users,
  ScrollText,
  Activity,
  Hexagon,
} from 'lucide-react';

const menuItems = [
  { path: '/', label: 'Dashboard', icon: LayoutDashboard },
  { path: '/projects', label: 'Projects', icon: FolderOpen },
  { path: '/scoring-rules', label: 'Scoring Rules', icon: ClipboardList },
  { path: '/users', label: 'Users Management', icon: Users },
  { path: '/audit-logs', label: 'Audit Logs', icon: ScrollText },
  { path: '/api-logs', label: 'API & Analysis', icon: Activity },
];

export default function Sidebar() {
  const location = useLocation();
  const navigate = useNavigate();

  return (
    <aside className="fixed left-0 top-0 h-full w-[260px] bg-[var(--hsbc-sidebar)] flex flex-col z-50">
      {/* Logo Area */}
      <div className="flex items-center gap-3 px-6 py-5 border-b border-white/10">
        <div className="w-9 h-9 rounded-lg bg-white/10 flex items-center justify-center">
          <Hexagon className="w-5 h-5 text-white" strokeWidth={2} />
        </div>
        <div className="flex flex-col">
          <span className="text-white font-bold text-lg leading-tight tracking-tight">HSBC</span>
          <span className="text-gray-400 text-[10px] leading-tight tracking-wide uppercase">Admin Portal</span>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className={`hsbc-sidebar-item w-full ${
                isActive ? 'active' : 'inactive'
              }`}
            >
              <Icon
                className={`w-[18px] h-[18px] ${
                  isActive ? 'text-white' : 'text-gray-400'
                }`}
                strokeWidth={1.8}
              />
              <span className="tracking-tight">{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="px-6 py-4 border-t border-white/10">
        <p className="text-[11px] text-gray-500">
          V 2.4.1 | HSBC Admin Portal
        </p>
      </div>
    </aside>
  );
}
