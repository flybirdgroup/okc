import { useState } from "react";
import { Search, ChevronDown, Trash2, Plus } from "lucide-react";
import { useProjects } from "@/context/AppContext";
import type { Project } from "@/context/AppContext";

export default function Projects() {
  const [searchQuery, setSearchQuery] = useState("");
  const [priorityFilter, setPriorityFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("All");
  const { projects, deleteProject, addProject } = useProjects();

  const [showAddDialog, setShowAddDialog] = useState(false);
  const [newProject, setNewProject] = useState<Partial<Project>>({
    name: "",
    requestedBy: "",
    score: 80,
    priority: "MEDIUM",
    status: "DRAFT",
    action: "View Details",
  });

  const filteredProjects = projects.filter((project) => {
    const matchesSearch =
      searchQuery === "" ||
      project.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesPriority = priorityFilter === "All" || project.priority === priorityFilter.toUpperCase();
    const matchesStatus = statusFilter === "All" || project.status === statusFilter.toUpperCase();
    return matchesSearch && matchesPriority && matchesStatus;
  });

  const handleAdd = () => {
    if (newProject.name && newProject.requestedBy) {
      addProject({
        name: newProject.name,
        requestedBy: newProject.requestedBy,
        score: Number(newProject.score) || 80,
        priority: (newProject.priority as Project["priority"]) || "MEDIUM",
        status: (newProject.status as Project["status"]) || "DRAFT",
        action: "View Details",
      });
      setShowAddDialog(false);
      setNewProject({ name: "", requestedBy: "", score: 80, priority: "MEDIUM", status: "DRAFT", action: "View Details" });
    }
  };

  return (
    <div className="p-8 max-w-[1400px]">
      <div className="mb-6">
        <h1 className="text-[32px] font-bold text-[var(--hsbc-text-primary)] tracking-tight">
          Admin Backend: Projects
        </h1>
      </div>

      {/* Filters Bar + Add */}
      <div className="hsbc-card p-4 mb-5 flex items-center gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--hsbc-text-subtle)]" />
          <input
            type="text"
            placeholder="Search by Project Name or ID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="hsbc-input w-full pl-10"
          />
        </div>

        <div className="relative">
          <select value={priorityFilter} onChange={(e) => setPriorityFilter(e.target.value)} className="hsbc-select pr-10 appearance-none">
            <option value="All">Priority: All</option>
            <option value="HIGH">High</option>
            <option value="MEDIUM">Medium</option>
            <option value="LOW">Low</option>
          </select>
          <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--hsbc-text-muted)] pointer-events-none" />
        </div>

        <div className="relative">
          <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="hsbc-select pr-10 appearance-none">
            <option value="All">Status: All</option>
            <option value="APPROVED">Approved</option>
            <option value="PENDING">Pending</option>
            <option value="IN_REVIEW">In Review</option>
            <option value="DRAFT">Draft</option>
          </select>
          <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--hsbc-text-muted)] pointer-events-none" />
        </div>

        <button onClick={() => setShowAddDialog(true)} className="hsbc-btn-primary px-4 py-2.5 flex items-center gap-2 text-sm">
          <Plus className="w-4 h-4" />
          Add Project
        </button>
      </div>

      {/* Add Project Dialog */}
      {showAddDialog && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-[var(--hsbc-bg-card)] rounded-xl p-6 w-[400px] border border-[var(--hsbc-border)]">
            <h2 className="text-lg font-bold text-[var(--hsbc-text-primary)] mb-4">Add New Project</h2>
            <div className="space-y-3">
              <div>
                <label className="block text-sm text-[var(--hsbc-text-secondary)] mb-1">Name</label>
                <input value={newProject.name} onChange={(e) => setNewProject({ ...newProject, name: e.target.value })} className="hsbc-input w-full" placeholder="Project name" />
              </div>
              <div>
                <label className="block text-sm text-[var(--hsbc-text-secondary)] mb-1">Requested By</label>
                <input value={newProject.requestedBy} onChange={(e) => setNewProject({ ...newProject, requestedBy: e.target.value })} className="hsbc-input w-full" placeholder="Requester name" />
              </div>
              <div className="flex gap-3">
                <div className="flex-1">
                  <label className="block text-sm text-[var(--hsbc-text-secondary)] mb-1">Score</label>
                  <input type="number" value={newProject.score} onChange={(e) => setNewProject({ ...newProject, score: Number(e.target.value) })} className="hsbc-input w-full" />
                </div>
                <div className="flex-1">
                  <label className="block text-sm text-[var(--hsbc-text-secondary)] mb-1">Priority</label>
                  <select value={newProject.priority} onChange={(e) => setNewProject({ ...newProject, priority: e.target.value as Project["priority"] })} className="hsbc-select w-full">
                    <option value="HIGH">High</option>
                    <option value="MEDIUM">Medium</option>
                    <option value="LOW">Low</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm text-[var(--hsbc-text-secondary)] mb-1">Status</label>
                <select value={newProject.status} onChange={(e) => setNewProject({ ...newProject, status: e.target.value as Project["status"] })} className="hsbc-select w-full">
                  <option value="APPROVED">Approved</option>
                  <option value="PENDING">Pending</option>
                  <option value="IN_REVIEW">In Review</option>
                  <option value="DRAFT">Draft</option>
                </select>
              </div>
            </div>
            <div className="flex gap-3 mt-5">
              <button onClick={() => setShowAddDialog(false)} className="flex-1 py-2.5 rounded-lg border border-[var(--hsbc-border)] text-sm font-medium hover:bg-[var(--hsbc-bg-main)] transition-colors">Cancel</button>
              <button onClick={handleAdd} className="hsbc-btn-primary flex-1 py-2.5 text-sm">Add Project</button>
            </div>
          </div>
        </div>
      )}

      {/* Projects Table */}
      <div className="hsbc-card">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-[var(--hsbc-bg-main)]">
                <th className="hsbc-table-header">PROJECT NAME</th>
                <th className="hsbc-table-header">REQUESTED BY</th>
                <th className="hsbc-table-header">SCORE</th>
                <th className="hsbc-table-header">PRIORITY</th>
                <th className="hsbc-table-header">STATUS</th>
                <th className="hsbc-table-header">ACTIONS</th>
              </tr>
            </thead>
            <tbody>
              {filteredProjects.map((project) => (
                <tr key={project.id} className="hover:bg-[var(--hsbc-bg-main)] transition-colors">
                  <td className="hsbc-table-cell font-medium text-[var(--hsbc-text-primary)]">{project.name}</td>
                  <td className="hsbc-table-cell">{project.requestedBy}</td>
                  <td className="hsbc-table-cell font-semibold">{project.score}</td>
                  <td className="hsbc-table-cell">
                    <span className={`hsbc-status-badge ${project.priority === "HIGH" ? "hsbc-priority-high" : project.priority === "MEDIUM" ? "hsbc-priority-medium" : "hsbc-priority-low"}`}>
                      {project.priority}
                    </span>
                  </td>
                  <td className="hsbc-table-cell">
                    <span className={`hsbc-status-badge ${project.status === "APPROVED" ? "hsbc-status-approved" : project.status === "PENDING" ? "hsbc-status-pending" : project.status === "IN_REVIEW" ? "hsbc-status-in-review" : "hsbc-status-draft"}`}>
                      {project.status}
                    </span>
                  </td>
                  <td className="hsbc-table-cell">
                    <div className="flex items-center gap-2">
                      <button className="text-[var(--hsbc-blue)] hover:text-[var(--hsbc-red)] text-sm font-medium transition-colors">
                        {project.action}
                      </button>
                      <button onClick={() => deleteProject(project.id)} className="p-1.5 rounded-md hover:bg-red-50 text-gray-400 hover:text-red-500 transition-colors" title="Delete">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
