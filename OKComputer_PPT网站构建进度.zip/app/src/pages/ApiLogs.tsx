import { useState } from "react";
import { Search, ChevronDown, Activity } from "lucide-react";
import { useApiLogs } from "@/context/AppContext";

export default function ApiLogs() {
  const [searchQuery, setSearchQuery] = useState("");
  const [userFilter, setUserFilter] = useState("All Users");
  const [projectFilter, setProjectFilter] = useState("All Proj");
  const { logs } = useApiLogs();

  const filteredLogs = logs.filter((log) => {
    const matchesSearch = searchQuery === "" || log.user.toLowerCase().includes(searchQuery.toLowerCase()) || log.project.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesUser = userFilter === "All Users" || log.user === userFilter;
    const matchesProject = projectFilter === "All Proj" || log.project === projectFilter;
    return matchesSearch && matchesUser && matchesProject;
  });

  return (
    <div className="p-8 max-w-[1400px]">
      <div className="mb-6">
        <h1 className="text-[32px] font-bold text-[var(--hsbc-text-primary)] tracking-tight">
          Admin Backend: API & Analysis Logs
        </h1>
      </div>

      <div className="hsbc-card p-4 mb-5">
        <div className="flex items-center gap-4 flex-wrap">
          <div className="relative flex-1 max-w-xs">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--hsbc-text-subtle)]" />
            <input type="text" placeholder="Search by ID / User..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="hsbc-input w-full pl-10" />
          </div>

          <div className="relative">
            <select value={userFilter} onChange={(e) => setUserFilter(e.target.value)} className="hsbc-select pr-10 appearance-none min-w-[130px]">
              <option>All Users</option>
              <option>john.s@hsbc</option>
              <option>emma.l@hsbc</option>
              <option>mike.t@hsbc</option>
              <option>lisa.k@hsbc</option>
              <option>alex.m@hsbc</option>
            </select>
            <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--hsbc-text-muted)] pointer-events-none" />
          </div>

          <div className="relative">
            <select value={projectFilter} onChange={(e) => setProjectFilter(e.target.value)} className="hsbc-select pr-10 appearance-none min-w-[120px]">
              <option>All Proj</option>
              <option>Retail Risk V2</option>
              <option>Wealth Mgmt</option>
              <option>Trade Finance</option>
              <option>Core Banking</option>
              <option>Mobile App</option>
            </select>
            <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--hsbc-text-muted)] pointer-events-none" />
          </div>
        </div>
      </div>

      <div className="hsbc-card">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-[var(--hsbc-bg-main)]">
                <th className="hsbc-table-header">TIMESTAMP</th>
                <th className="hsbc-table-header">USER</th>
                <th className="hsbc-table-header">PROJECT</th>
                <th className="hsbc-table-header">ACTION</th>
                <th className="hsbc-table-header">SCORE</th>
                <th className="hsbc-table-header">STATUS</th>
              </tr>
            </thead>
            <tbody>
              {filteredLogs.map((log, index: number) => (
                <tr key={index} className="hover:bg-[var(--hsbc-bg-main)] transition-colors">
                  <td className="hsbc-table-cell text-[var(--hsbc-text-muted)] font-mono text-xs">{log.timestamp}</td>
                  <td className="hsbc-table-cell font-medium text-[var(--hsbc-text-primary)]">{log.user}</td>
                  <td className="hsbc-table-cell text-[var(--hsbc-text-secondary)]">{log.project}</td>
                  <td className="hsbc-table-cell">
                    <span className="inline-flex items-center gap-1.5"><Activity className="w-3.5 h-3.5 text-[var(--hsbc-text-muted)]" />{log.action}</span>
                  </td>
                  <td className="hsbc-table-cell font-semibold">
                    {log.score === null || log.score === "-" ? <span className="text-[var(--hsbc-text-subtle)]">-</span> : <span className="text-[var(--hsbc-text-primary)]">{log.score}</span>}
                  </td>
                  <td className="hsbc-table-cell">
                    <span className={`hsbc-status-badge ${log.status === "Success" ? "hsbc-status-success" : log.status === "Pending" ? "hsbc-status-pending" : "hsbc-status-failed"}`}>
                      {log.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
