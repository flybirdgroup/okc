import { useState, useCallback } from "react";
import { ClipboardList, ChevronDown, ChevronUp, Pencil, Save, X } from "lucide-react";
import { useScoringRules } from "@/context/AppContext";
import type { ScoringRule } from "@/context/AppContext";

export default function ScoringRules() {
  const [expandedRule, setExpandedRule] = useState<string | null>("01");
  const [editingRule, setEditingRule] = useState<string | null>(null);
  const { rules, updateRule } = useScoringRules();

  // Store edited values per rule
  const [editForm, setEditForm] = useState<Record<string, {
    title: string;
    weight: number;
    subItems: { name: string; criteria: string }[];
  }>>({});

  const toggleExpand = (id: string) => {
    setExpandedRule(expandedRule === id ? null : id);
  };

  const startEditing = useCallback((rule: ScoringRule) => {
    setEditingRule(rule.id);
    setEditForm((prev) => ({
      ...prev,
      [rule.id]: {
        title: rule.title,
        weight: rule.weight,
        subItems: rule.subItems.map((si) => ({ ...si })),
      },
    }));
  }, []);

  const cancelEditing = useCallback(() => {
    setEditingRule(null);
  }, []);

  const saveEditing = useCallback((ruleId: string) => {
    const form = editForm[ruleId];
    if (!form) return;

    // Update rule title and weight
    updateRule(ruleId, {
      title: form.title,
      weight: form.weight,
      subItems: form.subItems,
    });

    setEditingRule(null);
  }, [editForm, updateRule]);

  const updateSubItem = useCallback((ruleId: string, index: number, field: "name" | "criteria", value: string) => {
    setEditForm((prev) => {
      const form = prev[ruleId];
      if (!form) return prev;
      const newSubItems = [...form.subItems];
      newSubItems[index] = { ...newSubItems[index], [field]: value };
      return { ...prev, [ruleId]: { ...form, subItems: newSubItems } };
    });
  }, []);

  const isEditing = (ruleId: string) => editingRule === ruleId;

  return (
    <div className="p-8 max-w-[1400px]">
      <div className="mb-8">
        <h1 className="text-[32px] font-bold text-[var(--hsbc-text-primary)] tracking-tight">
          Scoring Rules Configuration
        </h1>
      </div>

      <div className="space-y-4">
        {rules.map((rule) => (
          <div key={rule.id} className="hsbc-card overflow-hidden">
            {/* ── Header ── */}
            <div
              className="flex items-center justify-between px-6 py-4 cursor-pointer hover:bg-[var(--hsbc-bg-main)]/50 transition-colors"
              onClick={() => toggleExpand(rule.id)}
            >
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-lg bg-[var(--hsbc-red-light)] flex items-center justify-center">
                  <ClipboardList className="w-5 h-5 text-[var(--hsbc-red)]" strokeWidth={1.8} />
                </div>
                <div>
                  {isEditing(rule.id) ? (
                    <div className="flex items-center gap-2">
                      <span className="text-[16px] font-bold text-[var(--hsbc-text-primary)]">
                        {rule.id}.
                      </span>
                      <input
                        type="text"
                        value={editForm[rule.id]?.title ?? rule.title}
                        onClick={(e) => e.stopPropagation()}
                        onChange={(e) =>
                          setEditForm((prev) => ({
                            ...prev,
                            [rule.id]: { ...(prev[rule.id] ?? { title: rule.title, weight: rule.weight, subItems: rule.subItems }), title: e.target.value },
                          }))
                        }
                        className="hsbc-input text-[15px] font-bold min-w-[280px]"
                      />
                    </div>
                  ) : (
                    <h3 className="text-[16px] font-bold text-[var(--hsbc-text-primary)]">
                      {rule.id}. {rule.title}
                    </h3>
                  )}

                  {isEditing(rule.id) ? (
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-sm text-[var(--hsbc-red)] font-semibold">Weight:</span>
                      <input
                        type="number"
                        min={0}
                        max={100}
                        value={editForm[rule.id]?.weight ?? rule.weight}
                        onClick={(e) => e.stopPropagation()}
                        onChange={(e) =>
                          setEditForm((prev) => ({
                            ...prev,
                            [rule.id]: { ...(prev[rule.id] ?? { title: rule.title, weight: rule.weight, subItems: rule.subItems }), weight: Number(e.target.value) },
                          }))
                        }
                        className="hsbc-input text-sm w-20 py-1"
                      />
                      <span className="text-sm text-[var(--hsbc-red)] font-semibold">%</span>
                    </div>
                  ) : (
                    <p className="text-sm text-[var(--hsbc-red)] font-semibold mt-0.5">
                      Weight: {rule.weight}%
                    </p>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-3">
                {isEditing(rule.id) ? (
                  <>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        cancelEditing();
                      }}
                      className="flex items-center gap-2 px-4 py-2 text-sm font-semibold text-gray-500 hover:bg-gray-100 rounded-lg transition-colors"
                    >
                      <X className="w-3.5 h-3.5" />
                      Cancel
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        saveEditing(rule.id);
                      }}
                      className="hsbc-btn-primary px-4 py-2 flex items-center gap-2 text-sm"
                    >
                      <Save className="w-3.5 h-3.5" />
                      Save
                    </button>
                  </>
                ) : (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      startEditing(rule);
                    }}
                    className="flex items-center gap-2 px-4 py-2 text-sm font-semibold text-[var(--hsbc-blue)] hover:bg-[var(--hsbc-blue-light)] rounded-lg transition-colors"
                  >
                    <Pencil className="w-3.5 h-3.5" />
                    Edit Rule
                  </button>
                )}
                {expandedRule === rule.id ? (
                  <ChevronUp className="w-5 h-5 text-[var(--hsbc-text-muted)]" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-[var(--hsbc-text-muted)]" />
                )}
              </div>
            </div>

            {/* ── Expanded Content ── */}
            {expandedRule === rule.id && (
              <div className="px-6 pb-5 border-t border-[var(--hsbc-border)]">
                <div className="pt-4 space-y-4">
                  {(isEditing(rule.id)
                    ? (editForm[rule.id]?.subItems ?? rule.subItems)
                    : rule.subItems
                  ).map((item, index: number) => (
                    <div key={index} className="bg-[var(--hsbc-bg-main)] rounded-lg p-4">
                      {isEditing(rule.id) ? (
                        <div className="space-y-3">
                          <div>
                            <label className="block text-xs font-semibold text-[var(--hsbc-text-muted)] uppercase tracking-wider mb-1">
                              Sub-item Name
                            </label>
                            <input
                              type="text"
                              value={item.name}
                              onChange={(e) => updateSubItem(rule.id, index, "name", e.target.value)}
                              className="hsbc-input w-full text-sm"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-semibold text-[var(--hsbc-text-muted)] uppercase tracking-wider mb-1">
                              Scoring Criteria
                            </label>
                            <textarea
                              value={item.criteria}
                              onChange={(e) => updateSubItem(rule.id, index, "criteria", e.target.value)}
                              className="hsbc-input w-full text-sm min-h-[60px] resize-y"
                            />
                          </div>
                        </div>
                      ) : (
                        <>
                          <h4 className="text-sm font-semibold text-[var(--hsbc-text-primary)] mb-1">
                            Sub-item: {item.name}
                          </h4>
                          <p className="text-sm text-[var(--hsbc-text-muted)]">
                            Criteria: {item.criteria}
                          </p>
                        </>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
