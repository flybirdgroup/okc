import { useState } from "react";
import { Plus, Pencil, UserX, UserCheck } from "lucide-react";
import { useUsers } from "@/context/AppContext";
import type { User } from "@/context/AppContext";

export default function Users() {
  const { users, addUser, toggleStatus, deleteUser } = useUsers();
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [newUser, setNewUser] = useState<Partial<User>>({
    username: "",
    department: "",
    role: "Submitter",
    status: "Active",
  });

  const handleAdd = () => {
    if (newUser.username && newUser.department) {
      addUser({
        username: newUser.username,
        department: newUser.department,
        role: (newUser.role as User["role"]) || "Submitter",
        status: (newUser.status as User["status"]) || "Active",
      });
      setShowAddDialog(false);
      setNewUser({ username: "", department: "", role: "Submitter", status: "Active" });
    }
  };

  return (
    <div className="p-8 max-w-[1400px]">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-[32px] font-bold text-[var(--hsbc-text-primary)] tracking-tight">
          Admin Backend: Users
        </h1>
        <button onClick={() => setShowAddDialog(true)} className="hsbc-btn-primary px-5 py-2.5 flex items-center gap-2 text-sm">
          <Plus className="w-4 h-4" />
          Add User
        </button>
      </div>

      {/* Add User Dialog */}
      {showAddDialog && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-[var(--hsbc-bg-card)] rounded-xl p-6 w-[400px] border border-[var(--hsbc-border)]">
            <h2 className="text-lg font-bold text-[var(--hsbc-text-primary)] mb-4">Add New User</h2>
            <div className="space-y-3">
              <div>
                <label className="block text-sm text-[var(--hsbc-text-secondary)] mb-1">Username</label>
                <input value={newUser.username} onChange={(e) => setNewUser({ ...newUser, username: e.target.value })} className="hsbc-input w-full" placeholder="Enter username" />
              </div>
              <div>
                <label className="block text-sm text-[var(--hsbc-text-secondary)] mb-1">Department</label>
                <input value={newUser.department} onChange={(e) => setNewUser({ ...newUser, department: e.target.value })} className="hsbc-input w-full" placeholder="Enter department" />
              </div>
              <div>
                <label className="block text-sm text-[var(--hsbc-text-secondary)] mb-1">Role</label>
                <select value={newUser.role} onChange={(e) => setNewUser({ ...newUser, role: e.target.value as User["role"] })} className="hsbc-select w-full">
                  <option>Admin</option>
                  <option>Reviewer</option>
                  <option>Submitter</option>
                </select>
              </div>
            </div>
            <div className="flex gap-3 mt-5">
              <button onClick={() => setShowAddDialog(false)} className="flex-1 py-2.5 rounded-lg border border-[var(--hsbc-border)] text-sm font-medium hover:bg-[var(--hsbc-bg-main)] transition-colors">Cancel</button>
              <button onClick={handleAdd} className="hsbc-btn-primary flex-1 py-2.5 text-sm">Add User</button>
            </div>
          </div>
        </div>
      )}

      <div className="hsbc-card">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-[var(--hsbc-bg-main)]">
                <th className="hsbc-table-header">USERNAME</th>
                <th className="hsbc-table-header">DEPARTMENT</th>
                <th className="hsbc-table-header">ROLE</th>
                <th className="hsbc-table-header">STATUS</th>
                <th className="hsbc-table-header">ACTIONS</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr key={user.id} className="hover:bg-[var(--hsbc-bg-main)] transition-colors">
                  <td className="hsbc-table-cell font-medium text-[var(--hsbc-text-primary)]">{user.username}</td>
                  <td className="hsbc-table-cell">{user.department}</td>
                  <td className="hsbc-table-cell">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-md text-xs font-medium bg-[var(--hsbc-blue-light)] text-[var(--hsbc-blue)]">{user.role}</span>
                  </td>
                  <td className="hsbc-table-cell">
                    <span className={`hsbc-status-badge ${user.status === "Active" ? "hsbc-status-active" : "hsbc-status-inactive"}`}>{user.status}</span>
                  </td>
                  <td className="hsbc-table-cell">
                    <div className="flex items-center gap-2">
                      <button className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[var(--hsbc-blue)] hover:bg-[var(--hsbc-blue-light)] rounded-md transition-colors">
                        <Pencil className="w-3 h-3" /> Edit
                      </button>
                      <button
                        onClick={() => toggleStatus(user.id)}
                        className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                          user.status === "Active" ? "text-[#DC2626] hover:bg-red-50" : "text-[#16A34A] hover:bg-green-50"
                        }`}
                      >
                        {user.status === "Active" ? <><UserX className="w-3 h-3" /> Deactivate</> : <><UserCheck className="w-3 h-3" /> Reactivate</>}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
