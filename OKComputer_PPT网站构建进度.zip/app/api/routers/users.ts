import { z } from "zod";
import { eq, and } from "drizzle-orm";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { users } from "../../db/schema";

export const usersRouter = createRouter({
  // List all users with optional filters
  list: publicQuery
    .input(
      z.object({
        search: z.string().optional(),
        status: z.string().optional(),
      }).optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];

      if (input?.search) {
        conditions.push(eq(users.username, input.search));
      }
      if (input?.status && input.status !== "All") {
        conditions.push(eq(users.status, input.status));
      }

      const query = conditions.length > 0
        ? db.select().from(users).where(and(...conditions))
        : db.select().from(users);

      return await query;
    }),

  // Create user
  create: publicQuery
    .input(
      z.object({
        username: z.string().min(1),
        department: z.string().min(1),
        role: z.string(),
        status: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const result = await db.insert(users).values(input);
      return { success: true, insertId: Number(result[0].insertId) };
    }),

  // Update user
  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        data: z.object({
          username: z.string().optional(),
          department: z.string().optional(),
          role: z.string().optional(),
          status: z.string().optional(),
        }),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.update(users)
        .set({ ...input.data, updatedAt: new Date() })
        .where(eq(users.id, input.id));
      return { success: true };
    }),

  // Toggle status
  toggleStatus: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const user = await db.select().from(users).where(eq(users.id, input.id));
      if (!user[0]) throw new Error("User not found");

      const newStatus = user[0].status === "Active" ? "Inactive" : "Active";
      await db.update(users)
        .set({ status: newStatus, updatedAt: new Date() })
        .where(eq(users.id, input.id));
      return { success: true, newStatus };
    }),

  // Delete user
  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(users).where(eq(users.id, input.id));
      return { success: true };
    }),
});
