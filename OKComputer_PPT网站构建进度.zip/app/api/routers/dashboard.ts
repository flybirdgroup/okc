import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { projects } from "../../db/schema";
import { eq, sql } from "drizzle-orm";

export const dashboardRouter = createRouter({
  // Get KPI data
  kpi: publicQuery.query(async () => {
    const db = getDb();

    const totalProjects = await db.select({ count: sql<number>`COUNT(*)` }).from(projects);
    const highPriority = await db.select({ count: sql<number>`COUNT(*)` }).from(projects).where(eq(projects.priority, "HIGH"));
    const pendingReview = await db.select({ count: sql<number>`COUNT(*)` }).from(projects).where(eq(projects.status, "PENDING"));

    return {
      totalActiveProjects: totalProjects[0]?.count ?? 0,
      highPriorityItems: highPriority[0]?.count ?? 0,
      pendingReview: pendingReview[0]?.count ?? 0,
    };
  }),

  // Get priority distribution
  priorityDistribution: publicQuery.query(async () => {
    const db = getDb();
    const high = await db.select({ count: sql<number>`COUNT(*)` }).from(projects).where(eq(projects.priority, "HIGH"));
    const medium = await db.select({ count: sql<number>`COUNT(*)` }).from(projects).where(eq(projects.priority, "MEDIUM"));
    const low = await db.select({ count: sql<number>`COUNT(*)` }).from(projects).where(eq(projects.priority, "LOW"));

    return [
      { name: "High", value: high[0]?.count ?? 0, color: "#DA291C" },
      { name: "Medium", value: medium[0]?.count ?? 0, color: "#F59E0B" },
      { name: "Low", value: low[0]?.count ?? 0, color: "#3B82F6" },
    ];
  }),

  // Get active project monitoring data (top 5 projects by score)
  projectMonitoring: publicQuery.query(async () => {
    const db = getDb();
    const result = await db.select().from(projects).orderBy(sql`${projects.score} DESC`).limit(5);
    return result.map(p => ({
      name: p.name.split(" ").slice(0, 2).join(" "),
      score: Number(p.score),
    }));
  }),

  // Get recent projects for dashboard table
  recentProjects: publicQuery.query(async () => {
    const db = getDb();
    return await db.select().from(projects).orderBy(sql`${projects.id} DESC`).limit(5);
  }),
});
