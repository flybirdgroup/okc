import { z } from "zod";
import { eq } from "drizzle-orm";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { scoringRules, scoringRuleSubItems } from "../../db/schema";

export const scoringRulesRouter = createRouter({
  // List all scoring rules with their sub items
  list: publicQuery.query(async () => {
    const db = getDb();
    const rules = await db.select().from(scoringRules);

    // Fetch sub items for each rule
    const result = await Promise.all(
      rules.map(async (rule) => {
        const subItems = await db
          .select()
          .from(scoringRuleSubItems)
          .where(eq(scoringRuleSubItems.ruleId, rule.id));
        return {
          ...rule,
          subItems,
        };
      })
    );

    return result;
  }),

  // Get single scoring rule
  get: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const rule = await db.select().from(scoringRules).where(eq(scoringRules.id, input.id));
      if (!rule[0]) return null;

      const subItems = await db
        .select()
        .from(scoringRuleSubItems)
        .where(eq(scoringRuleSubItems.ruleId, input.id));

      return { ...rule[0], subItems };
    }),

  // Update scoring rule
  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        data: z.object({
          title: z.string().optional(),
          weight: z.string().optional(),
        }),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.update(scoringRules)
        .set({ ...input.data, updatedAt: new Date() })
        .where(eq(scoringRules.id, input.id));
      return { success: true };
    }),

  // Update sub item
  updateSubItem: publicQuery
    .input(
      z.object({
        id: z.number(),
        data: z.object({
          name: z.string().optional(),
          criteria: z.string().optional(),
        }),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.update(scoringRuleSubItems)
        .set({ ...input.data, updatedAt: new Date() })
        .where(eq(scoringRuleSubItems.id, input.id));
      return { success: true };
    }),
});
