import { z } from "zod";
import { eq, and, sql } from "drizzle-orm";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { apiLogs } from "../../db/schema";

export const apiLogsRouter = createRouter({
  // List all api logs with optional filters
  list: publicQuery
    .input(
      z.object({
        search: z.string().optional(),
        user: z.string().optional(),
        project: z.string().optional(),
      }).optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];

      if (input?.search) {
        conditions.push(
          sql`${apiLogs.user} LIKE ${`%${input.search}%`} OR ${apiLogs.project} LIKE ${`%${input.search}%`}`
        );
      }
      if (input?.user && input.user !== "All Users") {
        conditions.push(eq(apiLogs.user, input.user));
      }
      if (input?.project && input.project !== "All Proj") {
        conditions.push(eq(apiLogs.project, input.project));
      }

      const query = conditions.length > 0
        ? db.select().from(apiLogs).where(and(...conditions))
        : db.select().from(apiLogs);

      return await query;
    }),

  // Create api log
  create: publicQuery
    .input(
      z.object({
        timestamp: z.string(),
        user: z.string(),
        project: z.string(),
        action: z.string(),
        score: z.string().nullable(),
        status: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.insert(apiLogs).values(input);
      return { success: true };
    }),
});
