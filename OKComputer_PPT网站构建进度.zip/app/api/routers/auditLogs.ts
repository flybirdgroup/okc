import { z } from "zod";
import { and, sql } from "drizzle-orm";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { auditLogs } from "../../db/schema";

export const auditLogsRouter = createRouter({
  // List all audit logs with optional filters
  list: publicQuery
    .input(
      z.object({
        search: z.string().optional(),
        actionType: z.string().optional(),
      }).optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];

      if (input?.search) {
        conditions.push(
          sql`${auditLogs.userId} LIKE ${`%${input.search}%`}`
        );
      }
      if (input?.actionType && input.actionType !== "All") {
        conditions.push(
          sql`${auditLogs.action} LIKE ${`%${input.actionType}%`}`
        );
      }

      const query = conditions.length > 0
        ? db.select().from(auditLogs).where(and(...conditions))
        : db.select().from(auditLogs);

      return await query;
    }),

  // Create audit log
  create: publicQuery
    .input(
      z.object({
        timestamp: z.string(),
        userId: z.string(),
        action: z.string(),
        object: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.insert(auditLogs).values(input);
      return { success: true };
    }),
});
