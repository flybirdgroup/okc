import { z } from "zod";
import { eq, and, sql } from "drizzle-orm";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { projects } from "../../db/schema";

export const projectsRouter = createRouter({
  // List all projects with optional filters
  list: publicQuery
    .input(
      z.object({
        search: z.string().optional(),
        priority: z.string().optional(),
        status: z.string().optional(),
      }).optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];

      if (input?.search) {
        const search = `%${input.search}%`;
        conditions.push(
          sql`${projects.name} LIKE ${search} OR ${projects.projectId} LIKE ${search}`
        );
      }
      if (input?.priority && input.priority !== "All") {
        conditions.push(eq(projects.priority, input.priority.toUpperCase()));
      }
      if (input?.status && input.status !== "All") {
        conditions.push(eq(projects.status, input.status.toUpperCase()));
      }

      const query = conditions.length > 0
        ? db.select().from(projects).where(and(...conditions))
        : db.select().from(projects);

      return await query;
    }),

  // Get single project
  get: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db.select().from(projects).where(eq(projects.id, input.id));
      return result[0] ?? null;
    }),

  // Create project
  create: publicQuery
    .input(
      z.object({
        projectId: z.string().min(1),
        name: z.string().min(1),
        requestedBy: z.string().min(1),
        department: z.string().optional(),
        score: z.string(),
        priority: z.string(),
        status: z.string(),
        action: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const result = await db.insert(projects).values({
        ...input,
        score: input.score.toString(),
      });
      return { success: true, insertId: Number(result[0].insertId) };
    }),

  // Update project
  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        data: z.object({
          name: z.string().optional(),
          requestedBy: z.string().optional(),
          department: z.string().optional(),
          score: z.string().optional(),
          priority: z.string().optional(),
          status: z.string().optional(),
          action: z.string().optional(),
        }),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.update(projects)
        .set({
          ...input.data,
          updatedAt: new Date(),
        })
        .where(eq(projects.id, input.id));
      return { success: true };
    }),

  // Delete project
  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(projects).where(eq(projects.id, input.id));
      return { success: true };
    }),
});
