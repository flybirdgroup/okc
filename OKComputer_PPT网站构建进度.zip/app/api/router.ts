import { createRouter, publicQuery } from "./middleware";
import { projectsRouter } from "./routers/projects";
import { usersRouter } from "./routers/users";
import { scoringRulesRouter } from "./routers/scoringRules";
import { auditLogsRouter } from "./routers/auditLogs";
import { apiLogsRouter } from "./routers/apiLogs";
import { dashboardRouter } from "./routers/dashboard";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  projects: projectsRouter,
  users: usersRouter,
  scoringRules: scoringRulesRouter,
  auditLogs: auditLogsRouter,
  apiLogs: apiLogsRouter,
  dashboard: dashboardRouter,
});

export type AppRouter = typeof appRouter;
