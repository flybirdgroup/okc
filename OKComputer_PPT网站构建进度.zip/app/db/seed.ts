import { drizzle } from "drizzle-orm/mysql2";
import { createPool } from "mysql2/promise";
import * as schema from "./schema";

const { projects, users, scoringRules, scoringRuleSubItems, auditLogs, apiLogs } = schema;

const DATABASE_URL = process.env.DATABASE_URL ?? "mysql://hsbc_user:hsbc_pass@localhost:3306/hsbc_db";

async function seed() {
  const pool = createPool({ uri: DATABASE_URL, connectionLimit: 5 });
  const db = drizzle(pool, { schema, mode: "planetscale" });

  // ── Seed Projects ───────────────────────────────────────────────────
  const projectData = [
    { projectId: "P-2024-001", name: "2024 Core Banking Upg.", requestedBy: "Alex Morgan (IT Dept)", department: "IT", score: "92.5", priority: "HIGH", status: "APPROVED", action: "View Details" },
    { projectId: "P-2024-002", name: "Mobile App Redesign", requestedBy: "Sara Lee (Digital)", department: "Digital", score: "85.0", priority: "MEDIUM", status: "PENDING", action: "Download Report" },
    { projectId: "P-2024-003", name: "Cloud Migration Phase 2", requestedBy: "David Kim (Cloud Ops)", department: "Cloud Ops", score: "98.0", priority: "HIGH", status: "IN_REVIEW", action: "View Details" },
    { projectId: "P-2024-004", name: "CRM System Upgrade", requestedBy: "Lisa Wong (Sales)", department: "Sales", score: "76.5", priority: "LOW", status: "DRAFT", action: "Edit Project" },
    { projectId: "P-2024-005", name: "Retail Risk V2", requestedBy: "John Smith (Risk)", department: "Risk", score: "89.4", priority: "HIGH", status: "APPROVED", action: "View Details" },
    { projectId: "P-2024-006", name: "Wealth Management", requestedBy: "Emma Liu (Wealth)", department: "Wealth", score: "95.0", priority: "MEDIUM", status: "PENDING", action: "Download Report" },
    { projectId: "P-2024-007", name: "Trade Finance Hub", requestedBy: "Michael Chen (Trade)", department: "Trade", score: "76.5", priority: "MEDIUM", status: "IN_REVIEW", action: "View Details" },
    { projectId: "P-2024-008", name: "Cross-Border Data", requestedBy: "SVS Team", department: "SVS", score: "84.1", priority: "HIGH", status: "APPROVED", action: "View Details" },
  ];
  await db.insert(projects).values(projectData);
  console.log(`✓ Seeded ${projectData.length} projects`);

  // ── Seed Users ──────────────────────────────────────────────────────
  const userData = [
    { username: "Alex Morgan", department: "Retail Banking", role: "Admin", status: "Active" },
    { username: "Sam Lee", department: "Risk Management", role: "Reviewer", status: "Active" },
    { username: "Priya Patel", department: "Compliance", role: "Submitter", status: "Inactive" },
    { username: "David Kim", department: "Cloud Ops", role: "Admin", status: "Active" },
    { username: "Lisa Wong", department: "Sales", role: "Submitter", status: "Active" },
    { username: "John Smith", department: "Risk", role: "Reviewer", status: "Active" },
    { username: "Emma Liu", department: "Wealth", role: "Submitter", status: "Inactive" },
    { username: "Michael Chen", department: "Trade", role: "Reviewer", status: "Active" },
  ];
  await db.insert(users).values(userData);
  console.log(`✓ Seeded ${userData.length} users`);

  // ── Seed Scoring Rules ────────────────────────────────────────────────
  const ruleData = [
    { ruleId: "01", title: "Strategic Alignment", weight: "35.00" },
    { ruleId: "02", title: "Financial Viability", weight: "30.00" },
    { ruleId: "03", title: "Risk Assessment", weight: "20.00" },
    { ruleId: "04", title: "Operational Impact", weight: "15.00" },
  ];
  await db.insert(scoringRules).values(ruleData);
  console.log(`✓ Seeded ${ruleData.length} scoring rules`);

  // Get inserted rules to reference their auto-generated IDs for sub-items
  const insertedRules = await db.select().from(scoringRules);
  const ruleIdMap = new Map(insertedRules.map(r => [r.ruleId, r.id]));

  // ── Seed Scoring Rule Sub Items ───────────────────────────────────
  const subItemData = [
    // Rule 01: Strategic Alignment
    { ruleId: ruleIdMap.get("01")!, name: "Market Growth Potential", criteria: "High (4-5 pts), Medium (2-3 pts), Low (0-1 pt)" },
    { ruleId: ruleIdMap.get("01")!, name: "Brand Synergy", criteria: "Strong alignment (4-5 pts), Partial (2-3 pts), None (0-1 pt)" },
    // Rule 02: Financial Viability
    { ruleId: ruleIdMap.get("02")!, name: "ROI Projection", criteria: ">20% (5 pts), 10-20% (3 pts), <10% (1 pt)" },
    { ruleId: ruleIdMap.get("02")!, name: "Cost Efficiency", criteria: "Optimized (5 pts), Moderate (3 pts), Over-budget (1 pt)" },
    // Rule 03: Risk Assessment
    { ruleId: ruleIdMap.get("03")!, name: "Implementation Risk", criteria: "Low (4-5 pts), Medium (2-3 pts), High (0-1 pt)" },
    { ruleId: ruleIdMap.get("03")!, name: "Regulatory Compliance", criteria: "Full (5 pts), Partial (3 pts), Non-compliant (1 pt)" },
    // Rule 04: Operational Impact
    { ruleId: ruleIdMap.get("04")!, name: "Process Efficiency", criteria: "Major (4-5 pts), Moderate (2-3 pts), Minimal (0-1 pt)" },
    { ruleId: ruleIdMap.get("04")!, name: "Resource Availability", criteria: "Optimal (5 pts), Adequate (3 pts), Limited (1 pt)" },
  ];
  await db.insert(scoringRuleSubItems).values(subItemData);
  console.log(`✓ Seeded ${subItemData.length} scoring rule sub items`);

  // ── Seed Audit Logs ─────────────────────────────────────────────────
  const auditData = [
    { timestamp: "2024-03-15 14:22", userId: "admin_001", action: "Project Submitted", object: "P-2024-9102" },
    { timestamp: "2024-03-15 14:15", userId: "analyst_05", action: "Score Calculated", object: "Rule-Set: V2.1" },
    { timestamp: "2024-03-15 13:40", userId: "admin_001", action: "Rule Updated", object: "Rule-982-Config" },
    { timestamp: "2024-03-15 10:10", userId: "admin_002", action: "User Added", object: "new-user: temp_99" },
    { timestamp: "2024-04-18 10:15", userId: "jason_smith", action: "Analysis Submitted", object: "Cross-Border Data" },
    { timestamp: "2024-04-18 09:45", userId: "admin_001", action: "Project Approved", object: "P-2024-9101" },
    { timestamp: "2024-04-18 09:30", userId: "analyst_03", action: "Score Recalculated", object: "Rule-Set: V2.2" },
    { timestamp: "2024-04-17 16:20", userId: "admin_002", action: "User Deactivated", object: "user: temp_99" },
    { timestamp: "2024-04-17 14:00", userId: "sara_lee", action: "Project Updated", object: "P-2024-9100" },
    { timestamp: "2024-04-17 11:30", userId: "admin_001", action: "Rule Created", object: "Rule-983-Config" },
  ];
  await db.insert(auditLogs).values(auditData);
  console.log(`✓ Seeded ${auditData.length} audit logs`);

  // ── Seed API Logs ───────────────────────────────────────────────────
  const apiData = [
    { timestamp: "14:32:11 20/10", user: "john.s@hsbc", project: "Retail Risk V2", action: "Analysis Req", score: "89.4", status: "Success" },
    { timestamp: "13:15:02 20/10", user: "emma.l@hsbc", project: "Wealth Mgmt", action: "Data Sync", score: null, status: "Pending" },
    { timestamp: "10:05:47 20/10", user: "mike.t@hsbc", project: "Retail Risk V2", action: "Analysis Req", score: null, status: "Failed" },
    { timestamp: "09:22:19 20/10", user: "lisa.k@hsbc", project: "Trade Finance", action: "Health Check", score: "99.0", status: "Success" },
    { timestamp: "08:45:33 20/10", user: "alex.m@hsbc", project: "Core Banking", action: "Analysis Req", score: "92.5", status: "Success" },
    { timestamp: "08:12:05 20/10", user: "sara.l@hsbc", project: "Mobile App", action: "Data Sync", score: null, status: "Pending" },
    { timestamp: "07:58:41 20/10", user: "david.k@hsbc", project: "Cloud Migration", action: "Analysis Req", score: "98.0", status: "Success" },
    { timestamp: "07:30:15 20/10", user: "priya.p@hsbc", project: "Compliance Check", action: "Health Check", score: "87.2", status: "Success" },
  ];
  await db.insert(apiLogs).values(apiData);
  console.log(`✓ Seeded ${apiData.length} api logs`);

  console.log("\n🎉 Database seeding complete!");
}

seed().catch((err) => {
  console.error("Seed failed:", err);
  process.exit(1);
});
