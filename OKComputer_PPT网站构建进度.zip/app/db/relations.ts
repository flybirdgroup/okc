import { relations } from "drizzle-orm";
import { scoringRules, scoringRuleSubItems } from "./schema";

export const scoringRulesRelations = relations(scoringRules, ({ many }) => ({
  subItems: many(scoringRuleSubItems),
}));

export const scoringRuleSubItemsRelations = relations(scoringRuleSubItems, ({ one }) => ({
  rule: one(scoringRules, {
    fields: [scoringRuleSubItems.ruleId],
    references: [scoringRules.id],
  }),
}));
