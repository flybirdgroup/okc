import {
  mysqlTable,
  serial,
  varchar,
  text,
  timestamp,
  decimal,
  bigint,
} from "drizzle-orm/mysql-core";

// ── Projects ──────────────────────────────────────────────────────────
export const projects = mysqlTable("projects", {
  id: serial("id").primaryKey(),
  projectId: varchar("project_id", { length: 50 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  requestedBy: varchar("requested_by", { length: 255 }).notNull(),
  department: varchar("department", { length: 100 }),
  score: decimal("score", { precision: 5, scale: 1 }).notNull(),
  priority: varchar("priority", { length: 20 }).notNull(), // HIGH, MEDIUM, LOW
  status: varchar("status", { length: 30 }).notNull(),     // APPROVED, PENDING, IN_REVIEW, DRAFT
  action: varchar("action", { length: 50 }),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow().onUpdateNow(),
});

// ── Users ─────────────────────────────────────────────────────────────
export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 100 }).notNull(),
  department: varchar("department", { length: 100 }).notNull(),
  role: varchar("role", { length: 30 }).notNull(),          // Admin, Reviewer, Submitter
  status: varchar("status", { length: 20 }).notNull(),      // Active, Inactive
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow().onUpdateNow(),
});

// ── Scoring Rules ───────────────────────────────────────────────────
export const scoringRules = mysqlTable("scoring_rules", {
  id: serial("id").primaryKey(),
  ruleId: varchar("rule_id", { length: 10 }).notNull().unique(), // 01, 02, 03, 04
  title: varchar("title", { length: 255 }).notNull(),
  weight: decimal("weight", { precision: 5, scale: 2 }).notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow().onUpdateNow(),
});

// ── Scoring Rule Sub Items ──────────────────────────────────────────
export const scoringRuleSubItems = mysqlTable("scoring_rule_sub_items", {
  id: serial("id").primaryKey(),
  ruleId: bigint("rule_id", { mode: "number", unsigned: true }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  criteria: text("criteria").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow().onUpdateNow(),
});

// ── Audit Logs ──────────────────────────────────────────────────────
export const auditLogs = mysqlTable("audit_logs", {
  id: serial("id").primaryKey(),
  timestamp: varchar("timestamp", { length: 30 }).notNull(),
  userId: varchar("user_id", { length: 50 }).notNull(),
  action: varchar("action", { length: 100 }).notNull(),
  object: varchar("object", { length: 255 }).notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ── API & Analysis Logs ─────────────────────────────────────────────
export const apiLogs = mysqlTable("api_logs", {
  id: serial("id").primaryKey(),
  timestamp: varchar("timestamp", { length: 30 }).notNull(),
  user: varchar("user", { length: 100 }).notNull(),
  project: varchar("project", { length: 255 }).notNull(),
  action: varchar("action", { length: 100 }).notNull(),
  score: varchar("score", { length: 20 }),                 // can be "-" or number
  status: varchar("status", { length: 20 }).notNull(),      // Success, Pending, Failed
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
