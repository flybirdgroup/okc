from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()


class Project(db.Model):
    __tablename__ = 'projects'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    project_id = db.Column(db.String(50), unique=True, nullable=False)
    name = db.Column(db.String(255), nullable=False)
    requested_by = db.Column(db.String(255), nullable=False)
    department = db.Column(db.String(100))
    score = db.Column(db.Numeric(5, 1), nullable=False)
    priority = db.Column(db.String(20), nullable=False)   # HIGH, MEDIUM, LOW
    status = db.Column(db.String(30), nullable=False)     # APPROVED, PENDING, IN_REVIEW, DRAFT
    action = db.Column(db.String(50), default='View Details')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'project_id': self.project_id,
            'name': self.name,
            'requested_by': self.requested_by,
            'department': self.department,
            'score': float(self.score),
            'priority': self.priority,
            'status': self.status,
            'action': self.action,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
        }


class User(db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(100), nullable=False)
    department = db.Column(db.String(100), nullable=False)
    role = db.Column(db.String(30), nullable=False)       # Admin, Reviewer, Submitter
    status = db.Column(db.String(20), nullable=False)     # Active, Inactive
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'department': self.department,
            'role': self.role,
            'status': self.status,
            'created_at': self.created_at.isoformat() if self.created_at else None,
        }


class ScoringRule(db.Model):
    __tablename__ = 'scoring_rules'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    rule_id = db.Column(db.String(10), unique=True, nullable=False)
    title = db.Column(db.String(255), nullable=False)
    weight = db.Column(db.Numeric(5, 2), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    sub_items = db.relationship('ScoringRuleSubItem', backref='rule', lazy=True, cascade='all, delete-orphan')

    def to_dict(self):
        return {
            'id': self.id,
            'rule_id': self.rule_id,
            'title': self.title,
            'weight': float(self.weight),
            'sub_items': [si.to_dict() for si in self.sub_items],
        }


class ScoringRuleSubItem(db.Model):
    __tablename__ = 'scoring_rule_sub_items'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    rule_id = db.Column(db.Integer, db.ForeignKey('scoring_rules.id'), nullable=False)
    name = db.Column(db.String(255), nullable=False)
    criteria = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'rule_id': self.rule_id,
            'name': self.name,
            'criteria': self.criteria,
        }


class AuditLog(db.Model):
    __tablename__ = 'audit_logs'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    timestamp = db.Column(db.String(30), nullable=False)
    user_id = db.Column(db.String(50), nullable=False)
    action = db.Column(db.String(100), nullable=False)
    object = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'timestamp': self.timestamp,
            'user_id': self.user_id,
            'action': self.action,
            'object': self.object,
        }


class ApiLog(db.Model):
    __tablename__ = 'api_logs'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    timestamp = db.Column(db.String(30), nullable=False)
    user = db.Column(db.String(100), nullable=False)
    project = db.Column(db.String(255), nullable=False)
    action = db.Column(db.String(100), nullable=False)
    score = db.Column(db.String(20), nullable=True)
    status = db.Column(db.String(20), nullable=False)    # Success, Pending, Failed
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'timestamp': self.timestamp,
            'user': self.user,
            'project': self.project,
            'action': self.action,
            'score': self.score,
            'status': self.status,
        }
