from flask import Flask, render_template, request, jsonify, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from datetime import datetime
import os

app = Flask(__name__)

# Database config - SQLite (no MySQL needed!)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(os.path.dirname(os.path.abspath(__file__)), 'hsbc_admin.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'hsbc-admin-secret-key'

CORS(app)

from models import db, Project, User, ScoringRule, ScoringRuleSubItem, AuditLog, ApiLog
db.init_app(app)


# ============================================================
# Helper: add audit log
# ============================================================
def log_action(action, obj):
    log = AuditLog(
        timestamp=datetime.now().strftime('%Y-%m-%d %H:%M'),
        user_id='admin_001',
        action=action,
        object=obj,
    )
    db.session.add(log)
    db.session.commit()


# ============================================================
# Dashboard
# ============================================================
@app.route('/')
def dashboard():
    total_projects = Project.query.count()
    high_priority = Project.query.filter_by(priority='HIGH').count()
    pending_review = Project.query.filter_by(status='PENDING').count()

    priority_dist = [
        {'name': 'High', 'value': Project.query.filter_by(priority='HIGH').count(), 'color': '#DA291C'},
        {'name': 'Medium', 'value': Project.query.filter_by(priority='MEDIUM').count(), 'color': '#F59E0B'},
        {'name': 'Low', 'value': Project.query.filter_by(priority='LOW').count(), 'color': '#3B82F6'},
    ]

    # Top 5 projects by score for chart
    top_projects = Project.query.order_by(Project.score.desc()).limit(5).all()
    bar_data = [{'name': ' '.join(p.name.split()[:2]), 'score': float(p.score)} for p in top_projects]

    # Recent 5 projects for table
    recent_projects = Project.query.order_by(Project.id.desc()).limit(5).all()

    return render_template(
        'dashboard.html',
        active_page='dashboard',
        kpi={'total': total_projects, 'high': high_priority, 'pending': pending_review},
        priority_dist=priority_dist,
        bar_data=bar_data,
        recent_projects=recent_projects,
    )


# ============================================================
# Projects
# ============================================================
@app.route('/projects')
def projects_page():
    search = request.args.get('search', '')
    priority_filter = request.args.get('priority', 'All')
    status_filter = request.args.get('status', 'All')

    query = Project.query
    if search:
        query = query.filter(db.or_(
            Project.name.ilike(f'%{search}%'),
            Project.project_id.ilike(f'%{search}%')
        ))
    if priority_filter != 'All':
        query = query.filter_by(priority=priority_filter.upper())
    if status_filter != 'All':
        query = query.filter_by(status=status_filter.upper())

    projects = query.all()
    return render_template(
        'projects.html',
        active_page='projects',
        projects=projects,
        search=search,
        priority_filter=priority_filter,
        status_filter=status_filter,
    )


@app.route('/projects/create', methods=['POST'])
def create_project():
    name = request.form.get('name')
    requested_by = request.form.get('requested_by')
    score = float(request.form.get('score', 80))
    priority = request.form.get('priority', 'MEDIUM')
    status = request.form.get('status', 'DRAFT')

    project_id = f'P-{datetime.now().strftime("%Y%m%d-%H%M%S")}'

    new_project = Project(
        project_id=project_id,
        name=name,
        requested_by=requested_by,
        score=score,
        priority=priority,
        status=status,
    )
    db.session.add(new_project)
    db.session.commit()
    log_action('Project Created', project_id)

    return redirect(url_for('projects_page'))


@app.route('/projects/delete/<int:project_db_id>', methods=['POST'])
def delete_project(project_db_id):
    project = Project.query.get_or_404(project_db_id)
    db.session.delete(project)
    db.session.commit()
    log_action('Project Deleted', project.project_id)
    return redirect(url_for('projects_page'))


# ============================================================
# Scoring Rules
# ============================================================
@app.route('/scoring-rules')
def scoring_rules_page():
    rules = ScoringRule.query.all()
    return render_template(
        'scoring_rules.html',
        active_page='scoring_rules',
        rules=rules,
    )


@app.route('/scoring-rules/update/<int:rule_db_id>', methods=['POST'])
def update_scoring_rule(rule_db_id):
    rule = ScoringRule.query.get_or_404(rule_db_id)

    rule.title = request.form.get('title', rule.title)
    rule.weight = float(request.form.get('weight', rule.weight))
    db.session.commit()

    # Update sub-items
    sub_item_ids = request.form.getlist('sub_item_id[]')
    sub_names = request.form.getlist('sub_name[]')
    sub_criteria = request.form.getlist('sub_criteria[]')

    for si_id, si_name, si_criteria in zip(sub_item_ids, sub_names, sub_criteria):
        sub_item = ScoringRuleSubItem.query.get(int(si_id))
        if sub_item and sub_item.rule_id == rule_db_id:
            sub_item.name = si_name
            sub_item.criteria = si_criteria

    db.session.commit()
    log_action('Rule Updated', rule.rule_id)

    return redirect(url_for('scoring_rules_page'))


# ============================================================
# Users
# ============================================================
@app.route('/users')
def users_page():
    users = User.query.all()
    return render_template(
        'users.html',
        active_page='users',
        users=users,
    )


@app.route('/users/create', methods=['POST'])
def create_user():
    username = request.form.get('username')
    department = request.form.get('department')
    role = request.form.get('role', 'Submitter')
    status = request.form.get('status', 'Active')

    new_user = User(
        username=username,
        department=department,
        role=role,
        status=status,
    )
    db.session.add(new_user)
    db.session.commit()
    log_action('User Added', username)

    return redirect(url_for('users_page'))


@app.route('/users/toggle/<int:user_db_id>', methods=['POST'])
def toggle_user_status(user_db_id):
    user = User.query.get_or_404(user_db_id)
    user.status = 'Inactive' if user.status == 'Active' else 'Active'
    db.session.commit()
    log_action('User ' + ('Deactivated' if user.status == 'Inactive' else 'Reactivated'), user.username)
    return redirect(url_for('users_page'))


@app.route('/users/delete/<int:user_db_id>', methods=['POST'])
def delete_user(user_db_id):
    user = User.query.get_or_404(user_db_id)
    db.session.delete(user)
    db.session.commit()
    log_action('User Deleted', user.username)
    return redirect(url_for('users_page'))


# ============================================================
# Audit Logs
# ============================================================
@app.route('/audit-logs')
def audit_logs_page():
    logs = AuditLog.query.order_by(AuditLog.id.desc()).all()
    return render_template(
        'audit_logs.html',
        active_page='audit_logs',
        logs=logs,
    )


# ============================================================
# API & Analysis Logs
# ============================================================
@app.route('/api-logs')
def api_logs_page():
    logs = ApiLog.query.all()
    return render_template(
        'api_logs.html',
        active_page='api_logs',
        logs=logs,
    )


# ============================================================
# API Routes (JSON)
# ============================================================
@app.route('/api/dashboard/kpi')
def api_kpi():
    return jsonify({
        'total_active_projects': Project.query.count(),
        'high_priority_items': Project.query.filter_by(priority='HIGH').count(),
        'pending_review': Project.query.filter_by(status='PENDING').count(),
    })


@app.route('/api/projects')
def api_projects():
    projects = Project.query.all()
    return jsonify([p.to_dict() for p in projects])


# ============================================================
# Seed data
# ============================================================
@app.route('/seed')
def seed():
    # Clear existing data
    db.session.query(ApiLog).delete()
    db.session.query(AuditLog).delete()
    db.session.query(ScoringRuleSubItem).delete()
    db.session.query(ScoringRule).delete()
    db.session.query(User).delete()
    db.session.query(Project).delete()
    db.session.commit()

    # Seed Projects
    project_data = [
        ('P-2024-001', '2024 Core Banking Upg.', 'Alex Morgan (IT Dept)', 'IT', 92.5, 'HIGH', 'APPROVED'),
        ('P-2024-002', 'Mobile App Redesign', 'Sara Lee (Digital)', 'Digital', 85.0, 'MEDIUM', 'PENDING'),
        ('P-2024-003', 'Cloud Migration Phase 2', 'David Kim (Cloud Ops)', 'Cloud Ops', 98.0, 'HIGH', 'IN_REVIEW'),
        ('P-2024-004', 'CRM System Upgrade', 'Lisa Wong (Sales)', 'Sales', 76.5, 'LOW', 'DRAFT'),
        ('P-2024-005', 'Retail Risk V2', 'John Smith (Risk)', 'Risk', 89.4, 'HIGH', 'APPROVED'),
        ('P-2024-006', 'Wealth Management', 'Emma Liu (Wealth)', 'Wealth', 95.0, 'MEDIUM', 'PENDING'),
        ('P-2024-007', 'Trade Finance Hub', 'Michael Chen (Trade)', 'Trade', 76.5, 'MEDIUM', 'IN_REVIEW'),
        ('P-2024-008', 'Cross-Border Data', 'SVS Team', 'SVS', 84.1, 'HIGH', 'APPROVED'),
    ]
    for pid, name, req_by, dept, score, pri, stat in project_data:
        db.session.add(Project(project_id=pid, name=name, requested_by=req_by, department=dept, score=score, priority=pri, status=stat))

    # Seed Users
    user_data = [
        ('Alex Morgan', 'Retail Banking', 'Admin', 'Active'),
        ('Sam Lee', 'Risk Management', 'Reviewer', 'Active'),
        ('Priya Patel', 'Compliance', 'Submitter', 'Inactive'),
        ('David Kim', 'Cloud Ops', 'Admin', 'Active'),
        ('Lisa Wong', 'Sales', 'Submitter', 'Active'),
        ('John Smith', 'Risk', 'Reviewer', 'Active'),
        ('Emma Liu', 'Wealth', 'Submitter', 'Inactive'),
        ('Michael Chen', 'Trade', 'Reviewer', 'Active'),
    ]
    for username, dept, role, status in user_data:
        db.session.add(User(username=username, department=dept, role=role, status=status))

    # Seed Scoring Rules
    rules_data = [
        ('01', 'Strategic Alignment', 35.00),
        ('02', 'Financial Viability', 30.00),
        ('03', 'Risk Assessment', 20.00),
        ('04', 'Operational Impact', 15.00),
    ]
    for rid, title, weight in rules_data:
        db.session.add(ScoringRule(rule_id=rid, title=title, weight=weight))
    db.session.commit()

    # Seed Sub Items
    sub_items_data = [
        (1, 'Market Growth Potential', 'High (4-5 pts), Medium (2-3 pts), Low (0-1 pt)'),
        (1, 'Brand Synergy', 'Strong alignment (4-5 pts), Partial (2-3 pts), None (0-1 pt)'),
        (2, 'ROI Projection', '>20% (5 pts), 10-20% (3 pts), <10% (1 pt)'),
        (2, 'Cost Efficiency', 'Optimized (5 pts), Moderate (3 pts), Over-budget (1 pt)'),
        (3, 'Implementation Risk', 'Low (4-5 pts), Medium (2-3 pts), High (0-1 pt)'),
        (3, 'Regulatory Compliance', 'Full (5 pts), Partial (3 pts), Non-compliant (1 pt)'),
        (4, 'Process Efficiency', 'Major (4-5 pts), Moderate (2-3 pts), Minimal (0-1 pt)'),
        (4, 'Resource Availability', 'Optimal (5 pts), Adequate (3 pts), Limited (1 pt)'),
    ]
    for rule_id, name, criteria in sub_items_data:
        db.session.add(ScoringRuleSubItem(rule_id=rule_id, name=name, criteria=criteria))

    # Seed Audit Logs
    audit_data = [
        ('2024-03-15 14:22', 'admin_001', 'Project Submitted', 'P-2024-9102'),
        ('2024-03-15 14:15', 'analyst_05', 'Score Calculated', 'Rule-Set: V2.1'),
        ('2024-03-15 13:40', 'admin_001', 'Rule Updated', 'Rule-982-Config'),
        ('2024-03-15 10:10', 'admin_002', 'User Added', 'new-user: temp_99'),
        ('2024-04-18 10:15', 'jason_smith', 'Analysis Submitted', 'Cross-Border Data'),
        ('2024-04-18 09:45', 'admin_001', 'Project Approved', 'P-2024-9101'),
        ('2024-04-18 09:30', 'analyst_03', 'Score Recalculated', 'Rule-Set: V2.2'),
        ('2024-04-17 16:20', 'admin_002', 'User Deactivated', 'user: temp_99'),
        ('2024-04-17 14:00', 'sara_lee', 'Project Updated', 'P-2024-9100'),
        ('2024-04-17 11:30', 'admin_001', 'Rule Created', 'Rule-983-Config'),
    ]
    for ts, uid, action, obj in audit_data:
        db.session.add(AuditLog(timestamp=ts, user_id=uid, action=action, object=obj))

    # Seed API Logs
    api_data = [
        ('14:32:11 20/10', 'john.s@hsbc', 'Retail Risk V2', 'Analysis Req', '89.4', 'Success'),
        ('13:15:02 20/10', 'emma.l@hsbc', 'Wealth Mgmt', 'Data Sync', None, 'Pending'),
        ('10:05:47 20/10', 'mike.t@hsbc', 'Retail Risk V2', 'Analysis Req', None, 'Failed'),
        ('09:22:19 20/10', 'lisa.k@hsbc', 'Trade Finance', 'Health Check', '99.0', 'Success'),
        ('08:45:33 20/10', 'alex.m@hsbc', 'Core Banking', 'Analysis Req', '92.5', 'Success'),
        ('08:12:05 20/10', 'sara.l@hsbc', 'Mobile App', 'Data Sync', None, 'Pending'),
        ('07:58:41 20/10', 'david.k@hsbc', 'Cloud Migration', 'Analysis Req', '98.0', 'Success'),
        ('07:30:15 20/10', 'priya.p@hsbc', 'Compliance Check', 'Health Check', '87.2', 'Success'),
    ]
    for ts, user, project, action, score, status in api_data:
        db.session.add(ApiLog(timestamp=ts, user=user, project=project, action=action, score=score, status=status))

    db.session.commit()
    return 'Database seeded successfully!'


# ============================================================
# Init database
# ============================================================
@app.route('/init-db')
def init_db():
    with app.app_context():
        db.create_all()
    return 'Database tables created!'


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True, host='0.0.0.0', port=5000)
