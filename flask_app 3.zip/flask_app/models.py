from sqlalchemy import Column, Integer, String, Text, Numeric, DateTime, ForeignKey, or_
from sqlalchemy.orm import relationship
from datetime import datetime
from database import Base


# ── SVS ──────────────────────────────────────────────────────────────
class SVS(Base):
    __tablename__ = 'svs'

    id = Column(Integer, primary_key=True, autoincrement=True)
    svs_id = Column(String(50), unique=True, nullable=False)
    name = Column(String(255), nullable=False)
    description = Column(Text)
    owner = Column(String(255), nullable=False)
    priority = Column(String(20), nullable=False)
    status = Column(String(30), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    tickets = relationship('Ticket', backref='svs', lazy=True, cascade='all, delete-orphan')

    def to_dict(self):
        return {
            'id': self.id,
            'svs_id': self.svs_id,
            'name': self.name,
            'description': self.description,
            'owner': self.owner,
            'priority': self.priority,
            'status': self.status,
            'ticket_count': len(self.tickets) if self.tickets else 0,
        }


# ── Ticket ───────────────────────────────────────────────────────────
class Ticket(Base):
    __tablename__ = 'tickets'

    id = Column(Integer, primary_key=True, autoincrement=True)
    ticket_id = Column(String(50), unique=True, nullable=False)
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=False)
    svs_id = Column(Integer, ForeignKey('svs.id'), nullable=False)
    requested_by = Column(String(255))
    department = Column(String(100))
    score = Column(Numeric(6, 2))
    priority = Column(String(20), nullable=False)
    status = Column(String(30), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'ticket_id': self.ticket_id,
            'title': self.title,
            'description': self.description,
            'svs_id': self.svs_id,
            'svs': self.svs.to_dict() if self.svs else None,
            'requested_by': self.requested_by,
            'department': self.department,
            'score': float(self.score) if self.score else None,
            'priority': self.priority,
            'status': self.status,
        }


# ── Scoring Rule Category ───────────────────────────────────────────
class ScoringRule(Base):
    __tablename__ = 'scoring_rules'

    id = Column(Integer, primary_key=True, autoincrement=True)
    rule_id = Column(String(10), unique=True, nullable=False)
    title = Column(String(255), nullable=False)
    weight = Column(Numeric(5, 2), nullable=False)
    order = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    sub_items = relationship('ScoringRuleSubItem', backref='rule', lazy=True,
                             cascade='all, delete-orphan', order_by='ScoringRuleSubItem.order')

    def to_dict(self):
        return {
            'id': self.id,
            'rule_id': self.rule_id,
            'title': self.title,
            'weight': float(self.weight),
            'sub_items': [si.to_dict() for si in self.sub_items],
        }

    def to_agent_payload(self):
        return {
            'rule_id': self.rule_id,
            'category': self.title,
            'weight': float(self.weight),
            'subcategories': [si.to_agent_payload() for si in self.sub_items],
        }


# ── Scoring Rule Sub Item ──────────────────────────────────────────
class ScoringRuleSubItem(Base):
    __tablename__ = 'scoring_rule_sub_items'

    id = Column(Integer, primary_key=True, autoincrement=True)
    rule_id = Column(Integer, ForeignKey('scoring_rules.id'), nullable=False)
    name = Column(String(255), nullable=False)
    sub_weight = Column(Numeric(5, 2), default=50.00)
    criteria = Column(Text)
    order = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    rubric_rows = relationship('ScoringRubric', backref='sub_item', lazy=True,
                                  cascade='all, delete-orphan', order_by='ScoringRubric.score_level')

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'sub_weight': float(self.sub_weight),
            'criteria': self.criteria,
            'rubric_rows': [r.to_dict() for r in self.rubric_rows],
        }

    def to_agent_payload(self):
        return {
            'name': self.name,
            'sub_weight': float(self.sub_weight),
            'rubric': {str(r.score_level): r.description for r in self.rubric_rows},
        }


# ── Scoring Rubric (1-5) ──────────────────────────────────────────
class ScoringRubric(Base):
    __tablename__ = 'scoring_rubrics'

    id = Column(Integer, primary_key=True, autoincrement=True)
    sub_item_id = Column(Integer, ForeignKey('scoring_rule_sub_items.id'), nullable=False)
    score_level = Column(Integer, nullable=False)
    description = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'score_level': self.score_level,
            'description': self.description,
        }


# ── Scoring Request Log (Audit) ───────────────────────────────────
class ScoringRequestLog(Base):
    __tablename__ = 'scoring_request_logs'

    id = Column(Integer, primary_key=True, autoincrement=True)
    request_id = Column(String(50), unique=True, nullable=False)
    ticket_id = Column(Integer, ForeignKey('tickets.id'), nullable=False)
    status = Column(String(20), default='pending')
    request_payload = Column(Text)
    response_payload = Column(Text)
    scores = Column(Text)
    total_score = Column(Numeric(6, 2))
    processing_time_ms = Column(Integer)
    error_message = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime)

    def to_dict(self):
        return {
            'id': self.id,
            'request_id': self.request_id,
            'ticket_id': self.ticket_id,
            'status': self.status,
            'scores': self.scores,
            'total_score': float(self.total_score) if self.total_score else None,
            'processing_time_ms': self.processing_time_ms,
            'error_message': self.error_message,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
        }


# ── Audit Log ──────────────────────────────────────────────────────
class AuditLog(Base):
    __tablename__ = 'audit_logs'

    id = Column(Integer, primary_key=True, autoincrement=True)
    timestamp = Column(String(30), nullable=False)
    user_id = Column(String(50), nullable=False)
    action = Column(String(100), nullable=False)
    object_type = Column(String(50))
    object_id = Column(String(50))
    details = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'timestamp': self.timestamp,
            'user_id': self.user_id,
            'action': self.action,
            'object_type': self.object_type,
            'object_id': self.object_id,
            'details': self.details,
        }


# ── User ────────────────────────────────────────────────────────────
class User(Base):
    __tablename__ = 'users'

    id = Column(Integer, primary_key=True, autoincrement=True)
    staff_id = Column(String(50), unique=True, nullable=False)   # ← SSO staff ID
    username = Column(String(100), nullable=False)                # ← display name
    department = Column(String(100), nullable=False)
    role = Column(String(30), nullable=False, default='Submitter')
    status = Column(String(20), nullable=False, default='Active')
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'staff_id': self.staff_id,
            'username': self.username,
            'department': self.department,
            'role': self.role,
            'status': self.status,
        }


# ── API Log ─────────────────────────────────────────────────────────
class ApiLog(Base):
    __tablename__ = 'api_logs'

    id = Column(Integer, primary_key=True, autoincrement=True)
    timestamp = Column(String(30), nullable=False)
    user = Column(String(100), nullable=False)
    project = Column(String(255), nullable=False)
    action = Column(String(100), nullable=False)
    score = Column(String(20))
    status = Column(String(20), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'timestamp': self.timestamp,
            'user': self.user,
            'project': self.project,
            'action': self.action,
            'score': self.score,
            'status': self.status,
        }
