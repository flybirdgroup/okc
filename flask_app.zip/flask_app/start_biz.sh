#!/bin/bash
# HSBC Business Frontend — Standalone Service
# Port: 5001
# Proxies API calls to Admin backend (:5000) with hidden API Key

cd "$(dirname "$0")"

# Load environment
if [ -f .env ]; then
    export $(grep -v '^#' .env | xargs)
fi

# Check env
if [ -z "$API_KEY" ]; then
    echo "ERROR: API_KEY not set in .env"
    echo "Add: API_KEY=your-api-key-here"
    exit 1
fi

if [ -z "$ADMIN_API_URL" ]; then
    export ADMIN_API_URL="http://localhost:5000"
    echo "Using default ADMIN_API_URL=$ADMIN_API_URL"
fi

echo "Starting HSBC Business Frontend..."
echo "  Port: 5001"
echo "  Admin API: $ADMIN_API_URL"
echo "  API Key: ${API_KEY:0:4}**** (hidden)"
echo ""

python3 -m uvicorn biz_app:app --host 0.0.0.0 --port 5001 --reload
