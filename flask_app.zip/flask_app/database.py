from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
import os

# Load .env file if python-dotenv is available and path is provided
_env_file = os.environ.get('ENV_FILE_PATH')
if _env_file:
    try:
        from dotenv import load_dotenv
        load_dotenv(_env_file, override=True)
    except ImportError:
        pass

# Read from env var; fallback to SQLite for local dev
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
default_sqlite = 'sqlite:///' + os.path.join(BASE_DIR, 'hsbc_admin.db')
DATABASE_URL = os.environ.get('DATABASE_URL', default_sqlite)

engine = create_engine(DATABASE_URL, echo=False, future=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    """FastAPI dependency: yield a database session."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
