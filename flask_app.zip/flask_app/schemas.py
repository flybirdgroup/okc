from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime


# ── SVS ──────────────────────────────────────────────────────────────
class SVSCreate(BaseModel):
    name: str
    owner: str
    priority: str = "MEDIUM"
    status: str = "ACTIVE"
    description: Optional[str] = None


class SVSResponse(BaseModel):
    id: int
    svs_id: str
    name: str
    description: Optional[str]
    owner: str
    priority: str
    status: str
    ticket_count: int = 0

    class Config:
        from_attributes = True


# ── Ticket ───────────────────────────────────────────────────────────
class TicketCreate(BaseModel):
    title: str
    description: str = ""
    svs_id: int
    requested_by: Optional[str] = None
    department: Optional[str] = None
    priority: str = "MEDIUM"
    status: str = "DRAFT"


class TicketResponse(BaseModel):
    id: int
    ticket_id: str
    title: str
    description: str
    svs_id: int
    svs: Optional[dict]
    requested_by: Optional[str]
    department: Optional[str]
    score: Optional[float]
    priority: str
    status: str

    class Config:
        from_attributes = True


# ── Scoring Rules ───────────────────────────────────────────────────
class RubricRow(BaseModel):
    score_level: int
    description: str


class SubItemCreate(BaseModel):
    name: str
    sub_weight: float = 50.0
    criteria: Optional[str] = None
    rubric_rows: List[RubricRow] = []


class ScoringRuleCreate(BaseModel):
    rule_id: str
    title: str
    weight: float
    sub_items: List[SubItemCreate] = []


class ScoringRuleResponse(BaseModel):
    id: int
    rule_id: str
    title: str
    weight: float
    sub_items: List[dict]

    class Config:
        from_attributes = True


# ── Score ────────────────────────────────────────────────────────────
class ScoreRequest(BaseModel):
    svs: str
    ticket: str
    description: str = ""


class ScoreResponse(BaseModel):
    request_id: str
    status: str
    ticket: dict
    total_score: float
    evidence: List[dict]
    reasoning_summary: str
    processing_time_ms: int


class ConfirmRequest(BaseModel):
    svs: str
    ticket: str


class ConfirmResponse(BaseModel):
    status: str
    ticket: dict


# ── Scoring Log ──────────────────────────────────────────────────────
class ScoringLogResponse(BaseModel):
    id: int
    request_id: str
    ticket_id: int
    status: str
    total_score: Optional[float]
    processing_time_ms: Optional[int]
    error_message: Optional[str]
    created_at: Optional[str]
    completed_at: Optional[str]

    class Config:
        from_attributes = True


# ── Audit Log ────────────────────────────────────────────────────────
class AuditLogResponse(BaseModel):
    id: int
    timestamp: str
    user_id: str
    action: str
    object_type: Optional[str]
    object_id: Optional[str]
    details: Optional[str]

    class Config:
        from_attributes = True


# ── User ──────────────────────────────────────────────────────────────
class UserCreate(BaseModel):
    username: str
    department: str
    role: str = "Submitter"
    status: str = "Active"


class UserResponse(BaseModel):
    id: int
    username: str
    department: str
    role: str
    status: str

    class Config:
        from_attributes = True


# ── API Log ───────────────────────────────────────────────────────────
class ApiLogResponse(BaseModel):
    id: int
    timestamp: str
    user: str
    project: str
    action: str
    score: Optional[str]
    status: str

    class Config:
        from_attributes = True


# ── Dashboard ─────────────────────────────────────────────────────────
class DashboardKPI(BaseModel):
    total_svs: int
    total_tickets: int
    high: int
    pending: int


class PriorityDistItem(BaseModel):
    name: str
    value: int
    color: str


class BarDataItem(BaseModel):
    name: str
    score: int


class DashboardResponse(BaseModel):
    kpi: DashboardKPI
    priority_dist: List[PriorityDistItem]
    recent_tickets: List[TicketResponse]
    svs_list: List[SVSResponse]
    bar_data: List[BarDataItem]
