#!/usr/bin/env python3
"""
HSBC Business Frontend — Review Mode
Port: 5001

Flow: User writes desc → AI Review → Suggestions list → User picks Apply/Ignore → Iterate → Score
"""

from fastapi import FastAPI, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.sessions import SessionMiddleware
import httpx, os, re

ADMIN_API_URL = os.environ.get('ADMIN_API_URL', 'http://localhost:5000')
API_KEY       = os.environ.get('API_KEY', '')
SECRET_KEY    = os.environ.get('SECRET_KEY', 'biz-session-secret-change-me')

app = FastAPI(title="HSBC Biz Frontend", version="4.0")
templates = Jinja2Templates(directory="templates")
app.add_middleware(SessionMiddleware, secret_key=SECRET_KEY, max_age=3600)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# ── Dimensions ──
DIMS = [
    {"id": "sa-fit",    "cat": "Strategic Alignment",     "sub": "Strategic Fit",           "kw": ["strategy", "strategic", "goal", "align", "objective", "digital", "transformation", "vision", "mission"], "tip": "Describe how this project aligns with HSBC strategic goals (e.g., digital transformation, cross-border growth)."},
    {"id": "sa-exec",   "cat": "Strategic Alignment",     "sub": "Executive Sponsorship",   "kw": ["executive", "sponsor", "cio", "ceo", "cfo", "coo", "support", "approval", "backing", "champion", "board"], "tip": "Mention which executive (CIO, CEO, etc.) sponsors this and their level of involvement."},
    {"id": "tc-tech",   "cat": "Technical Complexity",    "sub": "Technology Innovation",   "kw": ["technology", "tech", "ai", "machine learning", "ml", "cloud", "microservice", "architecture", "blockchain", "kubernetes", "framework"], "tip": "Include the core technology stack and whether it's a new breakthrough or system upgrade."},
    {"id": "tc-integ",  "cat": "Technical Complexity",    "sub": "Integration Complexity",  "kw": ["integrate", "integration", "system", "platform", "api", "connect", "interface", "legacy"], "tip": "Specify how many existing systems/platforms need integration and data exchange complexity."},
    {"id": "bv-rev",    "cat": "Business Value",          "sub": "Revenue Impact",          "kw": ["revenue", "income", "profit", "sales", "customer", "growth", "roi", "business value", "market"], "tip": "Quantify the revenue impact: new customers, revenue uplift %, market expansion."},
    {"id": "bv-cost",   "cat": "Business Value",          "sub": "Cost Savings",            "kw": ["cost", "saving", "efficiency", "reduce", "automate", "optimization", "budget", "cut", "streamline"], "tip": "Estimate cost savings or efficiency gains and how they're achieved (automation, process optimization)."},
    {"id": "ra-reg",    "cat": "Risk Assessment",         "sub": "Regulatory Risk",         "kw": ["regulatory", "compliance", "gdpr", "pci", "regulation", "legal", "risk", "audit", "licens"], "tip": "List regulatory requirements (PCI-DSS, GDPR, HKMA) and compliance approach."},
    {"id": "ra-ops",    "cat": "Risk Assessment",         "sub": "Operational Risk",        "kw": ["operational", "operation", "process", "workflow", "impact", "change", "disruption", "transition"], "tip": "Describe impact on existing operations and what organizational changes are needed."},
    {"id": "rr-team",   "cat": "Resource Requirements",   "sub": "Team Size",               "kw": ["team", "people", "staff", "developer", "fte", "resource", "headcount", "engineer", "analyst"], "tip": "State team size and roles involved (developers, BAs, QA, compliance, operations)."},
    {"id": "rr-budget", "cat": "Resource Requirements",   "sub": "Budget Requirements",    "kw": ["budget", "million", "dollar", "funding", "investment", "capital", "cost", "spend"], "tip": "Include budget range, funding source, and whether it's phased or one-time."},
]


# ── AI Review Engine ──
def ai_review(description: str) -> list:
    """
    Analyze description and return structured suggestions.
    Each suggestion: {dim_id, cat, sub, status, suggestion, example}
    status: 'missing' | 'weak' | 'ok'
    """
    if not description:
        return [{"dim_id": d["id"], "cat": d["cat"], "sub": d["sub"],
                 "status": "missing", "suggestion": d["tip"],
                 "example": get_example(d["id"])} for d in DIMS]

    desc_lower = description.lower()
    suggestions = []

    for d in DIMS:
        # Check coverage
        covered = any(kw in desc_lower for kw in d["kw"])
        if covered:
            # Check depth — if keyword found but section is short
            # Find sentence containing keyword
            sentences = re.split(r'[.!?。！？\n]', desc_lower)
            relevant = [s for s in sentences if any(kw in s for kw in d["kw"])]
            avg_len = sum(len(s) for s in relevant) / len(relevant) if relevant else 0

            if avg_len < 20:  # Too short
                suggestions.append({
                    "dim_id": d["id"], "cat": d["cat"], "sub": d["sub"],
                    "status": "weak",
                    "suggestion": f"Your description mentions {d['sub']}, but could be more detailed. " + d["tip"],
                    "example": get_example(d["id"]),
                })
            else:
                suggestions.append({
                    "dim_id": d["id"], "cat": d["cat"], "sub": d["sub"],
                    "status": "ok", "suggestion": "", "example": "",
                })
        else:
            suggestions.append({
                "dim_id": d["id"], "cat": d["cat"], "sub": d["sub"],
                "status": "missing",
                "suggestion": d["tip"],
                "example": get_example(d["id"]),
            })

    return suggestions


def get_example(dim_id: str) -> str:
    examples = {
        "sa-fit": "Strategically aligned with HSBC's digital transformation initiative to modernize payment infrastructure.",
        "sa-exec": "Sponsored by the CIO with weekly steering committee oversight and board-level visibility.",
        "tc-tech": "Built on microservices architecture with Kubernetes, using real-time event streaming (Kafka) and TensorFlow for ML models.",
        "tc-integ": "Integrates with core banking system, Salesforce CRM, risk engine, compliance platform, and reporting hub — 5 systems total.",
        "bv-rev": "Expected to generate $50M incremental revenue over 3 years through improved customer retention and faster processing.",
        "bv-cost": "Projected annual savings of $20M through operational automation, reducing manual reconciliation and fraud investigation effort.",
        "ra-reg": "Full PCI-DSS Level 1 and GDPR compliance; regulatory team engaged early in design phase.",
        "ra-ops": "Branch operations shift to monitoring mode; 200 staff retrained for customer advisory roles with 3-month transition plan.",
        "rr-team": "Team of 8: 6 developers, 2 business analysts, supported by 1 PM and 1 compliance officer.",
        "rr-budget": "$5M total over 18 months, funded from the digital transformation budget with quarterly milestone releases.",
    }
    return examples.get(dim_id, "")


def apply_suggestion(description: str, suggestion: dict) -> str:
    """Append the example text for this dimension to the description."""
    if not suggestion["example"]:
        return description
    addition = f"\n\n**{suggestion['cat']} — {suggestion['sub']}**: {suggestion['example']}"
    return description.strip() + addition


# ── Proxy ──
async def proxy_to_admin(method: str, path: str, payload: dict = None):
    if not API_KEY:
        raise HTTPException(status_code=500, detail="API_KEY not configured")
    async with httpx.AsyncClient() as client:
        url = f"{ADMIN_API_URL}{path}"
        headers = {"X-API-Key": API_KEY}
        try:
            if method == "POST":
                resp = await client.post(url, json=payload, headers=headers, timeout=60.0)
            else:
                resp = await client.get(url, headers=headers, timeout=10.0)
            return resp.json()
        except Exception as e:
            raise HTTPException(status_code=502, detail=f"Admin API error: {str(e)}")


# ── GET / ──
@app.get("/", response_class=HTMLResponse)
async def page(request: Request):
    s = request.session
    suggestions = s.get('suggestions', [])
    has_review = bool(suggestions)
    accepted_count = s.get('accepted_count', 0)

    return templates.TemplateResponse("biz_scoring.html", {
        "request": request,
        "form_svs": s.get('form_svs', ''),
        "form_ticket": s.get('form_ticket', ''),
        "form_desc": s.get('form_desc', ''),
        "score_data": s.get('score_data'),
        "has_score": s.get('score_data') is not None,
        "suggestions": suggestions,
        "has_review": has_review,
        "accepted_count": accepted_count,
        "total_dims": len(DIMS),
    })


# ── POST /review ──
@app.post("/review")
async def do_review(request: Request, svs: str = Form(...), ticket: str = Form(...), description: str = Form(...)):
    """Run AI review on the description."""
    s = request.session
    s['form_svs'] = svs
    s['form_ticket'] = ticket
    s['form_desc'] = description

    suggestions = ai_review(description)
    s['suggestions'] = suggestions
    s['accepted_count'] = 0

    return RedirectResponse(url="/", status_code=303)


# ── POST /apply ──
@app.post("/apply")
async def apply_one(request: Request, dim_id: str = Form(...)):
    """Apply a single suggestion."""
    s = request.session
    suggestions = s.get('suggestions', [])
    desc = s.get('form_desc', '')

    for sug in suggestions:
        if sug["dim_id"] == dim_id and sug["status"] != "ok":
            desc = apply_suggestion(desc, sug)
            sug["status"] = "ok"  # Mark as applied
            s['accepted_count'] = s.get('accepted_count', 0) + 1
            break

    s['form_desc'] = desc
    s['suggestions'] = suggestions
    return RedirectResponse(url="/", status_code=303)


# ── POST /apply-all ──
@app.post("/apply-all")
async def apply_all(request: Request):
    """Apply all remaining suggestions."""
    s = request.session
    suggestions = s.get('suggestions', [])
    desc = s.get('form_desc', '')

    count = 0
    for sug in suggestions:
        if sug["status"] != "ok":
            desc = apply_suggestion(desc, sug)
            sug["status"] = "ok"
            count += 1

    s['form_desc'] = desc
    s['suggestions'] = suggestions
    s['accepted_count'] = s.get('accepted_count', 0) + count
    return RedirectResponse(url="/", status_code=303)


# ── POST /ignore ──
@app.post("/ignore")
async def ignore_one(request: Request, dim_id: str = Form(...)):
    """Ignore a suggestion."""
    s = request.session
    suggestions = s.get('suggestions', [])

    for sug in suggestions:
        if sug["dim_id"] == dim_id:
            sug["status"] = "ignored"
            break

    s['suggestions'] = suggestions
    return RedirectResponse(url="/", status_code=303)


# ── POST /score ──
@app.post("/score")
async def score_project(request: Request, svs: str = Form(...), ticket: str = Form(...), description: str = Form(...)):
    s = request.session
    s['form_svs'] = svs
    s['form_ticket'] = ticket
    s['form_desc'] = description

    result = await proxy_to_admin("POST", "/api/score", {"svs": svs, "ticket": ticket, "description": description})
    s['score_data'] = result
    return RedirectResponse(url="/", status_code=303)


# ── POST /confirm ──
@app.post("/confirm")
async def confirm_score(request: Request, svs: str = Form(...), ticket: str = Form(...)):
    result = await proxy_to_admin("POST", "/api/confirm", {"svs": svs, "ticket": ticket})
    request.session.pop('score_data', None)
    return RedirectResponse(url="/", status_code=303)


# ── POST /reset ──
@app.post("/reset")
async def reset_all(request: Request):
    request.session.clear()
    return RedirectResponse(url="/", status_code=303)


@app.get("/health")
def health():
    return {"status": "ok", "service": "biz-frontend", "version": "4.0", "mode": "review"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("biz_app:app", host="0.0.0.0", port=5001, reload=False)
