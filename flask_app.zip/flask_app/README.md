# HSBC Admin Portal — FastAPI

FastAPI backend for HSBC project scoring management. All data served via REST API, frontend renders via JavaScript fetch.

## Quick Start

```bash
# Install dependencies
pip install -r requirements.txt

# Initialize database
python3 -c "from database import engine, Base; Base.metadata.create_all(bind=engine)"

# Seed demo data
curl http://localhost:5000/seed

# Start server
python3 -m uvicorn main:app --host 0.0.0.0 --port 5000 --reload

# Or with custom .env
./start.sh --env /etc/hsbc/.env
```

## Architecture

```
Frontend (Jinja2 Templates + JS fetch)
    |
    |-- GET /api/dashboard      --> JSON
    |-- GET /api/svs            --> JSON
    |-- GET /api/tickets        --> JSON
    |-- GET /api/scoring-rules  --> JSON
    |-- GET /api/users          --> JSON
    |-- GET /api/audit-logs     --> JSON
    |-- GET /api/scoring-logs   --> JSON
    |-- GET /api/api-logs       --> JSON
    |-- POST /api/score        --> JSON
    |-- POST /api/confirm      --> JSON
    |
FastAPI + SQLAlchemy + SQLite/PostgreSQL
```

## File Structure

```
flask_app/
├── main.py              # FastAPI app (routes + business logic)
├── database.py          # SQLAlchemy engine + session
├── models.py            # SQLAlchemy models (8 tables)
├── schemas.py           # Pydantic request/response models
├── requirements.txt     # Dependencies
├── start.sh             # Production startup (uvicorn + --env)
├── .env.example         # Environment variable template
└── templates/           # Jinja2 HTML (JS fetch API)
    ├── base.html
    ├── dashboard.html
    ├── svs.html
    ├── tickets.html
    ├── scoring_rules.html
    ├── users.html
    ├── audit_logs.html
    ├── scoring_logs.html
    └── api_logs.html
```

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/` | Dashboard page |
| GET | `/svs` | SVS page |
| GET | `/tickets` | Tickets page |
| GET | `/scoring-rules` | Scoring Rules page |
| GET | `/users` | Users page |
| GET | `/audit-logs` | Audit Logs page |
| GET | `/scoring-logs` | Scoring Logs page |
| GET | `/api-logs` | API Logs page |
| GET | `/api/dashboard` | Dashboard data (JSON) |
| GET | `/api/svs` | SVS list (JSON) |
| POST | `/api/svs` | Create SVS |
| DELETE | `/api/svs/{id}` | Delete SVS |
| GET | `/api/tickets` | Tickets list (JSON) |
| POST | `/api/tickets` | Create Ticket |
| DELETE | `/api/tickets/{id}` | Delete Ticket |
| GET | `/api/scoring-rules` | Scoring rules (JSON) |
| POST | `/api/scoring-rules` | Create rule |
| PUT | `/api/scoring-rules/{id}` | Update rule |
| DELETE | `/api/scoring-rules/{id}` | Delete rule |
| GET | `/api/users` | Users list (JSON) |
| POST | `/api/users` | Create user |
| PUT | `/api/users/{id}` | Update user |
| DELETE | `/api/users/{id}` | Delete user |
| GET | `/api/audit-logs` | Audit logs (JSON) |
| GET | `/api/scoring-logs` | Scoring logs (JSON) |
| GET | `/api/api-logs` | API logs (JSON) |
| POST | `/api/score` | Score a ticket |
| POST | `/api/confirm` | Confirm score |
| GET | `/api/score/{request_id}` | Get score result |
| GET | `/init-db` | Initialize database |
| GET | `/seed` | Seed demo data |

## AI Scoring Pipeline

```
POST /api/score
    |
    +--> Layer 1: Your Agent API (3 retries)
    |       +-- Pass --> Return result
    |
    +--> Layer 2: Direct LLM API (degrade)
    |       +-- Pass --> Return result
    |
    +--> Fail --> RuntimeError --> HTTP 500
```

## Production (GCP VM)

```bash
# 1. Configure environment
cp .env.example .env
# Edit .env with your API keys

# 2. Start with custom .env path
./start.sh --env /etc/hsbc/.env
```

## Environment Variables

| Variable | Description |
|----------|-------------|
| `SECRET_KEY` | Flask secret key |
| `DATABASE_URL` | SQLite or PostgreSQL connection string |
| `AGENT_API_URL` | Your Agent API endpoint |
| `AGENT_API_KEY` | Your Agent API key |
| `LLM_API_URL` | Direct LLM API endpoint (fallback) |
| `LLM_API_KEY` | Direct LLM API key |

## Connect Your Agent API

Edit `main.py`, find `call_agent_api()` and `call_llm_direct()`, uncomment the production blocks:

```python
def call_agent_api(payload):
    response = requests.post(
        os.environ.get('AGENT_API_URL'),
        json=payload,
        headers={'Authorization': f'Bearer {os.environ.get("AGENT_API_KEY")}'},
        timeout=60
    )
    response.raise_for_status()
    return _parse_api_response(response.json())
```
