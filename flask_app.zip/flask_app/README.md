# HSBC Admin Portal — FastAPI

Dual-service architecture: Admin Portal + Business Frontend.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│  Nginx (Production)                                          │
│  /biz/*  →  Biz Frontend :5001  (Public — project scoring)   │
│  /       →  Admin Portal :5000  (Internal/VPN — management)  │
└─────────────────────────────────────────────────────────────┘

Biz Frontend (:5001)                Admin Portal (:5000)
├── No database                     ├── SQLite database
├── No scoring logic                ├── AI scoring pipeline
├── Only renders pages              ├── All management pages
└── Proxies API calls ─────────────→├── /api/score
   (with hidden API Key)            ├── /api/confirm
                                     ├── /api/dashboard
                                     └── ...
```

---

## Quick Start

### 1. Admin Portal (Port 5000)

```bash
cd flask_app
pip install -r requirements.txt

# Configure
cat > .env << 'EOF'
SECRET_KEY=your-secret-key
DATABASE_URL=sqlite:///hsbc_admin.db
API_KEY=your-api-key-for-biz-frontend
FLASK_ENV=production
EOF

# Initialize database
python3 -c "from database import engine, Base; Base.metadata.create_all(bind=engine)"

# Start
bash start.sh          # Runs on :5000
```

### 2. Business Frontend (Port 5001)

```bash
# Same directory, same .env
cat >> .env << 'EOF'
ADMIN_API_URL=http://localhost:5000
EOF

# Start
bash start_biz.sh      # Runs on :5001
```

Both services share the same `.env` file. The Business Frontend reads `API_KEY` and `ADMIN_API_URL` from it.

---

## Services

| Service | Port | Public? | Description |
|---------|------|---------|-------------|
| **Admin Portal** | 5000 | No (VPN/internal) | Management dashboard, API, database |
| **Biz Frontend** | 5001 | Yes | Project scoring page, AI chat, proxies to Admin |

---

## API Endpoints

### Admin Portal (:5000)

Protected by `X-API-Key` header:

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/score` | AI project scoring |
| POST | `/api/confirm` | Confirm & lock score |
| GET | `/api/score/{id}` | Query result |

Management (internal access only):

| Method | Path | Description |
|--------|------|-------------|
| GET | `/` | Dashboard |
| GET | `/scoring-rules` | Scoring configuration |
| GET | `/api/scoring-logs` | Logs (paginated) |

### Biz Frontend (:5001)

| Method | Path | Description |
|--------|------|-------------|
| GET | `/` | Project scoring page |
| POST | `/api/proxy/score` | Proxy to Admin /api/score |
| POST | `/api/proxy/confirm` | Proxy to Admin /api/confirm |
| GET | `/api/proxy/score/{id}` | Proxy to Admin query |
| GET | `/health` | Health check |

---

## Scoring Rules Matrix

```
Multiplier = (Category Weight × Subcategory Weight) / 500

Example: Strategic Alignment (20%) × Strategic Fit (50%)
         = (20 × 50) / 500 = 2.0

Score 4 → 4 × 2.0 = 8.0 points (out of 100)
```

---

## AI Scoring Pipeline (3-Layer Fallback)

```
POST /api/score
    │
    +--> Layer 1: Agent API (3 retries)
    │       +-- Success → status: "completed"
    │
    +--> Layer 2: Direct LLM API (1 call)
    │       +-- Success → status: "completed"
    │
    +--> Layer 3: 0-Score Fallback
            Return status: "fallback", score: 0.0
            (Log records error_message)
```

**Rate Limit**: Same ticket once per 30 seconds.

---

## Security

| Layer | Protection |
|-------|----------|
| API Key | Biz Frontend hides `X-API-Key` from browsers |
| Admin Access | Bind to internal IP or VPN only |
| Dangerous APIs | `/init-db` and `/seed` disabled in production |
| Rate Limit | 30s per ticket for scoring |

---

## Connect Real Agent API

Edit `main.py`, replace mock implementations:

```python
def call_agent_api(payload):
    import requests
    response = requests.post(
        os.environ.get('AGENT_API_URL'),
        json=payload,
        headers={'Authorization': f'Bearer {os.environ.get("AGENT_API_KEY")}'},
        timeout=60
    )
    return _parse_api_response(response.json())
```

---

## Production Deployment

```bash
# Admin (internal only)
gcloud compute instances create hsbc-admin \
  --tags=admin-only \
  --metadata-from-file startup-script=start.sh

# Biz Frontend (public)
gcloud compute instances create hsbc-biz \
  --tags=http-server \
  --metadata-from-file startup-script=start_biz.sh

# Nginx routes
# /biz/* → hsbc-biz:5001
# /      → hsbc-admin:5000 (restricted by IP)
```

---

## License

Internal — HSBC
