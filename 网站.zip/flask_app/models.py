from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

# ── SVS ──────────────────────────────────────────────────────────────
class SVS(db.Model):
    __tablename__ = 'svs'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    svs_id = db.Column(db.String(50), unique=True, nullable=False)
    name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text)
    owner = db.Column(db.String(255), nullable=False)
    priority = db.Column(db.String(20), nullable=False)
    status = db.Column(db.String(30), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    tickets = db.relationship('Ticket', backref='svs', lazy=True, cascade='all, delete-orphan')

    def to_dict(self):
        return {
            'id': self.id,
            'svs_id': self.svs_id,
            'name': self.name,
            'description': self.description,
            'owner': self.owner,
            'priority': self.priority,
            'status': self.status,
        }


# ── Ticket ───────────────────────────────────────────────────────────
class Ticket(db.Model):
    __tablename__ = 'tickets'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    ticket_id = db.Column(db.String(50), unique=True, nullable=False)
    title = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=False)
    svs_id = db.Column(db.Integer, db.ForeignKey('svs.id'), nullable=False)
    requested_by = db.Column(db.String(255))
    department = db.Column(db.String(100))
    score = db.Column(db.Numeric(6, 2))        # final confirmed score
    priority = db.Column(db.String(20), nullable=False)
    status = db.Column(db.String(30), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'ticket_id': self.ticket_id,
            'title': self.title,
            'description': self.description,
            'svs_id': self.svs_id,
            'svs': self.svs.to_dict() if self.svs else None,
            'requested_by': self.requested_by,
            'department': self.department,
            'score': float(self.score) if self.score else None,
            'priority': self.priority,
            'status': self.status,
        }


# ── Scoring Rule Category ───────────────────────────────────────────
class ScoringRule(db.Model):
    __tablename__ = 'scoring_rules'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    rule_id = db.Column(db.String(10), unique=True, nullable=False)
    title = db.Column(db.String(255), nullable=False)
    weight = db.Column(db.Numeric(5, 2), nullable=False)
    order = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    sub_items = db.relationship('ScoringRuleSubItem', backref='rule', lazy=True,
                                cascade='all, delete-orphan', order_by='ScoringRuleSubItem.order')

    def to_dict(self):
        return {
            'id': self.id,
            'rule_id': self.rule_id,
            'title': self.title,
            'weight': float(self.weight),
            'sub_items': [si.to_dict() for si in self.sub_items],
        }

    def to_agent_payload(self):
        """Format for Agent API - clean structure with rubric"""
        return {
            'category': self.title,
            'weight': float(self.weight),
            'subcategories': [si.to_agent_payload() for si in self.sub_items],
        }


# ── Scoring Rule Sub Item ──────────────────────────────────────────
class ScoringRuleSubItem(db.Model):
    __tablename__ = 'scoring_rule_sub_items'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    rule_id = db.Column(db.Integer, db.ForeignKey('scoring_rules.id'), nullable=False)
    name = db.Column(db.String(255), nullable=False)
    sub_weight = db.Column(db.Numeric(5, 2), default=50.00)
    criteria = db.Column(db.Text)
    order = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    rubric_rows = db.relationship('ScoringRubric', backref='sub_item', lazy=True,
                                  cascade='all, delete-orphan', order_by='ScoringRubric.score_level')

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'sub_weight': float(self.sub_weight),
            'criteria': self.criteria,
            'rubric_rows': [r.to_dict() for r in self.rubric_rows],
        }

    def to_agent_payload(self):
        """Format for Agent API"""
        return {
            'name': self.name,
            'sub_weight': float(self.sub_weight),
            'rubric': {str(r.score_level): r.description for r in self.rubric_rows},
        }


# ── Scoring Rubric (1-5) ──────────────────────────────────────────
class ScoringRubric(db.Model):
    __tablename__ = 'scoring_rubrics'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    sub_item_id = db.Column(db.Integer, db.ForeignKey('scoring_rule_sub_items.id'), nullable=False)
    score_level = db.Column(db.Integer, nullable=False)  # 1-5
    description = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'score_level': self.score_level,
            'description': self.description,
        }


# ── Scoring Request Log (Audit) ───────────────────────────────────
class ScoringRequestLog(db.Model):
    __tablename__ = 'scoring_request_logs'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    request_id = db.Column(db.String(50), unique=True, nullable=False)
    ticket_id = db.Column(db.Integer, db.ForeignKey('tickets.id'), nullable=False)
    status = db.Column(db.String(20), default='pending')  # pending, processing, completed, failed
    request_payload = db.Column(db.Text)      # Full JSON sent to Agent
    response_payload = db.Column(db.Text)     # Full JSON from Agent
    scores = db.Column(db.Text)               # Parsed scores JSON
    total_score = db.Column(db.Numeric(6, 2))
    processing_time_ms = db.Column(db.Integer)
    error_message = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime)

    def to_dict(self):
        return {
            'id': self.id,
            'request_id': self.request_id,
            'ticket_id': self.ticket_id,
            'status': self.status,
            'scores': self.scores,
            'total_score': float(self.total_score) if self.total_score else None,
            'processing_time_ms': self.processing_time_ms,
            'error_message': self.error_message,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
        }


# ── Audit Log ──────────────────────────────────────────────────────
class AuditLog(db.Model):
    __tablename__ = 'audit_logs'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    timestamp = db.Column(db.String(30), nullable=False)
    user_id = db.Column(db.String(50), nullable=False)
    action = db.Column(db.String(100), nullable=False)
    object_type = db.Column(db.String(50))    # ticket, svs, scoring_rule, etc.
    object_id = db.Column(db.String(50))
    details = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'timestamp': self.timestamp,
            'user_id': self.user_id,
            'action': self.action,
            'object_type': self.object_type,
            'object_id': self.object_id,
            'details': self.details,
        }


# ── User ────────────────────────────────────────────────────────────
class User(db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(100), nullable=False)
    department = db.Column(db.String(100), nullable=False)
    role = db.Column(db.String(30), nullable=False, default='Submitter')
    status = db.Column(db.String(20), nullable=False, default='Active')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'department': self.department,
            'role': self.role,
            'status': self.status,
        }


# ── API Log ─────────────────────────────────────────────────────────
class ApiLog(db.Model):
    __tablename__ = 'api_logs'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    timestamp = db.Column(db.String(30), nullable=False)
    user = db.Column(db.String(100), nullable=False)
    project = db.Column(db.String(255), nullable=False)
    action = db.Column(db.String(100), nullable=False)
    score = db.Column(db.String(20))
    status = db.Column(db.String(20), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'timestamp': self.timestamp,
            'user': self.user,
            'project': self.project,
            'action': self.action,
            'score': self.score,
            'status': self.status,
        }
