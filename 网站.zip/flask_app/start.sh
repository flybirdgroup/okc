#!/bin/bash
# Production start script using Gunicorn
# Usage:
#   ./start.sh                    # Load .env from current directory
#   ./start.sh --env /path/to/.env # Load .env from custom path

set -e

cd "$(dirname "$0")"

# Default env file
ENV_FILE=".env"

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --env)
            ENV_FILE="$2"
            shift 2
            ;;
        --env=*)
            ENV_FILE="${1#*=}"
            shift
            ;;
        -h|--help)
            echo "Usage: ./start.sh [--env /path/to/.env]"
            echo ""
            echo "Options:"
            echo "  --env PATH    Path to .env file (default: ./.env)"
            echo "  -h, --help    Show this help message"
            echo ""
            echo "Examples:"
            echo "  ./start.sh"
            echo "  ./start.sh --env /etc/hsbc/.env"
            echo "  ./start.sh --env=/opt/config/hsbc.env"
            exit 0
            ;;
        *)
            echo "Unknown option: $1"
            echo "Use ./start.sh --help for usage."
            exit 1
            ;;
    esac
done

# Validate env file exists
if [ ! -f "$ENV_FILE" ]; then
    echo "Error: Env file not found: $ENV_FILE"
    echo "Use ./start.sh --help for usage."
    exit 1
fi

echo "Loading environment from: $ENV_FILE"
export $(cat "$ENV_FILE" | grep -v '^#' | xargs)

# Export env file path so app.py can also read it (python-dotenv)
export ENV_FILE_PATH="$ENV_FILE"

# Use Gunicorn for production WSGI server
# -w 4: 4 worker processes
# -b 0.0.0.0:5000: bind to all interfaces on port 5000
# --timeout 120: allow up to 120s for scoring API calls
exec gunicorn -w 4 -b 0.0.0.0:5000 --timeout 120 app:app
