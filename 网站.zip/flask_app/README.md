# HSBC Admin Portal

Flask-based admin backend for HSBC project scoring management.

## Quick Start (Local)

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Configure environment (optional for local dev)
cp .env.example .env
# Edit .env with your settings, or rely on defaults (SQLite)

# 3. Initialize database
python3 -c "from app import app; from models import db; app.app_context().push(); db.create_all()"

# 4. Seed demo data
curl http://localhost:5000/seed

# 5. Start server (development)
python3 app.py

# Or production (Gunicorn)
./start.sh
```

## Production Deployment (GCP VM / Compute Engine)

### Step 1: Create VM

```bash
# Create e2-medium VM (2 vCPU, 4GB RAM) with Ubuntu 22.04
gcloud compute instances create hsbc-admin-vm \
  --zone=asia-east1-b \
  --machine-type=e2-medium \
  --image-family=ubuntu-2204-lts \
  --image-project=ubuntu-os-cloud \
  --boot-disk-size=20GB \
  --tags=http-server,https-server
```

### Step 2: SSH into VM and setup

```bash
gcloud compute ssh hsbc-admin-vm --zone=asia-east1-b

# Install Python and dependencies
sudo apt update
sudo apt install -y python3-pip python3-venv git postgresql-client

# Create app directory
sudo mkdir -p /opt/hsbc-admin
sudo chown $USER:$USER /opt/hsbc-admin

# Upload project (from local machine, in another terminal)
# gcloud compute scp --recurse flask_app/* hsbc-admin-vm:/opt/hsbc-admin/ --zone=asia-east1-b

# On VM — setup virtual environment
cd /opt/hsbc-admin
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### Step 3: Configure environment file

Create `.env` at any path, e.g. `/etc/hsbc/.env`:

```bash
sudo mkdir -p /etc/hsbc
sudo tee /etc/hsbc/.env << 'EOF'
# Flask
SECRET_KEY=your-random-secret-key-here

# Database — PostgreSQL (recommended for production)
DATABASE_URL=postgresql+psycopg2://hsbc_user:YOUR_PASSWORD@localhost:5432/hsbc_db

# Or keep SQLite for simple deployment:
# DATABASE_URL=sqlite:///opt/hsbc-admin/hsbc_admin.db

# Layer 1: Your Agent API
AGENT_API_URL=https://your-agent-api.example.com/score
AGENT_API_KEY=your-agent-api-key

# Layer 2: Direct LLM API (OpenAI / Claude / etc)
LLM_API_URL=https://api.openai.com/v1/chat/completions
LLM_API_KEY=sk-your-openai-key
EOF

sudo chmod 600 /etc/hsbc/.env
```

### Step 4: PostgreSQL setup (if using PostgreSQL)

```bash
sudo apt install -y postgresql postgresql-contrib
sudo -u postgres psql -c "CREATE USER hsbc_user WITH PASSWORD 'YOUR_PASSWORD';"
sudo -u postgres psql -c "CREATE DATABASE hsbc_db OWNER hsbc_user;"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE hsbc_db TO hsbc_user;"

# Test connection
psql postgresql://hsbc_user:YOUR_PASSWORD@localhost:5432/hsbc_db -c "\dt"
```

### Step 5: Initialize database and start

```bash
cd /opt/hsbc-admin
source venv/bin/activate

# Create tables
python3 -c "from app import app; from models import db; app.app_context().push(); db.create_all()"

# Seed demo data
curl http://localhost:5000/seed

# Start with custom env file
./start.sh --env /etc/hsbc/.env
```

### Step 6: Run as systemd service (auto-restart on boot)

Create `/etc/systemd/system/hsbc-admin.service`:

```ini
[Unit]
Description=HSBC Admin Portal
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/opt/hsbc-admin
Environment=ENV_FILE_PATH=/etc/hsbc/.env
ExecStart=/opt/hsbc-admin/venv/bin/gunicorn -w 4 -b 0.0.0.0:5000 --timeout 120 app:app
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

Enable and start:

```bash
sudo systemctl daemon-reload
sudo systemctl enable hsbc-admin
sudo systemctl start hsbc-admin
sudo systemctl status hsbc-admin

# View logs
sudo journalctl -u hsbc-admin -f
```

### Step 7: Nginx reverse proxy (optional, recommended)

```bash
sudo apt install -y nginx

sudo tee /etc/nginx/sites-available/hsbc-admin << 'EOF'
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_connect_timeout 120s;
        proxy_send_timeout 120s;
        proxy_read_timeout 120s;
    }
}
EOF

sudo ln -s /etc/nginx/sites-available/hsbc-admin /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t
sudo systemctl restart nginx
```

## Pages

| Page | Path | Description |
|------|------|-------------|
| Dashboard | `/` | KPI cards, charts, recent tickets |
| SVS | `/svs` | Strategic Value Stream management |
| Tickets | `/tickets` | Ticket CRUD with scoring status |
| Scoring Rules | `/scoring-rules` | Weight matrix + card-based rule editor |
| Users | `/users` | User management with role/status |
| Audit Logs | `/audit-logs` | All admin actions |
| Scoring Logs | `/scoring-logs` | AI scoring request history with evidence |
| API Logs | `/api-logs` | API call records |

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/score` | POST | Preview score a ticket (can call multiple times) |
| `/api/confirm` | POST | Confirm final score (locks ticket) |
| `/api/score/<request_id>` | GET | Get scoring result by request ID |
| `/api/scoring-rules` | GET | Get all scoring rules (JSON) |
| `/api/tickets` | GET | Get all tickets (JSON) |

## AI Scoring Pipeline

```
POST /api/score
    |
    +--> Layer 1: Your Agent API (3 retries)
    |       +-- Pass --> Return result
    |
    +--> Layer 2: Direct LLM API (degrade)
    |       +-- Pass --> Return result
    |
    +--> Fail --> RuntimeError --> HTTP 500
```

## `start.sh` Usage

```bash
# Load .env from current directory (default)
./start.sh

# Load .env from custom path
./start.sh --env /etc/hsbc/.env
./start.sh --env=/opt/config/hsbc.env

# Show help
./start.sh --help
```

The `--env` path is passed to `python-dotenv` in `app.py`, so all env vars are loaded before Flask starts.

## Production Checklist

- [ ] Create VM with firewall rules (port 80/443 open)
- [ ] Install PostgreSQL or configure SQLite path in persistent storage
- [ ] Copy `.env.example` to your preferred path and fill in real values
- [ ] Change `SECRET_KEY` to a random string (`openssl rand -hex 32`)
- [ ] Configure Agent API URL and API Key
- [ ] Configure LLM API URL and API Key (fallback)
- [ ] Set up systemd service for auto-start
- [ ] Set up Nginx reverse proxy + HTTPS (Let's Encrypt)
- [ ] Remove `/seed` endpoint access or protect it
- [ ] Set up log rotation (`/var/log/hsbc-admin/`)
- [ ] Configure database backups (if using PostgreSQL)

## File Structure

```
flask_app/
├── app.py              # Flask application + API logic
├── models.py           # SQLAlchemy database models
├── requirements.txt    # Python dependencies
├── start.sh            # Production startup script (Gunicorn + --env support)
├── .env.example        # Environment variable template
├── README.md           # This file
└── templates/          # Jinja2 HTML templates
    ├── base.html
    ├── dashboard.html
    ├── svs.html
    ├── tickets.html
    ├── scoring_rules.html
    ├── users.html
    ├── audit_logs.html
    ├── scoring_logs.html
    └── api_logs.html
```
