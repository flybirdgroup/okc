from flask import Flask, render_template, request, jsonify, redirect, url_for
from flask_cors import CORS
from datetime import datetime
import json
import uuid
import time

app = Flask(__name__)

# Database config — supports SQLite (dev) and PostgreSQL (production)
import os

# Load .env file if python-dotenv is available and path is provided
_env_file = os.environ.get('ENV_FILE_PATH')
if _env_file:
    try:
        from dotenv import load_dotenv
        load_dotenv(_env_file, override=True)
    except ImportError:
        pass  # python-dotenv not installed, rely on shell-exported vars

# Read from env var; fallback to SQLite for local dev
default_sqlite = 'sqlite:///' + os.path.join(os.path.dirname(os.path.abspath(__file__)), 'hsbc_admin.db')
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', default_sqlite)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'hsbc-admin-secret-key')

CORS(app)

from models import db, SVS, Ticket, User, ScoringRule, ScoringRuleSubItem, ScoringRubric, ScoringRequestLog, AuditLog, ApiLog
db.init_app(app)

# Jinja2 filter: parse JSON string
@app.template_filter('from_json')
def from_json_filter(value):
    if value is None:
        return []
    if isinstance(value, str):
        try:
            return json.loads(value)
        except (json.JSONDecodeError, TypeError):
            return []
    return value


# ============================================================
# Helper: add audit log
# ============================================================
def log_action(action, object_type=None, object_id=None, details=None):
    log = AuditLog(
        timestamp=datetime.now().strftime('%Y-%m-%d %H:%M'),
        user_id='admin_001',
        action=action,
        object_type=object_type,
        object_id=object_id,
        details=details,
    )
    db.session.add(log)
    db.session.commit()


# ============================================================
# Agent Prompt Builder
# ============================================================
def build_agent_prompt(payload):
    """
    Build the system + user prompt for the Agent LLM API.
    
    This prompt instructs the LLM to act as a scoring expert and return
    structured JSON with total_score and evidence per subcategory.
    """
    ticket = payload.get('ticket', {})
    rules = payload.get('scoring_rules', [])
    
    # System prompt: defines the LLM's role and output rules
    system_prompt = """You are an expert project scoring analyst at HSBC. Your job is to evaluate project tickets against predefined scoring rules and return a structured assessment.

SCORING RULES:
- Each category has a weight (0-100%).
- Each subcategory within a category has a sub-weight (0-100%).
- Each subcategory has a 1-5 rubric scale defining what each score means.
- You must evaluate every subcategory independently.

OUTPUT FORMAT (strict JSON):
{
  "total_score": <0-100>,
  "evidence": [
    {
      "subcategory": "<exact subcategory name>",
      "category": "<exact category name>",
      "score": <1-5>,
      "rubric_level": <1-5>,
      "rubric_description": "<description of the chosen rubric level>",
      "reasoning": "<why you chose this score, referencing ticket text>",
      "quoted_text": "<exact keyword or phrase from ticket description that supports this score>",
      "subcategory_weight": <number>,
      "category_weight": <number>
    }
  ]
}

SCORING METHODOLOGY:
1. Read the ticket description carefully.
2. For each subcategory, compare the ticket against the rubric levels 1-5.
3. Choose the rubric level that best matches the ticket.
4. Provide specific evidence: quote exact words/phrases from the ticket that justify the score.
5. If the ticket strongly matches a high-level rubric criterion, give a high score.
6. If the ticket lacks evidence for a criterion, give a low score.
7. Be objective and consistent. Do not inflate scores.

TOTAL SCORE CALCULATION:
total_score = sum over all evidence of (category_weight / 100 * subcategory_weight / 100 * score * 20)
This produces a score from 0 to 100.

IMPORTANT:
- Return ONLY valid JSON. No markdown, no explanation text outside JSON.
- Every subcategory must have an evidence entry.
- quoted_text must be an exact substring from the ticket description or title."""

    # User prompt: the actual ticket + rules to score
    user_prompt = f"""TICKET TO EVALUATE:
Ticket ID: {ticket.get('ticket_id', 'N/A')}
Title: {ticket.get('title', 'N/A')}
Description: {ticket.get('description', 'No description provided')}
SVS: {ticket.get('svs', {}).get('name', 'N/A') if ticket.get('svs') else 'N/A'}
Priority: {ticket.get('priority', 'N/A')}

SCORING RULES:
"""
    
    for rule in rules:
        cat = rule['category']
        cat_w = rule['weight']
        user_prompt += f"\nCategory: {cat} (Weight: {cat_w}%)\n"
        for sub in rule.get('subcategories', []):
            sub_name = sub['name']
            sub_w = sub['sub_weight']
            rubric = sub.get('rubric', {})
            user_prompt += f"  Subcategory: {sub_name} (Sub Weight: {sub_w}%)\n"
            for level in [1, 2, 3, 4, 5]:
                desc = rubric.get(str(level), 'No description')
                label = {1: 'Minimal', 2: 'Low', 3: 'Medium', 4: 'High', 5: 'Exceptional'}.get(level, '')
                user_prompt += f"    Score {level} — {label}: {desc}\n"
    
    user_prompt += """
Please evaluate the ticket against every subcategory above and return ONLY the JSON response."""
    
    return {
        "model": "gpt-4o",  # or your preferred LLM model
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        "temperature": 0.2,
        "max_tokens": 4000,
        "response_format": {"type": "json_object"}
    }




# ============================================================
# Agent Response Validator (Very Relaxed)
# ============================================================
def validate_agent_response(result, scoring_rules):
    """
    Validate the LLM response with minimal checks.

    Relaxed rules:
    - Evidence count is NOT checked.
    - Required fields are NOT checked. Only 'subcategory' is needed to identify.
    - Missing fields are auto-populated with defaults.
    - Missing subcategories are auto-filled with score 0.

    Kept checks:
    - Must be valid JSON object
    - total_score must be 0-100
    - evidence must be a list

    Returns (is_valid, error_message, patched_result).
    """
    # 1. Must be a dict
    if not isinstance(result, dict):
        return False, "Response is not a JSON object", None

    # 2. Must have total_score
    if 'total_score' not in result:
        return False, "Missing 'total_score' field", None

    total_score = result.get('total_score')
    if not isinstance(total_score, (int, float)):
        return False, f"'total_score' is not a number: {type(total_score)}", None
    if not (0 <= total_score <= 100):
        return False, f"'total_score' out of range: {total_score}", None

    # 3. Must have evidence array
    if 'evidence' not in result:
        return False, "Missing 'evidence' field", None

    evidence = result.get('evidence')
    if not isinstance(evidence, list):
        return False, f"'evidence' is not an array: {type(evidence)}", None

    # ------------------------------------------------------------------
    # Build expected subcategory map for auto-fill
    # ------------------------------------------------------------------
    expected_subs_map = {}
    for rule in scoring_rules:
        cat_name = rule['category']
        cat_w = rule['weight']
        for sub in rule.get('subcategories', []):
            sub_name = sub['name']
            expected_subs_map[sub_name] = {
                'category': cat_name,
                'category_weight': cat_w,
                'sub_weight': sub['sub_weight'],
                'rubric': sub.get('rubric', {}),
            }

    # 4. Walk through returned evidence — auto-fill anything missing, no hard checks
    seen_subs = set()
    for i, ev in enumerate(evidence):
        if not isinstance(ev, dict):
            continue  # Skip non-object entries silently

        sub_name = ev.get('subcategory')
        if not sub_name or sub_name not in expected_subs_map:
            continue  # Skip unknown / unidentifiable entries
        if sub_name in seen_subs:
            continue  # Skip duplicates silently
        seen_subs.add(sub_name)

        score = ev.get('score')
        if not isinstance(score, (int, float)) or not (1 <= score <= 5):
            score = 3  # Default to neutral if score is invalid / missing
            ev['score'] = score

        # Auto-fill optional missing fields with defaults
        info = expected_subs_map[sub_name]
        ev.setdefault('category', info['category'])
        ev.setdefault('category_weight', info['category_weight'])
        ev.setdefault('subcategory_weight', info['sub_weight'])
        ev.setdefault('rubric_level', score)
        rubric = info['rubric']
        rubric_desc = rubric.get(str(score), rubric.get(str(int(score)), 'No rubric description'))
        ev.setdefault('rubric_description', rubric_desc)
        ev.setdefault('reasoning', 'No detailed reasoning provided.')
        ev.setdefault('quoted_text', 'N/A')

    # 5. Auto-fill missing subcategories with score 0
    for sub_name, info in expected_subs_map.items():
        if sub_name not in seen_subs:
            evidence.append({
                'subcategory': sub_name,
                'category': info['category'],
                'score': 0,
                'rubric_level': 0,
                'rubric_description': 'Not mentioned in ticket — default score 0',
                'reasoning': 'This subcategory was not explicitly addressed in the ticket description. Default score: 0/5.',
                'quoted_text': 'N/A',
                'subcategory_weight': info['sub_weight'],
                'category_weight': info['category_weight'],
            })

    # 6. Recalculate total_score based on full evidence set
    calculated = 0.0
    for ev in evidence:
        cat_w = float(ev.get('category_weight', 0) or 0)
        sub_w = float(ev.get('subcategory_weight', 0) or 0)
        score = int(ev.get('score', 0) or 0)
        calculated += (cat_w / 100.0) * (sub_w / 100.0) * score * 20

    # Allow 3-point tolerance; if LLM's total is way off, override it
    if abs(calculated - total_score) > 3.0:
        result['total_score'] = round(calculated, 2)

    return True, None, result


# ============================================================
# LLM / Agent API Response Parser (Production)
# ============================================================
def _parse_api_response(response_json):
    """
    Extract the content string from various LLM / API response formats.

    Supports:
      1. OpenAI format:  choices[0].message.content
      2. Direct JSON:    response is already the result dict with total_score/evidence
      3. Raw wrapper:    response wraps the JSON in a 'data' or 'result' key
      4. Fallback:       dump the whole response as string for JSON.parse attempt

    Production usage:
        raw_content = _parse_api_response(response.json())
        result = json.loads(raw_content)
    """
    # 1. OpenAI / compatible format
    if isinstance(response_json, dict):
        if 'choices' in response_json and response_json['choices']:
            choice = response_json['choices'][0]
            if isinstance(choice, dict):
                msg = choice.get('message', {})
                if isinstance(msg, dict) and 'content' in msg:
                    return msg['content']

        # 2. Already the result dict (some Agent APIs return the payload directly)
        if 'total_score' in response_json or 'evidence' in response_json:
            return json.dumps(response_json)

        # 3. Wrapped in data / result / body
        for key in ('data', 'result', 'body', 'response', 'output'):
            if key in response_json:
                val = response_json[key]
                if isinstance(val, str):
                    return val
                if isinstance(val, dict):
                    return json.dumps(val)

    # 4. Fallback — return as JSON string
    return json.dumps(response_json) if isinstance(response_json, dict) else str(response_json)


# ============================================================
# LLM Response Simulator (for development only)
# ============================================================
def _simulate_llm_response(payload, inject_errors=False):
    """
    Simulate what an LLM would return.
    
    Args:
        inject_errors: If True, randomly inject malformed responses
                       to test the validation + retry system.
    """
    import random

    if inject_errors and random.random() < 0.1:
        bad_responses = [
            'not json at all',
            '{"total_score": 999}',  # out of range
            '{"evidence": []}',  # missing total_score
            '{"total_score": 50, "evidence": [{"score": 10}]}',  # score out of range
        ]
        return random.choice(bad_responses)

    scoring_rules = payload.get('scoring_rules', [])
    evidence = []
    total_weighted = 0.0

    desc = payload.get('ticket', {}).get('description', '')
    title = payload.get('ticket', {}).get('title', '')
    combined = (title + ' ' + desc).lower()

    keyword_map = {
        5: ['ai', 'ml', 'transform', 'strategic', 'platform', 'autonomous', 'breakthrough'],
        4: ['upgrade', 'enhancement', 'optimization', 'improvement', 'redesign', 'advanced'],
        3: ['integration', 'migration', 'development', 'implementation', 'modernization'],
        2: ['basic', 'maintenance', 'minor', 'setup', 'fix', 'patch', 'update'],
        1: ['bugfix', 'repair', 'trivial'],
    }

    for rule in scoring_rules:
        cat_name = rule['category']
        cat_weight = rule['weight']
        for sub in rule.get('subcategories', []):
            sub_name = sub['name']
            sub_weight = sub['sub_weight']
            rubric = sub.get('rubric', {})

            matched = []
            score = 3
            for level, kws in keyword_map.items():
                for kw in kws:
                    if kw in combined:
                        score = level
                        matched.append(kw)
                        break
                if score != 3:
                    break

            rubric_desc = rubric.get(str(score), 'No rubric description')
            quoted = f"Detected: {', '.join(matched)}" if matched else "No strong keywords found"

            evidence.append({
                'subcategory': sub_name,
                'category': cat_name,
                'score': score,
                'rubric_level': score,
                'rubric_description': rubric_desc,
                'reasoning': f"Score {score}/5 based on ticket analysis. {quoted}",
                'quoted_text': quoted,
                'subcategory_weight': sub_weight,
                'category_weight': cat_weight,
            })

            total_weighted += (cat_weight / 100.0) * (sub_weight / 100.0) * score * 20

    total_score = min(100, max(0, total_weighted))

    result = {
        'total_score': round(total_score, 2),
        'evidence': evidence,
        'reasoning_summary': f"Scored {len(evidence)} subcategories. Total: {total_score:.1f}/100.",
    }

    return json.dumps(result)


# ============================================================
# Layer 1: Call User's Agent API
# ============================================================
def call_agent_api(payload):
    """
    Layer 1 — Call the user's dedicated Agent API.

    Production: Replace the simulation below with a real HTTP POST
    to your Agent endpoint.
    """
    # ======================================================================
    # PRODUCTION: Replace this block with real Agent API call
    # ======================================================================
    # import requests
    # response = requests.post(
    #     'https://your-agent-api.example.com/score',
    #     json=payload,
    #     headers={'Authorization': 'Bearer YOUR_AGENT_API_KEY'},
    #     timeout=60
    # )
    # response.raise_for_status()
    # raw_content = _parse_api_response(response.json())
    # return raw_content
    # ======================================================================

    # SIMULATION: inject random errors to test retry + degrade
    return _simulate_llm_response(payload, inject_errors=True)


# ============================================================
# Layer 2 (Degrade): Call LLM API Directly
# ============================================================
def call_llm_direct(payload):
    """
    Layer 2 — Degrade to calling LLM API directly (OpenAI / Claude / etc).

    Called only when the user's Agent API fails after all retries.
    """
    prompt_payload = build_agent_prompt(payload)

    # ======================================================================
    # PRODUCTION: Replace this block with real LLM API call
    # ======================================================================
    # import requests
    # response = requests.post(
    #     'https://api.openai.com/v1/chat/completions',
    #     json=prompt_payload,
    #     headers={'Authorization': 'Bearer YOUR_OPENAI_KEY'},
    #     timeout=60
    # )
    # response.raise_for_status()
    # raw_content = _parse_api_response(response.json())
    # return raw_content
    # ======================================================================

    # SIMULATION: stable response (no error injection)
    return _simulate_llm_response(payload, inject_errors=False)


# ============================================================
# Agent API Helper (with validation + retry + degrade)
# ============================================================
def call_scoring_agent(payload):
    """
    Two-layer scoring strategy:

    Layer 1 — Agent API (user's custom endpoint)
        Try up to MAX_RETRIES times. If a response passes validation,
        return it immediately.

    Layer 2 — Direct LLM API (degrade)
        If Layer 1 exhausts all retries, call LLM directly (OpenAI/Claude).

    Failure — raise RuntimeError
        If both layers fail, raise an error so the caller (api_score_ticket)
        can return a proper failed response to the frontend.
    """
    MAX_RETRIES = 3

    last_error = None

    # ------------------------------------------------------------------
    # Layer 1: Agent API (with retry)
    # ------------------------------------------------------------------
    for attempt in range(MAX_RETRIES):
        try:
            raw_content = call_agent_api(payload)
            result = json.loads(raw_content)

            is_valid, error_msg, result = validate_agent_response(
                result, payload.get('scoring_rules', [])
            )

            if is_valid:
                if 'reasoning_summary' not in result:
                    total = result['total_score']
                    count = len(result['evidence'])
                    result['reasoning_summary'] = f"Scored {count} subcategories. Total: {total:.1f}/100."
                return result

            last_error = error_msg

            if attempt < MAX_RETRIES - 1:
                # Retry with reminder — but Agent API may not read this,
                # so the retry is mainly for transient network/format errors.
                pass

        except json.JSONDecodeError as e:
            last_error = f"Invalid JSON: {str(e)}"
        except Exception as e:
            last_error = str(e)
            if attempt < MAX_RETRIES - 1:
                continue

    # ------------------------------------------------------------------
    # Layer 2: Direct LLM API (degrade)
    # ------------------------------------------------------------------
    last_llm_error = None
    try:
        raw_content = call_llm_direct(payload)
        result = json.loads(raw_content)

        is_valid, error_msg, result = validate_agent_response(
            result, payload.get('scoring_rules', [])
        )

        if is_valid:
            if 'reasoning_summary' not in result:
                total = result['total_score']
                count = len(result['evidence'])
                result['reasoning_summary'] = f"[Direct LLM] Scored {count} subcategories. Total: {total:.1f}/100."
            return result
        else:
            last_llm_error = error_msg

    except Exception as e:
        last_llm_error = str(e)

    # ------------------------------------------------------------------
    # All layers failed — raise an error so the caller can handle it
    # ------------------------------------------------------------------
    raise RuntimeError(
        f"Scoring failed: Agent API exhausted after {MAX_RETRIES} retries, "
        f"and direct LLM API also failed ({last_llm_error or 'validation failed'}). "
        f"Please retry the request."
    )


# ============================================================
# API: Score Ticket (Preview - can be called multiple times)
# ============================================================
@app.route('/api/score', methods=['POST'])
def api_score_ticket():
    """
    Score a ticket. Frontend provides svs + ticket + description.
    Can be called multiple times (preview mode) until score is satisfactory.

    Request Body:
        { "svs": "SVS-001", "ticket": "T-2024-001", "description": "..." }

    Response:
        {
            "request_id": str,
            "status": "completed",
            "ticket": { ... },
            "total_score": float,
            "evidence": [ ... ],
            "reasoning_summary": str,
            "processing_time_ms": int
        }
    """
    start_time = time.time()

    data = request.get_json(silent=True) or {}
    svs_id_str = data.get('svs')
    ticket_id_str = data.get('ticket')
    description = data.get('description', '')

    # Validate
    if not svs_id_str or not ticket_id_str:
        return jsonify({
            'error': 'Missing required fields: svs and ticket are required',
            'status': 'failed'
        }), 400

    # Find SVS
    svs = SVS.query.filter_by(svs_id=svs_id_str).first()
    if not svs:
        return jsonify({
            'error': f'SVS not found: {svs_id_str}',
            'status': 'failed'
        }), 404

    # Find or create Ticket
    ticket = Ticket.query.filter_by(ticket_id=ticket_id_str).first()
    if not ticket:
        # Create new ticket with auto-generated fields
        ticket = Ticket(
            ticket_id=ticket_id_str,
            title=ticket_id_str,
            description=description,
            svs_id=svs.id,
            requested_by='system',
            department='System',
            priority='MEDIUM',
            status='DRAFT',
        )
        db.session.add(ticket)
        db.session.commit()
        log_action('Ticket Auto-Created', 'ticket', ticket_id_str, f'SVS: {svs_id_str}')
    else:
        # Update description if changed
        if ticket.description != description:
            ticket.description = description
            db.session.commit()

    # Check if already confirmed
    if ticket.status == 'CONFIRMED':
        return jsonify({
            'error': 'Ticket already confirmed. Cannot re-score.',
            'ticket': ticket.to_dict(),
            'status': 'failed'
        }), 409

    # Generate request ID and create log
    request_id = f"SCR-{uuid.uuid4().hex[:12].upper()}"
    scoring_log = ScoringRequestLog(
        request_id=request_id,
        ticket_id=ticket.id,
        status='processing',
    )
    db.session.add(scoring_log)
    db.session.commit()

    try:
        # Gather scoring rules
        rules = ScoringRule.query.all()
        scoring_rules_payload = [r.to_agent_payload() for r in rules]

        # Build ticket payload
        ticket_payload = {
            'id': ticket.id,
            'ticket_id': ticket.ticket_id,
            'title': ticket.title,
            'description': ticket.description,
            'priority': ticket.priority,
            'status': ticket.status,
            'svs': svs.to_dict(),
        }

        agent_payload = {
            'ticket': ticket_payload,
            'scoring_rules': scoring_rules_payload,
        }

        scoring_log.request_payload = json.dumps(agent_payload, indent=2, default=str)
        db.session.commit()

        # Call Agent
        agent_result = call_scoring_agent(agent_payload)

        processing_time_ms = int((time.time() - start_time) * 1000)

        # Update log
        scoring_log.status = 'completed'
        scoring_log.response_payload = json.dumps(agent_result, indent=2, default=str)
        scoring_log.scores = json.dumps(agent_result['evidence'], indent=2, default=str)
        scoring_log.total_score = agent_result['total_score']
        scoring_log.processing_time_ms = processing_time_ms
        scoring_log.completed_at = datetime.utcnow()
        db.session.commit()

        log_action('Ticket Preview Scored', 'ticket', ticket.ticket_id,
                   f'Score: {agent_result["total_score"]} | Request: {request_id}')

        return jsonify({
            'request_id': request_id,
            'status': 'completed',
            'ticket': ticket_payload,
            'total_score': agent_result['total_score'],
            'evidence': agent_result['evidence'],
            'reasoning_summary': agent_result['reasoning_summary'],
            'processing_time_ms': processing_time_ms,
        })

    except Exception as e:
        processing_time_ms = int((time.time() - start_time) * 1000)
        scoring_log.status = 'failed'
        scoring_log.error_message = str(e)
        scoring_log.processing_time_ms = processing_time_ms
        scoring_log.completed_at = datetime.utcnow()
        db.session.commit()

        log_action('Ticket Scoring Failed', 'ticket', ticket.ticket_id,
                   f'Error: {str(e)} | Request: {request_id}')

        return jsonify({
            'request_id': request_id,
            'status': 'failed',
            'error': str(e),
            'processing_time_ms': processing_time_ms,
        }), 500


# ============================================================
# API: Confirm Score (Final - changes ticket status to CONFIRMED)
# ============================================================
@app.route('/api/confirm', methods=['POST'])
def api_confirm_score():
    """
    Confirm the final score for a ticket.
    Once confirmed, the ticket cannot be re-scored.

    Request Body:
        { "svs": "SVS-001", "ticket": "T-2024-001" }

    Response:
        { "status": "confirmed", "ticket": { ... } }
    """
    data = request.get_json(silent=True) or {}
    svs_id_str = data.get('svs')
    ticket_id_str = data.get('ticket')

    if not svs_id_str or not ticket_id_str:
        return jsonify({
            'error': 'Missing required fields: svs and ticket are required',
            'status': 'failed'
        }), 400

    # Find SVS
    svs = SVS.query.filter_by(svs_id=svs_id_str).first()
    if not svs:
        return jsonify({
            'error': f'SVS not found: {svs_id_str}',
            'status': 'failed'
        }), 404

    # Find Ticket
    ticket = Ticket.query.filter_by(ticket_id=ticket_id_str, svs_id=svs.id).first()
    if not ticket:
        return jsonify({
            'error': f'Ticket not found: {ticket_id_str} under {svs_id_str}',
            'status': 'failed'
        }), 404

    # Check if already confirmed
    if ticket.status == 'CONFIRMED':
        return jsonify({
            'status': 'already_confirmed',
            'ticket': ticket.to_dict(),
        })

    # Update status
    old_status = ticket.status
    ticket.status = 'CONFIRMED'
    db.session.commit()

    log_action('Ticket Confirmed', 'ticket', ticket.ticket_id,
               f'Status changed from {old_status} to CONFIRMED')

    return jsonify({
        'status': 'confirmed',
        'ticket': ticket.to_dict(),
    })


@app.route('/api/score/<request_id>', methods=['GET'])
def api_get_score_result(request_id):
    """Get scoring result by request ID."""
    log = ScoringRequestLog.query.filter_by(request_id=request_id).first()
    if not log:
        return jsonify({'error': 'Request not found'}), 404

    return jsonify({
        'request_id': log.request_id,
        'status': log.status,
        'ticket_id': log.ticket_id,
        'total_score': float(log.total_score) if log.total_score else None,
        'evidence': json.loads(log.scores) if log.scores else None,
        'processing_time_ms': log.processing_time_ms,
        'error_message': log.error_message,
        'created_at': log.created_at.isoformat() if log.created_at else None,
        'completed_at': log.completed_at.isoformat() if log.completed_at else None,
    })


@app.route('/api/scoring-rules', methods=['GET'])
def api_get_scoring_rules():
    """Get all scoring rules (for external frontends to use)."""
    rules = ScoringRule.query.all()
    return jsonify({
        'scoring_rules': [r.to_agent_payload() for r in rules]
    })


@app.route('/api/tickets', methods=['GET'])
def api_get_tickets():
    """Get all tickets."""
    tickets = Ticket.query.all()
    return jsonify({
        'tickets': [t.to_dict() for t in tickets]
    })


@app.route('/api/tickets/<int:ticket_id>', methods=['GET'])
def api_get_ticket(ticket_id):
    """Get single ticket by ID."""
    ticket = Ticket.query.get(ticket_id)
    if not ticket:
        return jsonify({'error': 'Ticket not found'}), 404
    return jsonify(ticket.to_dict())


# ============================================================
# Dashboard
# ============================================================
@app.route('/')
def dashboard():
    total_svs = SVS.query.count()
    total_tickets = Ticket.query.count()
    high_priority_tickets = Ticket.query.filter_by(priority='HIGH').count()
    pending_tickets = Ticket.query.filter_by(status='PENDING').count()

    priority_dist = [
        {'name': 'High', 'value': Ticket.query.filter_by(priority='HIGH').count(), 'color': '#DA291C'},
        {'name': 'Medium', 'value': Ticket.query.filter_by(priority='MEDIUM').count(), 'color': '#F59E0B'},
        {'name': 'Low', 'value': Ticket.query.filter_by(priority='LOW').count(), 'color': '#3B82F6'},
    ]

    # Recent 5 tickets
    recent_tickets = Ticket.query.order_by(Ticket.id.desc()).limit(5).all()

    # SVS list with ticket counts
    svs_list = SVS.query.all()

    # Bar chart data: tickets per SVS (top 6 by volume)
    bar_data = []
    for svs in sorted(svs_list, key=lambda s: len(s.tickets), reverse=True)[:6]:
        bar_data.append({
            'name': svs.name[:18] + ('...' if len(svs.name) > 18 else ''),
            'score': len(svs.tickets),
        })

    return render_template(
        'dashboard.html',
        active_page='dashboard',
        kpi={'total_svs': total_svs, 'total_tickets': total_tickets, 'high': high_priority_tickets, 'pending': pending_tickets},
        priority_dist=priority_dist,
        recent_tickets=recent_tickets,
        svs_list=svs_list,
        bar_data=bar_data,
    )


# ============================================================
# SVS Management
# ============================================================
@app.route('/svs')
def svs_page():
    search = request.args.get('search', '')
    priority_filter = request.args.get('priority', 'All')
    status_filter = request.args.get('status', 'All')

    query = SVS.query
    if search:
        query = query.filter(db.or_(
            SVS.name.ilike(f'%{search}%'),
            SVS.svs_id.ilike(f'%{search}%')
        ))
    if priority_filter != 'All':
        query = query.filter_by(priority=priority_filter.upper())
    if status_filter != 'All':
        query = query.filter_by(status=status_filter.upper())

    svs_items = query.all()
    return render_template(
        'svs.html',
        active_page='svs',
        svs_items=svs_items,
        search=search,
        priority_filter=priority_filter,
        status_filter=status_filter,
    )


@app.route('/svs/create', methods=['POST'])
def create_svs():
    name = request.form.get('name')
    owner = request.form.get('owner')
    priority = request.form.get('priority', 'MEDIUM')
    status = request.form.get('status', 'ACTIVE')

    svs_id = f'SVS-{datetime.now().strftime("%Y%m%d-%H%M%S")}'

    new_svs = SVS(
        svs_id=svs_id,
        name=name,
        owner=owner,
        priority=priority,
        status=status,
    )
    db.session.add(new_svs)
    db.session.commit()
    log_action('SVS Created', 'svs', svs_id)

    return redirect(url_for('svs_page'))


@app.route('/svs/delete/<int:svs_db_id>', methods=['POST'])
def delete_svs(svs_db_id):
    svs = SVS.query.get_or_404(svs_db_id)
    svs_id = svs.svs_id
    db.session.delete(svs)
    db.session.commit()
    log_action('SVS Deleted', 'svs', svs_id)
    return redirect(url_for('svs_page'))


# ============================================================
# Ticket Management
# ============================================================
@app.route('/tickets')
def tickets_page():
    search = request.form.get('search', '') or request.args.get('search', '')
    priority_filter = request.args.get('priority', 'All')
    status_filter = request.args.get('status', 'All')
    svs_filter = request.args.get('svs', 'All')

    query = Ticket.query
    if search:
        query = query.filter(db.or_(
            Ticket.title.ilike(f'%{search}%'),
            Ticket.ticket_id.ilike(f'%{search}%')
        ))
    if priority_filter != 'All':
        query = query.filter_by(priority=priority_filter.upper())
    if status_filter != 'All':
        query = query.filter_by(status=status_filter.upper())
    if svs_filter != 'All':
        query = query.filter_by(svs_id=int(svs_filter))

    tickets = query.all()
    svs_list = SVS.query.all()
    return render_template(
        'tickets.html',
        active_page='tickets',
        tickets=tickets,
        svs_list=svs_list,
        search=search,
        priority_filter=priority_filter,
        status_filter=status_filter,
        svs_filter=svs_filter,
    )


@app.route('/tickets/create', methods=['POST'])
def create_ticket():
    title = request.form.get('title')
    description = request.form.get('description', '')
    svs_id = request.form.get('svs_id')
    requested_by = request.form.get('requested_by')
    department = request.form.get('department', '')
    priority = request.form.get('priority', 'MEDIUM')
    status = request.form.get('status', 'DRAFT')

    ticket_id = f'T-{datetime.now().strftime("%Y%m%d-%H%M%S")}'

    new_ticket = Ticket(
        ticket_id=ticket_id,
        title=title,
        description=description,
        svs_id=svs_id,
        requested_by=requested_by,
        department=department,
        priority=priority,
        status=status,
    )
    db.session.add(new_ticket)
    db.session.commit()
    log_action('Ticket Created', 'ticket', ticket_id)

    return redirect(url_for('tickets_page'))


@app.route('/tickets/delete/<int:ticket_db_id>', methods=['POST'])
def delete_ticket(ticket_db_id):
    ticket = Ticket.query.get_or_404(ticket_db_id)
    ticket_id = ticket.ticket_id
    db.session.delete(ticket)
    db.session.commit()
    log_action('Ticket Deleted', 'ticket', ticket_id)
    return redirect(url_for('tickets_page'))


# ============================================================
# Scoring Rules
# ============================================================
@app.route('/scoring-rules')
def scoring_rules_page():
    rules = ScoringRule.query.all()
    return render_template(
        'scoring_rules.html',
        active_page='scoring_rules',
        rules=rules,
    )


@app.route('/scoring-rules/bulk-update', methods=['POST'])
def bulk_update_scoring_rules():
    rule_ids = request.form.getlist('rule_id[]')
    rule_titles = request.form.getlist('rule_title[]')
    rule_weights = request.form.getlist('rule_weight[]')
    sub_ids = request.form.getlist('sub_id[]')
    sub_names = request.form.getlist('sub_name[]')
    sub_weights = request.form.getlist('sub_weight[]')
    sub_criteria = request.form.getlist('sub_criteria[]')

    # Update rules
    for rid, title, weight in zip(rule_ids, rule_titles, rule_weights):
        rule = ScoringRule.query.get(int(rid))
        if rule:
            rule.title = title
            rule.weight = float(weight)

    # Update sub items
    for sid, name, sw, criteria in zip(sub_ids, sub_names, sub_weights, sub_criteria):
        sub = ScoringRuleSubItem.query.get(int(sid))
        if sub:
            sub.name = name
            sub.sub_weight = float(sw)
            sub.criteria = criteria

    # Update rubric rows (score 1-5 descriptions)
    rubric_ids = request.form.getlist('rubric_id[]')
    rubric_descs = request.form.getlist('rubric_desc[]')
    for rid, desc in zip(rubric_ids, rubric_descs):
        rubric = ScoringRubric.query.get(int(rid))
        if rubric:
            rubric.description = desc

    db.session.commit()
    log_action('Rules & Rubric Updated', 'scoring_rule', details=f'{len(rule_ids)} rules, {len(sub_ids)} subs, {len(rubric_ids)} rubric rows')

    return redirect(url_for('scoring_rules_page'))


@app.route('/scoring-rules/delete-category/<int:rule_db_id>', methods=['POST'])
def delete_scoring_category(rule_db_id):
    rule = ScoringRule.query.get_or_404(rule_db_id)
    rule_id = rule.rule_id
    db.session.delete(rule)
    db.session.commit()
    log_action('Category Deleted', 'scoring_rule', rule_id)
    return redirect(url_for('scoring_rules_page'))


@app.route('/scoring-rules/delete-sub/<int:sub_db_id>', methods=['POST'])
def delete_scoring_subcategory(sub_db_id):
    sub = ScoringRuleSubItem.query.get_or_404(sub_db_id)
    sub_name = sub.name
    db.session.delete(sub)
    db.session.commit()
    log_action('Subcategory Deleted', 'scoring_rule', sub_name)
    return redirect(url_for('scoring_rules_page'))


@app.route('/scoring-rules/add-category', methods=['POST'])
def add_scoring_category():
    title = request.form.get('title')
    weight = float(request.form.get('weight', 0))

    existing = ScoringRule.query.order_by(ScoringRule.id.desc()).first()
    new_num = existing.id + 1 if existing else 1
    rule_id = f'{new_num:02d}'

    new_rule = ScoringRule(rule_id=rule_id, title=title, weight=weight)
    db.session.add(new_rule)
    db.session.commit()
    log_action('Category Added', 'scoring_rule', rule_id)

    return redirect(url_for('scoring_rules_page'))


@app.route('/scoring-rules/add-sub', methods=['POST'])
def add_scoring_subcategory():
    rule_id = request.form.get('rule_id')
    name = request.form.get('name')
    sub_weight = float(request.form.get('sub_weight', 50))
    criteria = request.form.get('criteria', '')

    new_sub = ScoringRuleSubItem(
        rule_id=rule_id,
        name=name,
        sub_weight=sub_weight,
        criteria=criteria
    )
    db.session.add(new_sub)
    db.session.commit()

    # Create default rubric rows (1-5)
    default_rubrics = [
        (1, 'Minimal/No evidence of this criterion. Does not meet basic expectations.'),
        (2, 'Below average. Partially meets expectations with significant gaps.'),
        (3, 'Meets standard expectations. Adequate but not exceptional.'),
        (4, 'Exceeds expectations. Strong performance with clear positive impact.'),
        (5, 'Exceptional/Transformative. Sets new standard or creates breakthrough.'),
    ]
    for score, desc in default_rubrics:
        db.session.add(ScoringRubric(
            sub_item_id=new_sub.id,
            score_level=score,
            description=desc,
        ))

    db.session.commit()
    log_action('Subcategory Added', 'scoring_rule', name)

    return redirect(url_for('scoring_rules_page'))


# ============================================================
# Users
# ============================================================
@app.route('/users')
def users_page():
    users = User.query.all()
    return render_template(
        'users.html',
        active_page='users',
        users=users,
    )


@app.route('/users/create', methods=['POST'])
def create_user():
    username = request.form.get('username')
    department = request.form.get('department')
    role = request.form.get('role', 'Submitter')
    status = request.form.get('status', 'Active')

    new_user = User(
        username=username,
        department=department,
        role=role,
        status=status,
    )
    db.session.add(new_user)
    db.session.commit()
    log_action('User Added', 'user', username)

    return redirect(url_for('users_page'))


@app.route('/users/toggle/<int:user_db_id>', methods=['POST'])
def toggle_user_status(user_db_id):
    user = User.query.get_or_404(user_db_id)
    user.status = 'Inactive' if user.status == 'Active' else 'Active'
    db.session.commit()
    log_action('User ' + ('Deactivated' if user.status == 'Inactive' else 'Reactivated'), 'user', user.username)
    return redirect(url_for('users_page'))


@app.route('/users/delete/<int:user_db_id>', methods=['POST'])
def delete_user(user_db_id):
    user = User.query.get_or_404(user_db_id)
    username = user.username
    db.session.delete(user)
    db.session.commit()
    log_action('User Deleted', 'user', username)
    return redirect(url_for('users_page'))


# ============================================================
# Audit Logs
# ============================================================
@app.route('/audit-logs')
def audit_logs_page():
    logs = AuditLog.query.order_by(AuditLog.id.desc()).all()
    return render_template(
        'audit_logs.html',
        active_page='audit_logs',
        logs=logs,
    )


# ============================================================
# API & Analysis Logs
# ============================================================
@app.route('/api-logs')
def api_logs_page():
    logs = ApiLog.query.all()
    return render_template(
        'api_logs.html',
        active_page='api_logs',
        logs=logs,
    )


# ============================================================
# Scoring Request Logs
# ============================================================
@app.route('/scoring-logs')
def scoring_logs_page():
    logs = ScoringRequestLog.query.order_by(ScoringRequestLog.id.desc()).all()
    return render_template(
        'scoring_logs.html',
        active_page='scoring_logs',
        logs=logs,
    )


# ============================================================
# Seed data
# ============================================================
@app.route('/seed')
def seed():
    # Clear existing data
    db.session.query(ApiLog).delete()
    db.session.query(AuditLog).delete()
    db.session.query(ScoringRequestLog).delete()
    db.session.query(ScoringRubric).delete()
    db.session.query(ScoringRuleSubItem).delete()
    db.session.query(ScoringRule).delete()
    db.session.query(Ticket).delete()
    db.session.query(SVS).delete()
    db.session.query(User).delete()
    db.session.commit()

    # Seed SVS
    svs_data = [
        ('SVS-001', 'Cross-Border Data', 'SVS Team', 'HIGH', 'ACTIVE'),
        ('SVS-002', 'Trade Finance Hub', 'Michael Chen (Trade)', 'MEDIUM', 'ACTIVE'),
        ('SVS-003', 'Wealth Management', 'Emma Liu (Wealth)', 'MEDIUM', 'ACTIVE'),
        ('SVS-004', 'Retail Risk V2', 'John Smith (Risk)', 'HIGH', 'ACTIVE'),
        ('SVS-005', 'Core Banking Upgrade', 'Alex Morgan (IT)', 'HIGH', 'ACTIVE'),
        ('SVS-006', 'Mobile App Redesign', 'Sara Lee (Digital)', 'MEDIUM', 'ACTIVE'),
        ('SVS-007', 'Cloud Migration', 'David Kim (Cloud)', 'HIGH', 'ACTIVE'),
        ('SVS-008', 'CRM System', 'Lisa Wong (Sales)', 'LOW', 'INACTIVE'),
    ]
    for sid, name, owner, pri, stat in svs_data:
        db.session.add(SVS(svs_id=sid, name=name, owner=owner, priority=pri, status=stat))
    db.session.commit()

    all_svs = SVS.query.all()
    svs_map = {svs.svs_id: svs.id for svs in all_svs}

    # Seed Tickets
    ticket_data = [
        ('T-2024-001', 'Data Pipeline Migration', 'Migrate legacy data pipeline to new architecture', svs_map['SVS-001'], 'Alex Morgan (IT)', 'IT', 'HIGH', 'APPROVED'),
        ('T-2024-002', 'API Integration Layer', 'Build REST API layer for cross-border transactions', svs_map['SVS-001'], 'Priya Patel (Compliance)', 'Compliance', 'HIGH', 'IN_REVIEW'),
        ('T-2024-003', 'Compliance Check Automation', 'Automate compliance verification workflow', svs_map['SVS-001'], 'Priya Patel (Compliance)', 'Compliance', 'MEDIUM', 'PENDING'),
        ('T-2024-004', 'Letter of Credit Module', 'Digital LC processing module', svs_map['SVS-002'], 'Michael Chen (Trade)', 'Trade', 'MEDIUM', 'PENDING'),
        ('T-2024-005', 'Trade Analytics Dashboard', 'Real-time trade analytics and reporting', svs_map['SVS-002'], 'Michael Chen (Trade)', 'Trade', 'HIGH', 'APPROVED'),
        ('T-2024-006', 'Portfolio Optimization', 'AI-driven portfolio optimization engine', svs_map['SVS-003'], 'Emma Liu (Wealth)', 'Wealth', 'HIGH', 'APPROVED'),
        ('T-2024-007', 'Client Onboarding Flow', 'Streamlined digital onboarding for wealth clients', svs_map['SVS-003'], 'Emma Liu (Wealth)', 'Wealth', 'MEDIUM', 'DRAFT'),
        ('T-2024-008', 'Risk Scoring Engine', 'Next-gen risk scoring with ML models', svs_map['SVS-004'], 'John Smith (Risk)', 'Risk', 'HIGH', 'IN_REVIEW'),
        ('T-2024-009', 'Fraud Detection Upgrade', 'Enhanced fraud detection algorithms', svs_map['SVS-004'], 'Sam Lee (Risk Mgmt)', 'Risk', 'HIGH', 'APPROVED'),
        ('T-2024-010', 'Payment Gateway V3', 'Upgrade payment processing gateway', svs_map['SVS-005'], 'Alex Morgan (IT)', 'IT', 'HIGH', 'APPROVED'),
        ('T-2024-011', 'Account Management API', 'New account management microservices', svs_map['SVS-005'], 'David Kim (Cloud)', 'Cloud Ops', 'MEDIUM', 'PENDING'),
        ('T-2024-012', 'UI/UX Redesign', 'Complete mobile app redesign', svs_map['SVS-006'], 'Sara Lee (Digital)', 'Digital', 'MEDIUM', 'IN_REVIEW'),
        ('T-2024-013', 'AWS Infrastructure Setup', 'Set up AWS cloud infrastructure', svs_map['SVS-007'], 'David Kim (Cloud)', 'Cloud Ops', 'HIGH', 'APPROVED'),
    ]
    for tid, title, desc, svs_id, req_by, dept, pri, stat in ticket_data:
        db.session.add(Ticket(
            ticket_id=tid, title=title, description=desc,
            svs_id=svs_id, requested_by=req_by, department=dept,
            priority=pri, status=stat
        ))

    # Seed Users
    user_data = [
        ('Alex Morgan', 'Retail Banking', 'Admin', 'Active'),
        ('Sam Lee', 'Risk Management', 'Reviewer', 'Active'),
        ('Priya Patel', 'Compliance', 'Submitter', 'Inactive'),
        ('David Kim', 'Cloud Ops', 'Admin', 'Active'),
        ('Lisa Wong', 'Sales', 'Submitter', 'Active'),
        ('John Smith', 'Risk', 'Reviewer', 'Active'),
        ('Emma Liu', 'Wealth', 'Submitter', 'Inactive'),
        ('Michael Chen', 'Trade', 'Reviewer', 'Active'),
    ]
    for username, dept, role, status in user_data:
        db.session.add(User(username=username, department=dept, role=role, status=status))

    # Seed Scoring Rules
    rules_data = [
        ('01', 'Strategic Alignment', 40.00),
        ('02', 'Data Compliance Enhancement', 15.00),
        ('03', 'Impact on HSBC People & Culture', 10.00),
        ('04', 'Brand and Corporate Reputation Alignment', 35.00),
    ]
    for rid, title, weight in rules_data:
        db.session.add(ScoringRule(rule_id=rid, title=title, weight=weight))
    db.session.commit()

    # Seed Sub Items
    sub_items_data = [
        (1, 'Alignment with Corporate strategy pillars', 40.00, 'Aligned (4-5 pts), Partial (2-3 pts), None (0-1 pt)'),
        (1, 'Competitive advantage differentiation', 30.00, 'Strong (4-5 pts), Moderate (2-3 pts), Weak (0-1 pt)'),
        (1, 'Brand & Reputation Impact', 30.00, 'Major (4-5 pts), Moderate (2-3 pts), Minimal (0-1 pt)'),
        (2, 'Mandate Source', 50.00, 'Regulatory (5 pts), Internal (3 pts), Optional (1 pt)'),
        (2, 'Financial Impact', 50.00, 'High (4-5 pts), Medium (2-3 pts), Low (0-1 pt)'),
        (3, 'Automation & Efficiency', 40.00, 'Major (4-5 pts), Moderate (2-3 pts), Minimal (0-1 pt)'),
        (3, 'People Reskilling Impact', 30.00, 'High (4-5 pts), Medium (2-3 pts), Low (0-1 pt)'),
        (3, 'Future Skills Alignment', 30.00, 'Strong (4-5 pts), Partial (2-3 pts), None (0-1 pt)'),
        (4, 'ESG Alignment', 35.00, 'Strong (4-5 pts), Partial (2-3 pts), None (0-1 pt)'),
        (4, 'Customer Experience Impact', 35.00, 'Major (4-5 pts), Moderate (2-3 pts), Minimal (0-1 pt)'),
        (4, 'Market Differentiation', 30.00, 'High (4-5 pts), Medium (2-3 pts), Low (0-1 pt)'),
    ]
    for rule_id, name, sw, criteria in sub_items_data:
        db.session.add(ScoringRuleSubItem(rule_id=rule_id, name=name, sub_weight=sw, criteria=criteria))
    db.session.commit()

    # Seed Scoring Rubric (1-5 dimension table)
    all_sub_items = ScoringRuleSubItem.query.all()
    sub_id_map = {si.name: si.id for si in all_sub_items}

    rubric_data = [
        # Rule 01: Strategic Alignment
        (sub_id_map['Alignment with Corporate strategy pillars'], 1, 'No alignment with corporate strategy. Project contradicts or conflicts with stated strategic objectives.'),
        (sub_id_map['Alignment with Corporate strategy pillars'], 2, 'Minimal alignment. Project touches on strategy but does not advance any strategic pillar meaningfully.'),
        (sub_id_map['Alignment with Corporate strategy pillars'], 3, 'Partial alignment. Project supports one strategic pillar but lacks cross-functional or long-term strategic value.'),
        (sub_id_map['Alignment with Corporate strategy pillars'], 4, 'Strong alignment. Project directly advances multiple strategic pillars with clear measurable outcomes.'),
        (sub_id_map['Alignment with Corporate strategy pillars'], 5, 'Full strategic alignment. Project is transformational, enabling new business models and long-term competitive advantage.'),

        (sub_id_map['Competitive advantage differentiation'], 1, 'No differentiation. Project merely catches up to industry standard or lags behind competitors.'),
        (sub_id_map['Competitive advantage differentiation'], 2, 'Minimal differentiation. Slight improvement over current state but easily replicated by competitors.'),
        (sub_id_map['Competitive advantage differentiation'], 3, 'Moderate differentiation. Noticeable improvement that provides temporary advantage.'),
        (sub_id_map['Competitive advantage differentiation'], 4, 'Strong differentiation. Sustainable competitive advantage with significant barriers to replication.'),
        (sub_id_map['Competitive advantage differentiation'], 5, 'Transformative differentiation. Creates entirely new market category or redefines industry standards.'),

        (sub_id_map['Brand & Reputation Impact'], 1, 'Negative impact. Project risks damaging brand reputation or customer trust.'),
        (sub_id_map['Brand & Reputation Impact'], 2, 'Neutral impact. No perceptible effect on brand perception.'),
        (sub_id_map['Brand & Reputation Impact'], 3, 'Minor positive impact. Incremental improvement in customer perception.'),
        (sub_id_map['Brand & Reputation Impact'], 4, 'Significant positive impact. Major enhancement to brand positioning or customer trust.'),
        (sub_id_map['Brand & Reputation Impact'], 5, 'Transformative impact. Project becomes synonymous with brand excellence and industry leadership.'),

        # Rule 02: Data Compliance Enhancement
        (sub_id_map['Mandate Source'], 1, 'Optional or nice-to-have. No regulatory or business mandate.'),
        (sub_id_map['Mandate Source'], 2, 'Internal operational improvement. No external compliance requirement.'),
        (sub_id_map['Mandate Source'], 3, 'Regulatory guidance or recommendation. Not yet mandatory but industry best practice.'),
        (sub_id_map['Mandate Source'], 4, 'Regulatory requirement with defined timeline. Non-compliance carries operational penalties.'),
        (sub_id_map['Mandate Source'], 5, 'Critical regulatory mandate. Non-compliance carries severe penalties including license revocation.'),

        (sub_id_map['Financial Impact'], 1, 'Minimal financial impact. < $1M annual impact or negligible cost avoidance.'),
        (sub_id_map['Financial Impact'], 2, 'Small financial impact. $1-5M annual impact or limited cost savings.'),
        (sub_id_map['Financial Impact'], 3, 'Moderate financial impact. $5-20M annual impact with clear ROI within 2-3 years.'),
        (sub_id_map['Financial Impact'], 4, 'Major financial impact. $20-100M annual impact with strong ROI within 1-2 years.'),
        (sub_id_map['Financial Impact'], 5, 'Transformative financial impact. > $100M annual impact or prevents existential risk.'),

        # Rule 03: Impact on HSBC People & Culture
        (sub_id_map['Automation & Efficiency'], 1, 'No automation benefit. Manual work unchanged or increased.'),
        (sub_id_map['Automation & Efficiency'], 2, 'Minimal automation. < 10% efficiency improvement.'),
        (sub_id_map['Automation & Efficiency'], 3, 'Moderate automation. 10-30% efficiency improvement.'),
        (sub_id_map['Automation & Efficiency'], 4, 'Significant automation. 30-60% efficiency improvement with workforce redeployment.'),
        (sub_id_map['Automation & Efficiency'], 5, 'Transformative automation. > 60% efficiency improvement enabling workforce transformation.'),

        (sub_id_map['People Reskilling Impact'], 1, 'No reskilling. Project uses existing skills only.'),
        (sub_id_map['People Reskilling Impact'], 2, 'Minimal reskilling. < 50 people need minor training.'),
        (sub_id_map['People Reskilling Impact'], 3, 'Moderate reskilling. 50-200 people need structured training programs.'),
        (sub_id_map['People Reskilling Impact'], 4, 'Major reskilling. 200-1000 people need significant upskilling with career pathways.'),
        (sub_id_map['People Reskilling Impact'], 5, 'Transformative reskilling. > 1000 people with comprehensive academy program.'),

        (sub_id_map['Future Skills Alignment'], 1, 'No future skills. Uses only current or declining skills.'),
        (sub_id_map['Future Skills Alignment'], 2, 'Minimal future skills. Introduces one new skill area.'),
        (sub_id_map['Future Skills Alignment'], 3, 'Moderate future skills. Develops capabilities in 2-3 emerging areas.'),
        (sub_id_map['Future Skills Alignment'], 4, 'Strong future skills. Builds expertise in 3-5 critical future capabilities.'),
        (sub_id_map['Future Skills Alignment'], 5, 'Transformative future skills. Creates industry-leading capability in emerging domains.'),

        # Rule 04: Brand and Corporate Reputation Alignment
        (sub_id_map['ESG Alignment'], 1, 'No ESG consideration. Project may conflict with sustainability goals.'),
        (sub_id_map['ESG Alignment'], 2, 'Minimal ESG. Addresses one ESG aspect with limited scope.'),
        (sub_id_map['ESG Alignment'], 3, 'Moderate ESG. Addresses 2-3 ESG dimensions with measurable targets.'),
        (sub_id_map['ESG Alignment'], 4, 'Strong ESG. Comprehensive ESG integration across all dimensions with industry-leading targets.'),
        (sub_id_map['ESG Alignment'], 5, 'Transformative ESG. Project becomes ESG benchmark for industry, enabling systemic change.'),

        (sub_id_map['Customer Experience Impact'], 1, 'Negative CX impact. Project degrades customer experience or satisfaction.'),
        (sub_id_map['Customer Experience Impact'], 2, 'Minimal CX impact. Internal improvement invisible to customers.'),
        (sub_id_map['Customer Experience Impact'], 3, 'Moderate CX impact. Noticeable improvement in one customer journey touchpoint.'),
        (sub_id_map['Customer Experience Impact'], 4, 'Major CX impact. End-to-end journey transformation with measurable NPS improvement.'),
        (sub_id_map['Customer Experience Impact'], 5, 'Transformative CX impact. Redefines customer relationship model and sets industry standard.'),

        (sub_id_map['Market Differentiation'], 1, 'No differentiation. Standard capability available from all competitors.'),
        (sub_id_map['Market Differentiation'], 2, 'Minimal differentiation. Slight feature advantage easily matched.'),
        (sub_id_map['Market Differentiation'], 3, 'Moderate differentiation. Clear feature advantage with moderate sustainability.'),
        (sub_id_map['Market Differentiation'], 4, 'Strong differentiation. Sustainable advantage in key market segment.'),
        (sub_id_map['Market Differentiation'], 5, 'Transformative differentiation. Creates new market category or becomes platform for ecosystem.'),
    ]
    for sub_item_id, score, desc in rubric_data:
        db.session.add(ScoringRubric(sub_item_id=sub_item_id, score_level=score, description=desc))

    # Seed Audit Logs
    audit_data = [
        ('2024-03-15 14:22', 'admin_001', 'SVS Created', 'svs', 'SVS-001', None),
        ('2024-03-15 14:15', 'analyst_05', 'Score Calculated', 'ticket', 'T-2024-001', 'Score: 92.5'),
        ('2024-03-15 13:40', 'admin_001', 'Rule Updated', 'scoring_rule', '01', None),
        ('2024-03-15 10:10', 'admin_002', 'Ticket Added', 'ticket', 'T-2024-001', None),
        ('2024-04-18 10:15', 'jason_smith', 'Ticket Submitted', 'ticket', 'T-2024-008', None),
        ('2024-04-18 09:45', 'admin_001', 'Ticket Approved', 'ticket', 'T-2024-006', None),
        ('2024-04-17 16:20', 'admin_002', 'User Deactivated', 'user', 'temp_99', None),
        ('2024-04-17 14:00', 'sara_lee', 'SVS Updated', 'svs', 'SVS-003', None),
        ('2024-04-17 11:30', 'admin_001', 'Rule Created', 'scoring_rule', '04', None),
    ]
    for ts, uid, action, obj_type, obj_id, details in audit_data:
        db.session.add(AuditLog(timestamp=ts, user_id=uid, action=action, object_type=obj_type, object_id=obj_id, details=details))

    # Seed API Logs
    api_data = [
        ('14:32:11 20/10', 'john.s@hsbc', 'Retail Risk V2', 'Analysis Req', '89.4', 'Success'),
        ('13:15:02 20/10', 'emma.l@hsbc', 'Wealth Mgmt', 'Data Sync', None, 'Pending'),
        ('10:05:47 20/10', 'mike.t@hsbc', 'Retail Risk V2', 'Analysis Req', None, 'Failed'),
        ('09:22:19 20/10', 'lisa.k@hsbc', 'Trade Finance', 'Health Check', '99.0', 'Success'),
        ('08:45:33 20/10', 'alex.m@hsbc', 'Core Banking', 'Analysis Req', '92.5', 'Success'),
        ('08:12:05 20/10', 'sara.l@hsbc', 'Mobile App', 'Data Sync', None, 'Pending'),
        ('07:58:41 20/10', 'david.k@hsbc', 'Cloud Migration', 'Analysis Req', '98.0', 'Success'),
        ('07:30:15 20/10', 'priya.p@hsbc', 'Compliance Check', 'Health Check', '87.2', 'Success'),
    ]
    for ts, user, project, action, score, status in api_data:
        db.session.add(ApiLog(timestamp=ts, user=user, project=project, action=action, score=score, status=status))

    db.session.commit()
    return 'Database seeded with SVS + Ticket structure!'


# ============================================================
# Init database
# ============================================================
@app.route('/init-db')
def init_db():
    with app.app_context():
        db.create_all()
    return 'Database tables created!'


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True, host='0.0.0.0', port=5000)
